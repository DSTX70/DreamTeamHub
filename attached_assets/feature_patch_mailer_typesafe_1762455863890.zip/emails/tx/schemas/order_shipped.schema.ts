// emails/tx/schemas/order_shipped.schema.ts
import type { ObjectSchema } from "../../../shared/email/schema";

export const orderShippedSchema: ObjectSchema = {
  kind: "object",
  fields: {
    orderId: { kind: "string" },
    etaDate: { kind: "string" }, // preformatted date string for display
    orderLink: { kind: "url" },
    brandHeaderUrl: { kind: "url" },
    brandName: { kind: "string" },
    lineItems: {
      kind: "array",
      of: {
        kind: "object",
        fields: {
          thumbUrl: { kind: "url" },
          title: { kind: "string" },
          qty: { kind: "number" },
          price: { kind: "string" }, // formatted money
        }
      }
    }
  }
};
