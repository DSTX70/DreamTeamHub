// server/examples/sendShippedEmail.example.ts
import fs from "fs";
import { renderTxEmailFromFileTyped } from "../lib/mailer.typed";
import { orderShippedSchema } from "../../emails/tx/schemas/order_shipped.schema";

async function main() {
  const templatePath = "emails/tx/order_shipped.mjml";
  const html = renderTxEmailFromFileTyped(
    templatePath,
    orderShippedSchema,
    {
      orderId: "12345",
      etaDate: "Nov 10, 2025",
      orderLink: "https://example.com/orders/12345",
      brandHeaderUrl: "https://example.com/static/brand/header.png",
      brandName: "Fab Card Co.",
      lineItems: [
        { thumbUrl: "https://example.com/img/p1.webp", title: "Card A", qty: 2, price: "$7.98" },
        { thumbUrl: "https://example.com/img/p2.webp", title: "Card B", qty: 1, price: "$3.99" },
      ]
    }
  );
  fs.writeFileSync("tmp_order_shipped.html", html, "utf-8");
  console.log("Rendered to tmp_order_shipped.html");
}

main().catch(err => { console.error(err); process.exit(1); });
