# Type-Safe Mailer Helper (TS Generics + Schema)

This patch adds a tiny, **type-safe** wrapper so your transactional email templates enforce required variables **at compile time** and also validate them **at runtime**.

## Files
- `shared/email/schema.ts` — schema DSL + `TypeOf<S>` inference + `validateVars()`
- `server/lib/mailer.typed.ts` — `renderTxEmailFromFileTyped<S>()` wrapper
- `emails/tx/schemas/order_shipped.schema.ts` — example schema
- `server/examples/sendShippedEmail.example.ts` — usage

## Usage
```ts
import { renderTxEmailFromFileTyped } from "./server/lib/mailer.typed";
import { orderShippedSchema } from "./emails/tx/schemas/order_shipped.schema";

const html = renderTxEmailFromFileTyped(
  "emails/tx/order_shipped.mjml",
  orderShippedSchema,
  {
    orderId: "12345",
    etaDate: "Nov 10, 2025",
    orderLink: "https://example.com/orders/12345",
    brandHeaderUrl: "https://example.com/static/brand/header.png",
    brandName: "Fab Card Co.",
    lineItems: [
      { thumbUrl: "https://example.com/img/p1.webp", title: "Card A", qty: 2, price: "$7.98" },
    ]
  }
);
```

If you forget a required field (e.g., `brandName`) you’ll get a **TypeScript error**, and at runtime `validateVars()` will throw with a precise path (e.g., `brandName: Required string missing`).

## Notes
- `kind: "html"` permits raw HTML **strings** (still pass through escaping in your template unless you use `{{{var}}}` knowingly).
- `kind: "url"` does a light `new URL()` check at runtime.
- Extend the DSL as needed (e.g., enums, regex) and update `validateVars()` accordingly.
