// shared/email/schema.ts
// A tiny schema DSL + TypeScript type inference for email template vars.

export type PrimitiveKind = "string" | "number" | "boolean" | "url" | "html";

export interface FieldSchema {
  kind: PrimitiveKind;
  optional?: boolean;
}

export interface ObjectSchema {
  kind: "object";
  fields: Record<string, Schema>;
  optional?: boolean;
}

export interface ArraySchema {
  kind: "array";
  of: Schema;
  optional?: boolean;
}

export type Schema = FieldSchema | ObjectSchema | ArraySchema;

// ---------- Type inference (compile-time) ----------
export type TypeOf<S extends Schema> =
  S extends { kind: "string" } ? string :
  S extends { kind: "number" } ? number :
  S extends { kind: "boolean" } ? boolean :
  S extends { kind: "url" } ? string :
  S extends { kind: "html" } ? string :
  S extends { kind: "array", of: infer Item extends Schema } ? Array<TypeOf<Item>> :
  S extends { kind: "object", fields: infer F extends Record<string, Schema> } ? {
    [K in keyof F as F[K] extends { optional: true } ? K : K]-?:
      F[K] extends Schema ? TypeOf<F[K]> : never
  } : never;

// Required keys helper for docs/debug (type only)
export type RequiredKeys<S extends Schema> =
  S extends { kind: "object", fields: infer F extends Record<string, Schema> } ?
    { [K in keyof F]-?: F[K] extends { optional: true } ? never : K }[keyof F]
  : never;

// ---------- Runtime validation ----------
export type ValidationError = { path: string; message: string };

export function validateVars(schema: Schema, value: any, path: string = ""): ValidationError[] {
  const err = (m: string) => [{ path, message: m } as ValidationError];
  if (!schema) return err("Missing schema");

  switch (schema.kind) {
    case "string":
    case "html":
      if (value === undefined || value === null) {
        if (schema.optional) return [];
        return err("Required string missing");
      }
      if (typeof value !== "string") return err("Expected string");
      return [];
    case "url":
      if (value === undefined || value === null) {
        if (schema.optional) return [];
        return err("Required url missing");
      }
      if (typeof value !== "string") return err("Expected url string");
      // very light URL check
      try { new URL(value); } catch { return err("Invalid URL"); }
      return [];
    case "number":
      if (value === undefined || value === null) {
        if (schema.optional) return [];
        return err("Required number missing");
      }
      if (typeof value !== "number" || Number.isNaN(value)) return err("Expected number");
      return [];
    case "boolean":
      if (value === undefined || value === null) {
        if (schema.optional) return [];
        return err("Required boolean missing");
      }
      if (typeof value !== "boolean") return err("Expected boolean");
      return [];
    case "array":
      if (value === undefined || value === null) {
        if (schema.optional) return [];
        return err("Required array missing");
      }
      if (!Array.isArray(value)) return err("Expected array");
      const out: ValidationError[] = [];
      value.forEach((v, i) => {
        out.push(...validateVars(schema.of, v, `${path}[${i}]`));
      });
      return out;
    case "object":
      if (value === undefined || value === null) {
        if (schema.optional) return [];
        return err("Required object missing");
      }
      if (typeof value !== "object") return err("Expected object");
      const errors: ValidationError[] = [];
      for (const [k, s] of Object.entries(schema.fields || {})) {
        const childPath = path ? `${path}.${k}` : k;
        errors.push(...validateVars(s, (value as any)[k], childPath));
      }
      return errors;
    default:
      return err("Unknown schema kind");
  }
}
