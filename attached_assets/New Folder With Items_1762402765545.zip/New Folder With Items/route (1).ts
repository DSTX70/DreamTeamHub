// app/api/agents/[id]/promote/route.ts
import { NextRequest } from "next/server";
import { json } from "@/lib/next/response";
import { db } from "@/drizzle/db";
import { agent } from "@/drizzle/schema";
import { eq } from "drizzle-orm";
import { PromoteBody } from "@/lib/validators/agents";
import { z } from "zod";

const ParamId = z.object({ id: z.string().uuid("invalid agent id") });

export async function POST(req: NextRequest, ctx: { params: { id: string } }) {
  const p = ParamId.safeParse(ctx.params);
  if (!p.success) return json({ error: p.error.errors.map(e=>e.message).join("; ") }, 422);

  const body = await req.json().catch(()=> ({}));
  const pb = PromoteBody.safeParse(body);
  if (!pb.success) return json({ error: pb.error.errors.map(e=>e.message).join("; ") }, 422);
  const advance = pb.data.advance ?? 1;

  const id = p.data.id;
  const rows = await db.select().from(agent).where(eq(agent.id, id));
  if (!rows.length) return json({ error: "agent not found" }, 404);

  const current = (rows[0] as any).nextGate ?? 1;
  const next = Math.min(4, current + advance);
  const [updated] = await db.update(agent).set({ nextGate: next }).where(eq(agent.id, id)).returning();

  return json({ ok: true, agent: updated });
}
