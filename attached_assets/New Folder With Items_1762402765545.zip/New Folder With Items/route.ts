// app/api/knowledge/[owner]/[id]/publish/[fileId]/route.ts
import { NextRequest } from "next/server";
import { json } from "@/lib/next/response";
import { getDriveClient } from "@/lib/drive/googleDrive_real";
import { resolveFolders } from "@/lib/knowledge/resolveFolders";
import { db } from "@/drizzle/db";
import { opsEvent } from "@/drizzle/schema";
import crypto from "crypto";
import { PublishBody, parsePublishHeaders } from "@/lib/validators/publish";

export async function POST(req: NextRequest, ctx: { params: { owner: string; id: string; fileId: string } }) {
  const headers = parsePublishHeaders(req as unknown as Request);
  if ("error" in headers) return json({ error: headers.error }, 403);
  const { reviewerToken, idempotencyKey } = headers;

  const body = await req.json().catch(() => ({}));
  const parsed = PublishBody.safeParse(body);
  if (!parsed.success) return json({ error: parsed.error.errors.map((e) => e.message).join("; ") }, 422);

  const owner = ctx.params.owner.toUpperCase() as "BU" | "BRAND" | "PRODUCT";
  const id = ctx.params.id;
  const fileId = ctx.params.fileId;

  const { publish } = await resolveFolders(owner, id);
  if (!publish) return json({ error: "Publish folder not linked" }, 404);

  const out = await getDriveClient().copyOrMove(fileId, publish, "move");

  const reviewerHash = crypto.createHash("sha256").update(reviewerToken).digest("hex");
  const idem = idempotencyKey || crypto.randomUUID();
  await db.insert(opsEvent).values({
    actor: "reviewer",
    kind: "PUBLISH",
    ownerType: owner,
    ownerId: id as any,
    message: `Published file ${fileId}`,
    meta: { fileId, reviewerHash, idempotencyKey: idem, driveTitle: out.name, driveUrl: out.webViewLink },
  });

  return new Response(JSON.stringify({ ok: true, fileId, drive: out }), {
    status: 200,
    headers: { "content-type": "application/json", "X-Request-Id": out.id || "", "X-Idempotency-Key": idem },
  });
}
