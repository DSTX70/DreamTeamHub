// lib/validators/publish.ts
import { z } from "zod";

export const ReviewerToken = z.string().min(12, "reviewer token required (min 12 chars)");

export const IdempotencyKey = z
  .string()
  .min(1)
  .max(255)
  .optional()
  .describe("client-supplied idempotency key; reuse on retries");

export const PublishHeaders = z.object({
  reviewerToken: ReviewerToken,
  idempotencyKey: IdempotencyKey,
});

export type PublishHeaders = z.infer<typeof PublishHeaders>;

export const PublishBody = z.object({
  approver: z
    .object({
      name: z.string().min(2, "approver name too short"),
      email: z.string().email().optional(),
    })
    .optional(),
  note: z.string().max(2000).optional(),
});

export type PublishBody = z.infer<typeof PublishBody>;

export function parsePublishHeaders(req: Request): PublishHeaders | { error: string } {
  const reviewerToken = req.headers.get("x-reviewer-token") || "";
  const idempotencyKey = req.headers.get("idempotency-key") || undefined;
  const parsed = PublishHeaders.safeParse({ reviewerToken, idempotencyKey });
  if (!parsed.success) {
    return { error: parsed.error.errors.map((e) => e.message).join("; ") };
  }
  return parsed.data;
}
