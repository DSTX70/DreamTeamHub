// lib/validators/agents.ts
import { z } from "zod";

export const PromoteBody = z
  .object({
    advance: z.number().int().min(1).max(3).default(1).optional(),
    note: z.string().max(1000).optional(),
  })
  .partial();

export type PromoteBody = z.infer<typeof PromoteBody>;
