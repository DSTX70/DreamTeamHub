// server.js (excerpt)
import express from "express";
import { stagingGuard } from "./middleware/stagingGuard.js";

const app = express();

// Health check for uptime monitors
app.get("/healthz", (req, res) => res.send("ok"));

// Protect everything else when NODE_ENV=staging
app.use(stagingGuard());

// ... your routes below ...
app.get("/", (req, res) => res.send("Hello from staging"));

app.listen(process.env.PORT || 3000, () => {
  console.log("Server up");
});
