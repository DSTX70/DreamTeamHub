# Ready-to-run PR — Staging Refresh CI + stagingGuard patch

## Files to add
- `.github/workflows/staging_refresh.yml` (weekly Greenmask refresh)
- `server/middleware/stagingGuard.js` (Express guard)
- `.env.staging` (commit a sample only; real secrets in Replit/GitHub Secrets)

## Secrets to add (GitHub → Settings → Secrets and variables → Actions)
- `PROD_DB_URL` — Production DB URL for pg_dump
- `STAGING_DB_URL` — Staging DB URL for pg_restore

## How to create the PR
1. Create a new branch, e.g. `chore/staging-refresh-and-guard`.
2. Copy the files from this bundle into your repo at the indicated paths.
3. Commit and push the branch.
4. Open a Pull Request. The workflow supports manual `Run workflow` and weekly cron.

## Notes
- The CI expects `db/greenmask.yml` and `db/sql/ri_invariants.sql` to exist in your repo (use the v2 pack we generated).
- The guard activates only when `NODE_ENV=staging`.
