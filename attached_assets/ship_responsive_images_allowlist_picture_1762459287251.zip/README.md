# Responsive Images — Allowlist/S3 + <picture> helper — Drop

**Date:** 2025-11-06

This bundle adds:
- **Ops allowlist** for responsive images (SKU → base key).
- **Secure uploader** with MIME sniffing (first-byte scan) and SVG/XML rejection.
- **Sharp transformer** that outputs {avif, webp, jpg} in multiple widths.
- **S3 integration** (SDK v3) with cache-control headers.
- **<Picture /> helper** and a small util to build `srcset` easily.
- **Admin UI** for allowlist + multi-file drag-drop with progress + summary row.

> Designed to slot into your existing Node/TS monorepo. DB migrations can later replace the in-memory allowlist.

## What’s included

### Server
- `server/routes/images.route.ts`
  - `GET /api/ops/images/allowlist` — list allowlisted entries (sku → baseKey).
  - `POST /api/ops/images/allowlist` — upsert items `{ items:[{ sku, baseKey }] }`.
  - `DELETE /api/ops/images/allowlist/:sku` — remove entry.
  - `POST /api/ops/images/upload` — multi-file upload (form-data), MIME sniffs, rejects svg/xml, transforms and uploads variants to S3, returns manifest.
  - `GET /api/ops/images/variants/:baseKey` — list generated variants for a base key.

- `server/routes/img_cdn.route.ts` — optional CDN-style passthrough with sensible `Cache-Control` for `/img/*` keys (if you proxy through app).

- `server/images/s3.ts` — S3 client + helpers (env-driven).
- `server/images/mime.ts` — first-byte MIME sniff + svg/xml guard.
- `server/images/transform.ts` — Sharp pipelines (sizes, quality, formats).
- `server/images/uploader.ts` — multer + orchestrator (hash, transform, upload).

### Shared
- `shared/images/types.ts` — types for variants + manifest.

### Client
- `client/src/pages/ops/ImagesAdmin.tsx` — allowlist editor + drag-drop uploader with per-file progress + payload summary + variants table.
- `client/src/components/Picture.tsx` — `<Picture baseKey="products/CARD-CC-..." sizes="(min-width: 768px) 50vw, 100vw" alt="..." />`
- `client/src/utils/picture.ts` — `buildSrcSet()` util.

### Tests
- `tests/images_policy.test.ts` — MIME sniff unit tests (rejects svg/xml, accepts png/jpg/webp/avif).

## Env

```
AWS_REGION=us-east-1
AWS_S3_BUCKET=your-bucket
AWS_ACCESS_KEY_ID=xxx
AWS_SECRET_ACCESS_KEY=xxx
# Default Cache-Control for uploaded images (override per upload)
IMG_DEFAULT_CACHE_CONTROL=public, max-age=31536000, immutable
```

## Mount

```ts
// server/app.ts
app.use(require("./server/routes/images.route").router);
app.use(require("./server/routes/img_cdn.route").router);
```

## Usage

1) Add SKUs to allowlist in **Ops → Images**.  
2) Drag-drop assets; they’ll be transformed and pushed to S3 as:
```
s3://$BUCKET/<baseKey>/<w>.<ext>  // ext in {avif, webp, jpg}
```
3) Render images in the app with `<Picture baseKey="..."/>` and let the browser pick the best format/size.

