# Images Admin — Merged Header with Status Badges

**Date:** 2025-11-06

This patch merges the S3/Cache-Control status header into the full Images Admin page from the earlier drop (allowlist editor + uploader + variants).

Files updated/added:
- `client/src/pages/ops/ImagesAdmin.tsx` — merged page
- `client/src/pages/ops/components/StatusBadge.tsx` — badge component (ok/warn/err)

Server note: ensure `GET /api/ops/images/status` is mounted (see previous drop).
