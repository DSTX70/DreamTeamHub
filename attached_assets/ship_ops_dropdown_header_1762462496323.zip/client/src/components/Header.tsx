import React from "react";
import HeaderOpsMenu from "./HeaderOpsMenu";

const Header: React.FC = () => {
  return (
    <header className="w-full border-b bg-white">
      <div className="mx-auto max-w-6xl px-4 py-3 flex items-center justify-between">
        <a href="/" className="text-base font-semibold">Dream Team Hub</a>
        <nav className="flex items-center gap-3">
          <a href="/ops/overview" className="text-sm text-gray-700 hover:text-black">Ops</a>
          <HeaderOpsMenu />
        </nav>
      </div>
    </header>
  );
};

export default Header;
