# Ops Dropdown — Global Header

**Date:** 2025-11-06

Adds a reusable Ops dropdown menu for your global header with links to:
- Overview → /ops/overview
- Inventory → /ops/inventory
- Images → /ops/images
- Affiliates → /ops/affiliates
- Settings → /ops/settings

Included:
- client/src/components/HeaderOpsMenu.tsx
- client/src/components/Header.tsx (optional sample)
- client/src/layouts/AppShell.tsx (optional sample)

Usage:
Import and render <HeaderOpsMenu /> in your existing header.
