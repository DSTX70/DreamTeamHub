import React from "react";
import StatCard from "./components/StatCard";

type Overview = {
  inventory: { lowCount: number };
  images: { bucket: string; region: string; probeOk: boolean; defaultCacheControl: string };
  affiliates: { clicks: number; uniques: number; orders: number; revenue: number; commission: number; window: { fromISO: string; toISO: string } };
  linter: { rules: number };
};

function fmtCurrency(n: number) { return new Intl.NumberFormat(undefined, { style: "currency", currency: "USD" }).format(n); }

const OpsOverview: React.FC = () => {
  const [data, setData] = React.useState<Overview | null>(null);
  React.useEffect(()=>{
    (async ()=>{
      try {
        const r = await fetch("/api/ops/overview");
        const j = await r.json();
        setData(j);
      } catch {
        setData(null);
      }
    })();
  }, []);

  return (
    <div className="p-4 space-y-4">
      <h1 className="text-xl font-semibold">Ops Overview</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard title="Inventory" subtitle="Low-stock & thresholds" href="/ops/inventory">
          {data ? (
            <div>Low-stock SKUs: <span className={data.inventory.lowCount ? "text-red-600 font-semibold" : ""}>{data.inventory.lowCount}</span></div>
          ) : <div className="text-gray-500">Loading…</div>}
        </StatCard>

        <StatCard title="Images" subtitle="Allowlist & uploads" href="/ops/images">
          {data ? (
            <div className="space-y-1">
              <div>Bucket: <span className="font-mono">{data.images.bucket || "(unset)"}</span></div>
              <div>Probe: {data.images.probeOk ? "OK" : "Check IAM/Region"}</div>
              <div className="text-xs text-gray-600">Cache-Control: {data.images.defaultCacheControl}</div>
            </div>
          ) : <div className="text-gray-500">Loading…</div>}
        </StatCard>

        <StatCard title="Affiliates" subtitle="E2E + Ops report" href="/ops/affiliates">
          {data ? (
            <div className="space-y-1">
              <div>Clicks: {data.affiliates.clicks} • Uniques: {data.affiliates.uniques}</div>
              <div>Orders: {data.affiliates.orders}</div>
              <div>Revenue: {fmtCurrency(data.affiliates.revenue)} • Commission: {fmtCurrency(data.affiliates.commission)}</div>
              <div className="text-xs text-gray-600">Window: {new Date(data.affiliates.window.fromISO).toLocaleDateString()} → {new Date(data.affiliates.window.toISO).toLocaleDateString()}</div>
            </div>
          ) : <div className="text-gray-500">Loading…</div>}
        </StatCard>

        <StatCard title="LLM Linter" subtitle="Prompt rules & fixes" href="/llm/provider/linter">
          {data ? (
            <div>{data.linter.rules} core rules loaded</div>
          ) : <div className="text-gray-500">Loading…</div>}
        </StatCard>
      </div>
    </div>
  );
};

export default OpsOverview;
