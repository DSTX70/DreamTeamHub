import React from "react";

const StatCard: React.FC<{ title: string; subtitle?: string; href: string; children?: React.ReactNode }> = ({ title, subtitle, href, children }) => {
  return (
    <a href={href} className="block border rounded p-4 hover:shadow-md transition-shadow">
      <div className="flex items-center justify-between">
        <div>
          <div className="text-sm text-gray-600">{subtitle}</div>
          <div className="text-lg font-semibold">{title}</div>
        </div>
        <div className="text-xs text-gray-500">Open →</div>
      </div>
      <div className="mt-3 text-sm">{children}</div>
    </a>
  );
};

export default StatCard;
