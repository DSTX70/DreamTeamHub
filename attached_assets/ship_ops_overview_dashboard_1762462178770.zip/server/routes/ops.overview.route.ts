import express, { Request, Response } from "express";
import { inventoryDao } from "../db/inventoryDao";
import { affiliateDao } from "../db/affiliateDao";
import { s3List } from "../images/s3";
import { runAllRules } from "../../shared/lint/rules";

export const router = express.Router();

router.get("/api/ops/overview", async (_req: Request, res: Response) => {
  // Inventory
  const lows = await inventoryDao.getLowStock();
  const inventory = { lowCount: Array.isArray(lows) ? lows.length : 0 };

  // Images status (reuse envs + simple probe)
  const bucket = process.env.AWS_S3_BUCKET || "";
  const region = process.env.AWS_REGION || "us-east-1";
  const defaultCacheControl = process.env.IMG_DEFAULT_CACHE_CONTROL || "public, max-age=31536000, immutable";
  let probeOk = false;
  if (bucket) {
    try { await s3List(""); probeOk = true; } catch { probeOk = false; }
  }
  const images = { bucket, region, probeOk, defaultCacheControl };

  // Affiliates — last 7d summary
  const now = new Date();
  const fromISO = new Date(now.getTime() - 7*86400000).toISOString();
  const toISO = now.toISOString();
  const rep = await affiliateDao.getReport({ fromISO, toISO, commissionRate: 0.10 });
  const affiliates = {
    clicks: rep.totals.clicks,
    uniques: rep.totals.uniqueVisitors,
    orders: rep.totals.orders,
    revenue: rep.totals.revenue,
    commission: rep.totals.commission,
    window: rep.window
  };

  // Linter rule count
  const rulesCount = runAllRules({ type: "object", properties: {} }).length; // call with tiny schema to access rules array length
  const linter = { rules: rulesCount };

  res.json({ inventory, images, affiliates, linter });
});

export default router;
