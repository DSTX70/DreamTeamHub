# /ops/overview — Tiny Ops Dashboard

**Date:** 2025-11-06

Adds a lightweight Ops Overview with cards linking to **Inventory**, **Images**, **Affiliates**, and **LLM Linter**,
plus a small server endpoint that aggregates key health metrics.

## What’s included

### Server
- `server/routes/ops.overview.route.ts`
  - `GET /api/ops/overview` — returns an object with:
    - `inventory`: `{ lowCount }`
    - `images`: `{ bucket, probeOk, defaultCacheControl }`
    - `affiliates`: `{ clicks, uniques, orders, revenue, commission, window }` (last 7d)
    - `linter`: `{ rules }` (rule count pulled from shared linter rules)

### Client
- `client/src/pages/ops/OpsOverview.tsx` — 4 cards with links:
  - **Inventory** → `/ops/inventory`
  - **Images** → `/ops/images`
  - **Affiliates** → `/ops/affiliates`
  - **LLM Linter** → `/llm/provider/linter`
- `client/src/pages/ops/components/StatCard.tsx` — small UI card.

## Mount

```ts
// server/app.ts
app.use(require("./server/routes/ops.overview.route").router);
```

## Add a client route

```tsx
// e.g., in your AppRouter
// <Route path="/ops/overview" element={<OpsOverview />} />
```

