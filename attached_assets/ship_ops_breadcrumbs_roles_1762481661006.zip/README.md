# Breadcrumbs + Role Chips for Ops Settings

Date: 2025-11-07

Adds a small, reusable **Breadcrumbs** component and patches **SettingsLayout** to show:
- Ops → Settings → Alerts/Global (based on current route)
- Compact role chips (ops_viewer / ops_editor / ops_admin) fetched from /api/ops/_auth/ping

Files:
- client/src/components/Breadcrumbs.tsx
- client/src/pages/ops/settings/SettingsLayout.tsx  (drop-in replacement)

Usage elsewhere:
  <Breadcrumbs items={[{label:'Ops', href:'/ops/overview'},{label:'Inventory'}]} roles={['ops_viewer']} />
