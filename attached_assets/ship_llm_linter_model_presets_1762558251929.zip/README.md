# LLM Linter — Model Presets (GPT/Claude/Gemini)

Date: 2025-11-07

Adds per‑model presets that surface:
- Model‑specific tips (what tends to break JSON for that family)
- Extra augment lines appended to the JSON‑only block

Files:
- shared/lint/presets.ts — preset definitions
- client/src/pages/llm/ProviderPromptLinter.tsx — model selector, tips panel, augment merged with preset
