import React, { useEffect, useMemo, useState } from 'react'
import { listPods, createPod, updatePod, deletePod, listAgentSpecs, upsertAgentSpec, deleteAgentSpec } from '../lib/admin_ex'
import { listRoles, createRole, updateRole } from '../lib/api'

type RoleCard = {
  id?: number
  handle: string; title: string; pod: string
  purpose?: string; core_functions?: string[]; responsibilities?: string[]
  definition_of_done?: string[]; links?: string[]; tags?: string[]
  tone_voice?: string
}

export default function RosterAdmin(){
  return (
    <div className="section" style={{display:'grid', gap:24}}>
      <PodsPanel/>
      <RolesPanel/>
      <AgentSpecsPanel/>
    </div>
  )
}

function PodsPanel(){
  const [items, setItems] = useState<any[]>([])
  const [sel, setSel] = useState<any|null>(null)
  const [form, setForm] = useState({name:'', charter:'', owners:'', thread_id:''})

  useEffect(()=>{ (async()=>{
    try{ setItems(await listPods()) }catch{ setItems([]) }
  })() }, [])

  useEffect(()=>{
    if(!sel) return
    setForm({
      name: sel.name || '',
      charter: sel.charter || '',
      owners: (sel.owners||[]).join(', '),
      thread_id: sel.thread_id || ''
    })
  }, [sel])

  const ownersArray = useMemo(()=>form.owners.split(',').map(s=>s.trim()).filter(Boolean), [form.owners])

  const submit = async ()=>{
    if(!form.name.trim()) return
    const payload = { name: form.name.trim(), charter: form.charter, owners: ownersArray, thread_id: form.thread_id }
    if(sel?.id){
      await updatePod(sel.id, payload)
    } else {
      await createPod(payload)
    }
    setItems(await listPods())
    setSel(null)
    setForm({name:'', charter:'', owners:'', thread_id:''})
  }

  const remove = async (id:number)=>{
    if(!confirm('Delete this Pod?')) return
    await deletePod(id)
    setItems(await listPods())
    if(sel?.id===id){ setSel(null); setForm({name:'', charter:'', owners:'', thread_id:''}) }
  }

  return (
    <section>
      <h2 style={{margin:'0 0 8px'}}>Pods — Onboard / Edit / Delete</h2>
      <div style={{display:'grid', gap:10, gridTemplateColumns:'repeat(auto-fit, minmax(260px,1fr))'}}>
        <input placeholder="Pod name (e.g., Marketing & Comms)" value={form.name} onChange={e=>setForm({...form, name:e.target.value})} />
        <input placeholder="Owners (comma-separated handles)" value={form.owners} onChange={e=>setForm({...form, owners:e.target.value})} />
        <input placeholder="Thread ID (optional)" value={form.thread_id} onChange={e=>setForm({...form, thread_id:e.target.value})} />
        <input placeholder="Charter (short)" value={form.charter} onChange={e=>setForm({...form, charter:e.target.value})} />
      </div>
      <div style={{marginTop:10, display:'flex', gap:8, flexWrap:'wrap'}}>
        <button className="btn" data-pod="control" onClick={submit}><span className="icon">💾</span>{sel?.id ? 'Update Pod' : 'Create Pod'}</button>
        {sel?.id ? <button className="btn btn--secondary btn--sm" onClick={()=>{ setSel(null); setForm({name:'', charter:'', owners:'', thread_id:''})}}>Cancel</button> : null}
      </div>

      <h3 style={{marginTop:16}}>Existing Pods</h3>
      <div style={{display:'grid', gap:10}}>
        {items.map((p:any)=>(
          <div key={p.id} className="card">
            <div className="rail"></div>
            <div className="inner">
              <div className="title">{p.name}</div>
              <div className="chips">
                <span className="chip">Owners: {(p.owners||[]).join(', ')}</span>
                {p.thread_id ? <span className="chip">thread: {p.thread_id}</span> : null}
              </div>
              <p className="oneliner">{p.charter || ''}</p>
              <div style={{display:'flex', gap:8}}>
                <button className="btn btn--secondary btn--sm" onClick={()=>setSel(p)}>Edit</button>
                <button className="btn btn--danger btn--sm" onClick={()=>remove(p.id)}>Delete</button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </section>
  )
}

function RolesPanel(){
  const [items, setItems] = useState<RoleCard[]>([])
  const [sel, setSel] = useState<RoleCard|null>(null)
  const [form, setForm] = useState<RoleCard>({handle:'', title:'', pod:'', purpose:'', core_functions:[], responsibilities:[], definition_of_done:[], links:[], tags:[], tone_voice:''})
  const [core, setCore] = useState('')
  const [dod, setDod] = useState('')
  const [tags, setTags] = useState('')

  useEffect(()=>{ (async()=>{
    try{ setItems(await listRoles()) }catch{ setItems([]) }
  })() }, [])

  useEffect(()=>{
    if(!sel) return
    setForm({
      id: sel.id, handle: sel.handle, title: sel.title, pod: sel.pod,
      purpose: sel.purpose || '',
      core_functions: (sel.core_functions||[]).slice(),
      responsibilities: (sel.responsibilities||[]).slice(),
      definition_of_done: (sel.definition_of_done||[]).slice(),
      links: (sel.links||[]).slice(),
      tags: (sel.tags||[]).slice(),
      tone_voice: sel.tone_voice || ''
    })
    setCore((sel.core_functions||[]).join('; '))
    setDod((sel.definition_of_done||[]).join('; '))
    setTags((sel.tags||[]).join(', '))
  }, [sel])

  const submit = async ()=>{
    const payload = {
      handle: form.handle, title: form.title, pod: form.pod,
      purpose: form.purpose || '',
      core_functions: core.split(';').map(s=>s.trim()).filter(Boolean),
      responsibilities: form.responsibilities || [],
      definition_of_done: dod.split(';').map(s=>s.trim()).filter(Boolean),
      links: form.links || [],
      tags: tags.split(',').map(s=>s.trim()).filter(Boolean),
      tone_voice: form.tone_voice || ''
    }
    if(form.id){
      await updateRole(form.id, payload)
    } else {
      await createRole(payload)
    }
    setItems(await listRoles())
    setSel(null)
    setForm({handle:'', title:'', pod:'', purpose:'', core_functions:[], responsibilities:[], definition_of_done:[], links:[], tags:[], tone_voice:''})
    setCore(''); setDod(''); setTags('')
  }

  return (
    <section>
      <h2 style={{margin:'16px 0 8px'}}>Role Cards — Onboard & Edit</h2>
      <div style={{display:'grid', gap:10, gridTemplateColumns:'repeat(auto-fit, minmax(260px,1fr))'}}>
        <input placeholder="Handle (e.g., Prism)" value={form.handle} onChange={e=>setForm({...form, handle:e.target.value})} />
        <input placeholder="Title (e.g., Marketing Lead)" value={form.title} onChange={e=>setForm({...form, title:e.target.value})} />
        <input placeholder="Pod (e.g., Marketing & Comms)" value={form.pod} onChange={e=>setForm({...form, pod:e.target.value})} />
        <input placeholder="Tone/Voice (optional)" value={form.tone_voice||''} onChange={e=>setForm({...form, tone_voice:e.target.value})} />
        <input placeholder="Purpose (1–2 lines)" value={form.purpose||''} onChange={e=>setForm({...form, purpose:e.target.value})} />
        <input placeholder="Core Functions (semicolon-separated)" value={core} onChange={e=>setCore(e.target.value)} />
        <input placeholder="Definition of Done (semicolon-separated)" value={dod} onChange={e=>setDod(e.target.value)} />
        <input placeholder="Tags (comma-separated)" value={tags} onChange={e=>setTags(e.target.value)} />
      </div>
      <div style={{marginTop:10}}>
        <button className="btn" data-pod="brand" onClick={submit}><span className="icon">💾</span>{form.id ? 'Update Role' : 'Create Role'}</button>
        {form.id ? <button className="btn btn--secondary btn--sm" onClick={()=>{ setSel(null); setForm({handle:'', title:'', pod:'', purpose:'', core_functions:[], responsibilities:[], definition_of_done:[], links:[], tags:[], tone_voice:''}); setCore(''); setDod(''); setTags('') }}>Cancel Edit</button> : null}
      </div>

      <h3 style={{marginTop:16}}>Existing Roles</h3>
      <div style={{display:'grid', gap:10}}>
        {items.map((r:RoleCard)=>(
          <div key={r.id || r.handle + r.title} className="card">
            <div className="rail"></div>
            <div className="inner">
              <div className="title">{r.handle} — {r.title}</div>
              <div className="chips"><span className="chip">{r.pod}</span>{(r.tags||[]).map((t,i)=><span className="chip" key={i}>{t}</span>)}</div>
              <p className="oneliner">{r.purpose||''}</p>
              <button className="btn btn--secondary btn--sm" onClick={()=>setSel(r)}>Edit</button>
            </div>
          </div>
        ))}
      </div>
    </section>
  )
}

function AgentSpecsPanel(){
  const [items, setItems] = useState<any[]>([])
  const [sel, setSel] = useState<any|null>(null)
  const [form, setForm] = useState<any>({
    handle:'', title:'', pod:'', thread_id:'',
    system_prompt:'',
    instruction_blocks:'', // textarea, one per line
    tools:'threads.post,drive.search,zip.kit,hash.index', // comma-separated
    policies:'{"may_post_threads":false,"may_modify_drive":false}' // JSON
  })

  async function refresh(){ try{ const d = await listAgentSpecs(); setItems(d) } catch { setItems([]) } }
  useEffect(()=>{ refresh() }, [])

  useEffect(()=>{
    if(!sel) return
    setForm({
      handle: sel.handle || '',
      title: sel.title || '',
      pod: sel.pod || '',
      thread_id: sel.thread_id || '',
      system_prompt: sel.system_prompt || '',
      instruction_blocks: (sel.instruction_blocks||[]).join('\n'),
      tools: (sel.tools||[]).join(','),
      policies: JSON.stringify(sel.policies||{}, null, 0)
    })
  }, [sel])

  const submit = async ()=>{
    if(!form.handle || !form.title || !form.pod) return
    const payload = {
      handle: form.handle,
      title: form.title,
      pod: form.pod,
      thread_id: form.thread_id || '',
      system_prompt: form.system_prompt || `You are ${form.handle}, ${form.title} in the ${form.pod} pod.`,
      instruction_blocks: (form.instruction_blocks||'').split('\n').map((s:string)=>s.trim()).filter(Boolean),
      tools: (form.tools||'').split(',').map((s:string)=>s.trim()).filter(Boolean),
      policies: (()=>{ try{ return JSON.parse(form.policies||'{}') } catch{ return {} }})()
    }
    await upsertAgentSpec(payload)
    await refresh()
    setSel(null)
    setForm({
      handle:'', title:'', pod:'', thread_id:'',
      system_prompt:'', instruction_blocks:'',
      tools:'threads.post,drive.search,zip.kit,hash.index',
      policies:'{"may_post_threads":false,"may_modify_drive":false}'
    })
  }

  const remove = async (h:string)=>{
    if(!confirm('Delete this Agent Spec?')) return
    await deleteAgentSpec(h)
    await refresh()
    if(sel?.handle===h){
      setSel(null)
    }
  }

  return (
    <section>
      <h2 style={{margin:'16px 0 8px'}}>Agent Specs — Persisted (CRUD)</h2>
      <div style={{display:'grid', gap:10, gridTemplateColumns:'repeat(auto-fit, minmax(260px,1fr))'}}>
        <input placeholder="Handle" value={form.handle} onChange={e=>setForm({...form, handle:e.target.value})} />
        <input placeholder="Title" value={form.title} onChange={e=>setForm({...form, title:e.target.value})} />
        <input placeholder="Pod" value={form.pod} onChange={e=>setForm({...form, pod:e.target.value})} />
        <input placeholder="Thread ID (optional)" value={form.thread_id} onChange={e=>setForm({...form, thread_id:e.target.value})} />
        <input placeholder="Tools (comma-separated)" value={form.tools} onChange={e=>setForm({...form, tools:e.target.value})} />
        <textarea placeholder="Instruction Blocks (one per line)" rows={3} value={form.instruction_blocks} onChange={e=>setForm({...form, instruction_blocks:e.target.value})} />
        <textarea placeholder="System Prompt (optional override)" rows={3} value={form.system_prompt} onChange={e=>setForm({...form, system_prompt:e.target.value})} />
        <textarea placeholder='Policies (JSON)' rows={3} value={form.policies} onChange={e=>setForm({...form, policies:e.target.value})} />
      </div>
      <div style={{marginTop:10, display:'flex', gap:8, flexWrap:'wrap'}}>
        <button className="btn" data-pod="product" onClick={submit}><span className="icon">🤖</span>{sel ? 'Update Spec' : 'Create/Upsert Spec'}</button>
        {sel ? <button className="btn btn--secondary btn--sm" onClick={()=>{ setSel(null); setForm({handle:'', title:'', pod:'', thread_id:'', system_prompt:'', instruction_blocks:'', tools:'threads.post,drive.search,zip.kit,hash.index', policies:'{"may_post_threads":false,"may_modify_drive":false}'})}}>Cancel</button> : null}
      </div>

      <h3 style={{marginTop:16}}>Agent Specs in DB</h3>
      <div style={{display:'grid', gap:10}}>
        {items.map((a:any)=>(
          <div key={a.handle} className="card">
            <div className="rail"></div>
            <div className="inner">
              <div className="title">{a.handle} — {a.title}</div>
              <div className="chips"><span className="chip">{a.pod}</span>{a.thread_id ? <span className="chip">thread: {a.thread_id}</span> : null}</div>
              <p className="oneliner">{(a.system_prompt||'').slice(0,160)}{(a.system_prompt||'').length>160?'…':''}</p>
              <div style={{display:'flex', gap:8, flexWrap:'wrap'}}>
                <button className="btn btn--secondary btn--sm" onClick={()=>setSel(a)}>Edit</button>
                <button className="btn btn--danger btn--sm" onClick={()=>remove(a.handle)}>Delete</button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </section>
  )
}
