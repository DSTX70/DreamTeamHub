import { API } from '../lib/api'

// ---- Pods CRUD ----
export async function listPods(){
  const r = await fetch(`${API}/pods`)
  if(!r.ok) throw new Error('HTTP ' + r.status)
  const d = await r.json()
  return d.items || []
}

export async function createPod(payload: {name:string, charter?:string, owners?:string[], thread_id?:string}){
  const r = await fetch(`${API}/pods`, {
    method:'POST', headers:{'content-type':'application/json'},
    body: JSON.stringify(payload)
  })
  if(!r.ok) throw new Error('HTTP ' + r.status)
  return await r.json()
}

export async function updatePod(id:number, payload: {name:string, charter?:string, owners?:string[], thread_id?:string}){
  const r = await fetch(`${API}/pods/${id}`, {
    method:'PUT', headers:{'content-type':'application/json'},
    body: JSON.stringify(payload)
  })
  if(!r.ok) throw new Error('HTTP ' + r.status)
  return await r.json()
}

export async function deletePod(id:number){
  const r = await fetch(`${API}/pods/${id}`, { method:'DELETE' })
  if(!r.ok) throw new Error('HTTP ' + r.status)
  return await r.json()
}

// ---- Agent Specs CRUD ----
export async function listAgentSpecs(){
  const r = await fetch(`${API}/agent-specs`)
  if(!r.ok) throw new Error('HTTP ' + r.status)
  const d = await r.json()
  return d.items || []
}

export async function getAgentSpec(handle:string){
  const r = await fetch(`${API}/agent-specs/${encodeURIComponent(handle)}`)
  if(!r.ok) throw new Error('HTTP ' + r.status)
  return await r.json()
}

export async function upsertAgentSpec(body: any){
  const r = await fetch(`${API}/agent-specs`, { method:'POST', headers:{'content-type':'application/json'}, body: JSON.stringify(body) })
  if(!r.ok) throw new Error('HTTP ' + r.status)
  return await r.json()
}

export async function deleteAgentSpec(handle:string){
  const r = await fetch(`${API}/agent-specs/${encodeURIComponent(handle)}`, { method:'DELETE' })
  if(!r.ok) throw new Error('HTTP ' + r.status)
  return await r.json()
}
