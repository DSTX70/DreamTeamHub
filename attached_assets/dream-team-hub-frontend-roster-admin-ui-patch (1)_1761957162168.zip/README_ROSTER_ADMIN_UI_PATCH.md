# Frontend Roster Admin — UI Patch

This patch wires the Roster Admin UI to:
- Use **Pods PUT/DELETE** (full CRUD)
- Add an **Agent Specs** admin grid with CRUD to `/agent-specs`

## Files
- `src/lib/admin_ex.ts` — helper functions to call Pods + Agent Specs APIs
- `src/components/RosterAdmin.patch.tsx` — drop-in replacement for `src/components/RosterAdmin.tsx`

## How to apply
1) Unzip into your Vite app root (merge into `src/`).
2) Replace **`src/components/RosterAdmin.tsx`** with the contents of **`src/components/RosterAdmin.patch.tsx`** (or rename the file).
3) Ensure your backend has:
   - Pods CRUD: `PUT /pods/{id}`, `DELETE /pods/{id}`
   - Agent Spec persistence: `/agent-specs` (list,get,upsert,delete) and the startup loader
4) Run the app:
```bash
npm install
npm run dev -- --host
```

### Notes
- Owners field is comma-separated; Deliverables/Instruction blocks are semicolon- or newline-separated in the UI and mapped to arrays.
- If you also persisted `/agents` upserts to DB, your Agent Console shows the same agents as this grid on refresh.
