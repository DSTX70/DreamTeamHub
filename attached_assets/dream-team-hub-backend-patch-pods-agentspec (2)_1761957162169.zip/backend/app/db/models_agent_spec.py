from sqlalchemy import Column, Integer, String, Text, JSON
from app.db.init import Base

class AgentSpecModel(Base):
    __tablename__ = "agent_specs"
    id = Column(Integer, primary_key=True)
    handle = Column(String, unique=True, nullable=False)
    title = Column(String, nullable=False)
    pod = Column(String, default="")
    thread_id = Column(String, default="")
    system_prompt = Column(Text, default="")
    instruction_blocks = Column(JSON, default=list)
    tools = Column(JSON, default=list)
    policies = Column(JSON, default=dict)
