from app.db.init import SessionLocal
from app.db.models_agent_spec import AgentSpecModel
from app.routers.agents import AGENTS, AgentSpec

def load_agent_specs_from_db():
    db = SessionLocal()
    try:
        rows = db.query(AgentSpecModel).all()
        for r in rows:
            AGENTS[r.handle] = AgentSpec(
                handle=r.handle, title=r.title, pod=r.pod, thread_id=r.thread_id,
                system_prompt=r.system_prompt, instruction_blocks=r.instruction_blocks,
                tools=r.tools, policies=r.policies
            )
        return {"ok": True, "count": len(rows)}
    finally:
        db.close()
