from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.orm import Session
from app.db.init import get_db
from app.db.models import Pod

router = APIRouter()

class PodIn(BaseModel):
    name: str
    charter: str = ""
    owners: list[str] = []
    thread_id: str = ""

@router.post("")
def create_pod(body: PodIn, db: Session = Depends(get_db)):
    if db.query(Pod).filter(Pod.name == body.name).first():
        raise HTTPException(409, "Pod with that name already exists")
    p = Pod(name=body.name, charter=body.charter, owners=body.owners, thread_id=body.thread_id)
    db.add(p); db.commit(); db.refresh(p)
    return {"id": p.id, "name": p.name}

@router.get("")
def list_pods(db: Session = Depends(get_db)):
    rows = db.query(Pod).all()
    return {"items":[{"id":r.id,"name":r.name,"owners":r.owners,"thread_id":r.thread_id,"charter":r.charter} for r in rows]}

@router.put("/{pod_id}")
def update_pod(pod_id: int, body: PodIn, db: Session = Depends(get_db)):
    p = db.query(Pod).get(pod_id)
    if not p:
        raise HTTPException(404, "Pod not found")
    # enforce unique name if changed
    if body.name and body.name != p.name:
        if db.query(Pod).filter(Pod.name == body.name).first():
            raise HTTPException(409, "Another pod with that name exists")
        p.name = body.name
    p.charter = body.charter
    p.owners = body.owners
    p.thread_id = body.thread_id
    db.commit(); db.refresh(p)
    return {"ok": True, "id": p.id}

@router.delete("/{pod_id}")
def delete_pod(pod_id: int, db: Session = Depends(get_db)):
    p = db.query(Pod).get(pod_id)
    if not p:
        raise HTTPException(404, "Pod not found")
    db.delete(p); db.commit()
    return {"ok": True}
