from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.orm import Session
from app.db.init import get_db
from app.db.models_agent_spec import AgentSpecModel

router = APIRouter()

class AgentSpecIn(BaseModel):
    handle: str
    title: str
    pod: str
    thread_id: str = ""
    system_prompt: str = ""
    instruction_blocks: list[str] = []
    tools: list[str] = []
    policies: dict = {}

@router.get("")
def list_specs(db: Session = Depends(get_db)):
    rows = db.query(AgentSpecModel).all()
    return {"items":[{k:getattr(r,k) for k in ("id","handle","title","pod","thread_id","system_prompt","instruction_blocks","tools","policies")} for r in rows]}

@router.get("/{handle}")
def get_spec(handle: str, db: Session = Depends(get_db)):
    r = db.query(AgentSpecModel).filter(AgentSpecModel.handle == handle).first()
    if not r: raise HTTPException(404, "Agent spec not found")
    return {k:getattr(r,k) for k in ("id","handle","title","pod","thread_id","system_prompt","instruction_blocks","tools","policies")}

@router.post("")
def upsert_spec(body: AgentSpecIn, db: Session = Depends(get_db)):
    r = db.query(AgentSpecModel).filter(AgentSpecModel.handle == body.handle).first()
    if r:
        for k,v in body.dict().items(): setattr(r,k,v)
        db.commit(); db.refresh(r)
    else:
        r = AgentSpecModel(**body.dict()); db.add(r); db.commit(); db.refresh(r)
    return {"ok": True, "id": r.id}

@router.delete("/{handle}")
def delete_spec(handle: str, db: Session = Depends(get_db)):
    r = db.query(AgentSpecModel).filter(AgentSpecModel.handle == handle).first()
    if not r: raise HTTPException(404, "Agent spec not found")
    db.delete(r); db.commit()
    return {"ok": True}
