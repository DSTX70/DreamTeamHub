// shared/email/schema.ts
// Schema DSL + TypeScript inference + runtime validation
// Now with: enum + regex pattern constraints

export type PrimitiveKind = "string" | "number" | "boolean" | "url" | "html";

export interface BaseField {
  optional?: boolean;
  /** If provided, value must be one of these (after type coercion checks). */
  enum?: readonly (string | number | boolean)[];
  /** For strings/html/url: value must match this regex. */
  pattern?: string; // JS regex source, without slashes
}

export interface FieldSchema extends BaseField {
  kind: PrimitiveKind;
}

export interface ObjectSchema {
  kind: "object";
  fields: Record<string, Schema>;
  optional?: boolean;
}

export interface ArraySchema {
  kind: "array";
  of: Schema;
  optional?: boolean;
}

export type Schema = FieldSchema | ObjectSchema | ArraySchema;

// ---------- Type inference (compile-time) ----------
export type TypeOf<S extends Schema> =
  S extends { kind: "string" } ? string :
  S extends { kind: "number" } ? number :
  S extends { kind: "boolean" } ? boolean :
  S extends { kind: "url" } ? string :
  S extends { kind: "html" } ? string :
  S extends { kind: "array", of: infer Item extends Schema } ? Array<TypeOf<Item>> :
  S extends { kind: "object", fields: infer F extends Record<string, Schema> } ? {
    [K in keyof F as F[K] extends { optional: true } ? K : K]-?:
      F[K] extends Schema ? TypeOf<F[K]> : never
  } : never;

// Required keys helper for docs/debug (type only)
export type RequiredKeys<S extends Schema> =
  S extends { kind: "object", fields: infer F extends Record<string, Schema> } ?
    { [K in keyof F]-?: F[K] extends { optional: true } ? never : K }[keyof F]
  : never;

// ---------- Runtime validation ----------
export type ValidationError = { path: string; message: string };

function isNil(v: any) { return v === undefined || v === null; }
function err(path: string, message: string): ValidationError[] { return [{ path, message }]; }

function checkEnum(schema: FieldSchema, value: any, path: string): ValidationError[] {
  if (!schema.enum) return [];
  const ok = (schema.enum as any[]).some((e) => e === value);
  return ok ? [] : err(path, `Value '${String(value)}' not in enum [${(schema.enum as any[]).map(String).join(", ")}]`);
}

function checkPattern(schema: FieldSchema, value: any, path: string): ValidationError[] {
  if (!schema.pattern) return [];
  if (typeof value !== "string") return err(path, "Pattern provided but value is not a string");
  try {
    const re = new RegExp(schema.pattern);
    return re.test(value) ? [] : err(path, `Value '${value}' does not match pattern /${schema.pattern}/`);
  } catch {
    return err(path, `Invalid regex pattern: ${schema.pattern}`);
  }
}

export function validateVars(schema: Schema, value: any, path: string = ""): ValidationError[] {
  if (!schema) return err(path, "Missing schema");

  switch (schema.kind) {
    case "string":
    case "html": {
      if (isNil(value)) return schema.optional ? [] : err(path, "Required string missing");
      if (typeof value !== "string") return err(path, "Expected string");
      return [...checkEnum(schema, value, path), ...checkPattern(schema, value, path)];
    }
    case "url": {
      if (isNil(value)) return schema.optional ? [] : err(path, "Required url missing");
      if (typeof value !== "string") return err(path, "Expected url string");
      try { new URL(value); } catch { return err(path, "Invalid URL"); }
      return [...checkEnum(schema, value, path), ...checkPattern(schema, value, path)];
    }
    case "number": {
      if (isNil(value)) return schema.optional ? [] : err(path, "Required number missing");
      if (typeof value !== "number" || Number.isNaN(value)) return err(path, "Expected number");
      return checkEnum(schema, value, path);
    }
    case "boolean": {
      if (isNil(value)) return schema.optional ? [] : err(path, "Required boolean missing");
      if (typeof value !== "boolean") return err(path, "Expected boolean");
      return checkEnum(schema, value, path);
    }
    case "array": {
      if (isNil(value)) return schema.optional ? [] : err(path, "Required array missing");
      if (!Array.isArray(value)) return err(path, "Expected array");
      const out: ValidationError[] = [];
      value.forEach((v, i) => { out.push(...validateVars(schema.of, v, `${path}[${i}]`)); });
      return out;
    }
    case "object": {
      if (isNil(value)) return schema.optional ? [] : err(path, "Required object missing");
      if (typeof value !== "object") return err(path, "Expected object");
      const errors: ValidationError[] = [];
      for (const [k, s] of Object.entries(schema.fields || {})) {
        const childPath = path ? `${path}.${k}` : k;
        errors.push(...validateVars(s as Schema, (value as any)[k], childPath));
      }
      return errors;
    }
    default:
      return err(path, "Unknown schema kind");
  }
}
