# Schema DSL: Enum + Regex (Pattern) Constraints

This patch extends the email schema DSL with:
- **`enum`**: restrict a field to a fixed set (e.g., `statusCopy` ∈ {"Processing","Packed","Shipped","Delayed"}).
- **`pattern`**: require string-like fields to match a regex (e.g., currency format). Works on `string`, `html`, and `url` kinds.

**Updated file**
- `shared/email/schema.ts` — new fields and validation

**Example**
```ts
import { orderUpdateSchema } from "./emails/tx/schemas/order_update.schema";
import { renderTxEmailFromFileTyped } from "./server/lib/mailer.typed";

renderTxEmailFromFileTyped(
  "emails/tx/order_update.mjml",
  orderUpdateSchema,
  {
    orderId: "A1002",
    statusCopy: "Shipped",               // must be in enum
    etaDate: "Nov 12, 2025",
    orderLink: "https://example.com/orders/A1002",
    brandHeaderUrl: "https://example.com/brand/header.png",
    brandName: "Fab Card Co.",
    lineItems: [
      { thumbUrl: "https://example.com/p1.webp", title: "Card A", qty: 1, price: "$3.99" }, // matches pattern
    ],
  }
);
```

If a value is outside the **enum**, or fails the **pattern**, `validateVars()` throws with a precise path.
