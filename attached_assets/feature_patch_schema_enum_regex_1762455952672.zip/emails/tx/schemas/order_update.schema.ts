// emails/tx/schemas/order_update.schema.ts
import type { ObjectSchema } from "../../../shared/email/schema";

export const orderUpdateSchema: ObjectSchema = {
  kind: "object",
  fields: {
    orderId: { kind: "string" },
    statusCopy: { kind: "string", enum: ["Processing", "Packed", "Shipped", "Delayed"] as const },
    etaDate: { kind: "string" }, // formatted date
    orderLink: { kind: "url" },
    brandHeaderUrl: { kind: "url" },
    brandName: { kind: "string" },
    lineItems: {
      kind: "array",
      of: {
        kind: "object",
        fields: {
          thumbUrl: { kind: "url" },
          title: { kind: "string" },
          qty: { kind: "number" },
          // Enforce currency format: $12.34 or 12.34 (light check)
          price: { kind: "string", pattern: r"^\$?\d+(?:\.\d{2})?$" },
        }
      }
    }
  }
};
