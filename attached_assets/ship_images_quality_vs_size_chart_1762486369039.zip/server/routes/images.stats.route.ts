import express, { Request, Response } from "express";
import { s3List } from "../images/s3";

export const router = express.Router();

/**
 * List variant sizes for a baseKey.
 * Example variant key format: <baseKey>-<width>.<ext>
 */
router.get("/api/ops/images/stats", async (req: Request, res: Response) => {
  const baseKey = String(req.query.baseKey || "");
  if (!baseKey) return res.status(400).json({ error: "baseKey required" });

  try {
    const all = await s3List(baseKey);
    const items = (all || []).map((o:any) => {
      const m = o.key?.match(/-(\d+)\.(avif|webp|jpg)$/);
      const width = m ? Number(m[1]) : undefined;
      const ext = m ? m[2] : undefined;
      return { key: o.key, width, ext, size: Number(o.size || 0) };
    }).filter((x:any) => x.width && x.ext);

    const totalsByExt: Record<string, number> = { avif: 0, webp: 0, jpg: 0 };
    let totalsBytes = 0;
    for (const it of items as any[]) {
      totalsByExt[it.ext] = (totalsByExt[it.ext] || 0) + it.size;
      totalsBytes += it.size;
    }

    res.json({ items, totalsByExt, totalsBytes });
  } catch (e:any) {
    console.error("images.stats error:", e?.message);
    res.status(500).json({ error: "stats failed" });
  }
});

export default router;
