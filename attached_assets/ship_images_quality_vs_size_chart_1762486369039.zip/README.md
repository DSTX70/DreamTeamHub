# Images — Quality vs Size chart after upload

**Date:** 2025-11-07

Adds a post-upload **quality vs size** view to the Images Admin page:
- Fetches variant sizes from S3 via a new stats route
- Renders a small inline **bar chart** (by width and format) and a totals table

## What’s included
- `server/routes/images.stats.route.ts`
  - `GET /api/ops/images/stats?baseKey=...` → `{ items:[{key,width,ext,size}], totalsByExt:{ avif, webp, jpg }, totalsBytes }`
- `client/src/pages/ops/ImagesAdmin.tsx`
  - After upload (and on baseKey change), fetches stats and renders a **bar chart** + **summary table**

## Mount

```ts
// server/app.ts
app.use(require("./server/routes/images.stats.route").router);
```

## Notes
- This chart uses **inline SVG**, no external chart libs.
- It reads what’s already uploaded; it does **not** re-encode at different qualities (that can be a future enhancement).
