# Observability — errors/events + /ops/logs CSV

Date: 2025-11-07
