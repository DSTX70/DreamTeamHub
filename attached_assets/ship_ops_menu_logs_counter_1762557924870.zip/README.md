# Ops Menu — /ops/logs link + mini counter

Date: 2025-11-07
