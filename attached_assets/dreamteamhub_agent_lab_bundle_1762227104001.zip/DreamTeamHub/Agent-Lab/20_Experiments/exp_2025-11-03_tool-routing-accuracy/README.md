# Experiment: Tool routing accuracy @ L1
Date: 2025-11-03  |  Owner: OS  |  Status: Proposed

## Hypothesis (Why)
Improved intent detection + tool selection will produce ≥ 80% task success at p95 ≤ 5s and ≤ $0.05 per task with zero safety incidents.

## Setup (What)
- Agent: agent-router @ L1
- Spec: /Agent-Lab/10_Specs/agent-router/agent.spec.json
- Tools: search (read), formatter (write)
- Data/Scenarios: ts_router_v1 (standard scenario pack)
- Policies: standard safety, budget caps

## Procedure (How)
1) Run N=50 trials across scenario pack
2) Capture logs + traces
3) Score with evaluation harness; export KPIs CSV

## KPIs & Thresholds
- Success ≥ 0.80
- p95 Latency ≤ 5 s
- Cost/task ≤ $0.05
- Tool error rate ≤ 2%
- Safety incidents = 0

## Results
(attach metrics table and commentary)

## Decision
(Keep / Iterate / Promote) — Owner + date

## Evidence
- /Agent-Lab/30_EvidencePacks/exp_2025-11-03_tool-routing-accuracy/logs
- /Agent-Lab/30_EvidencePacks/exp_2025-11-03_tool-routing-accuracy/traces
- /Agent-Lab/30_EvidencePacks/exp_2025-11-03_tool-routing-accuracy/screens
