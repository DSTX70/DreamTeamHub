#!/usr/bin/env python3
"""
DTH Roles Importer (Python)
Usage:
  python dth_import_roles.py --manifest ../00_Canonical/roles/roles_manifest.jsonl --category "Agent Lab / Added Specialists" --dry-run
Env:
  DTH_API_BASE=https://your-dth.example.com/api
  DTH_API_TOKEN=xxxxxx
"""
import os, json, argparse, sys, requests, pathlib

parser = argparse.ArgumentParser()
parser.add_argument('--manifest', default='../00_Canonical/roles/roles_manifest.jsonl')
parser.add_argument('--category', default='Agent Lab / Added Specialists')
parser.add_argument('--dry-run', action='store_true')
args = parser.parse_args()

API_BASE = os.getenv('DTH_API_BASE')
API_TOKEN = os.getenv('DTH_API_TOKEN')
if not API_BASE or not API_TOKEN:
    print('Missing env: DTH_API_BASE and/or DTH_API_TOKEN', file=sys.stderr)
    sys.exit(2)

headers = {'Authorization': f'Bearer {API_TOKEN}', 'Content-Type': 'application/json'}
manifest_path = pathlib.Path(args.manifest)

def load_role_json(entry):
    # Try relative to manifest and project root
    p1 = (manifest_path.parent / entry['path'].lstrip('/')).resolve()
    p2 = (manifest_path.parent / ('.' + entry['path'])).resolve()
    for p in [p1, p2]:
        if p.exists():
            with open(p, 'r', encoding='utf-8') as f:
                role = json.load(f)
            return role
    raise FileNotFoundError(f"Role JSON not found for key={entry['key']}: tried {p1} and {p2}")

def upsert(entry):
    role = load_role_json(entry)
    role['category'] = args.category

    get_url = f"{API_BASE}/roles/{entry['key']}"
    if args.dry_run:
        print(f"[DRY-RUN] Would GET {get_url}")
        return True

    r = requests.get(get_url, headers=headers)
    if r.status_code == 200:
        put_url = get_url
        r2 = requests.put(put_url, headers=headers, data=json.dumps(role))
        if r2.ok:
            print(f"Updated: {entry['key']}")
            return True
        else:
            print(f"PUT failed: {entry['key']} -> {r2.status_code} {r2.text}", file=sys.stderr)
            return False
    elif r.status_code == 404:
        post_url = f"{API_BASE}/roles"
        r2 = requests.post(post_url, headers=headers, data=json.dumps(role))
        if r2.ok:
            print(f"Created: {entry['key']}")
            return True
        else:
            print(f"POST failed: {entry['key']} -> {r2.status_code} {r2.text}", file=sys.stderr)
            return False
    else:
        print(f"GET failed: {entry['key']} -> {r.status_code} {r.text}", file=sys.stderr)
        return False

def main():
    ok=0; fail=0
    with open(manifest_path, 'r', encoding='utf-8') as mf:
        for line in mf:
            line=line.strip()
            if not line: continue
            entry = json.loads(line)
            if args.dry_run:
                print(f"[DRY-RUN] Validate {entry['key']} ({entry.get('title')})")
            if upsert(entry):
                ok+=1
            else:
                fail+=1
    print(f"\nDone. OK={ok} FAIL={fail}")
    if fail>0: sys.exit(1)

if __name__ == '__main__':
    main()
