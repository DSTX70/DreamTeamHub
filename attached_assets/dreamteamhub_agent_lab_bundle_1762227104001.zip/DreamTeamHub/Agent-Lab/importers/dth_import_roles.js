#!/usr/bin/env node
/**
 * DTH Roles Importer (Node.js)
 * Usage:
 *   node dth_import_roles.js --manifest ../00_Canonical/roles/roles_manifest.jsonl --category "Agent Lab / Added Specialists" --dry-run
 * Env:
 *   DTH_API_BASE=https://your-dth.example.com/api
 *   DTH_API_TOKEN=xxxxxx
 */
import fs from 'fs';
import path from 'path';
import process from 'process';

const args = new Map(process.argv.slice(2).map((v,i,a)=> i%2===0 ? [v, a[i+1]] : []));
const manifestPath = args.get('--manifest') || '../00_Canonical/roles/roles_manifest.jsonl';
const category = args.get('--category') || 'Agent Lab / Added Specialists';
const dryRun = args.has('--dry-run');

const API_BASE = process.env.DTH_API_BASE;
const API_TOKEN = process.env.DTH_API_TOKEN;
if (!API_BASE || !API_TOKEN) {
  console.error('Missing env: DTH_API_BASE and/or DTH_API_TOKEN');
  process.exit(2);
}

function log(msg){ console.log(msg); }
function err(msg){ console.error(msg); }

async function upsertRole(entry) {
  // Load full role JSON from the manifest's path
  const filePath = path.resolve(path.dirname(manifestPath), entry.path.replace(/^\/*/,'').replace(/^Agent-Lab\//,''));
  const altPath = path.resolve(path.dirname(manifestPath), `.${entry.path}`);
  let p = fs.existsSync(filePath) ? filePath : (fs.existsSync(altPath) ? altPath : null);
  if (!p) throw new Error(`JSON file not found for key=${entry.key}: tried ${filePath} and ${altPath}`);
  const role = JSON.parse(fs.readFileSync(p, 'utf-8'));
  role.category = category;

  const headers = {
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${API_TOKEN}`
  };

  const getUrl = `${API_BASE}/roles/${encodeURIComponent(entry.key)}`;
  if (dryRun) {
    log(`[DRY-RUN] Would GET ${getUrl}`);
  } else {
    const res = await fetch(getUrl, { headers });
    if (res.status === 200) {
      // exists -> update
      const putUrl = `${API_BASE}/roles/${encodeURIComponent(entry.key)}`;
      if (dryRun) {
        log(`[DRY-RUN] Would PUT ${putUrl}`);
      } else {
        const upRes = await fetch(putUrl, { method: 'PUT', headers, body: JSON.stringify(role) });
        if (!upRes.ok) throw new Error(`PUT failed for key=${entry.key}: ${upRes.status} ${await upRes.text()}`);
        log(`Updated: ${entry.key}`);
      }
    } else if (res.status === 404) {
      // create
      const postUrl = `${API_BASE}/roles`;
      if (dryRun) {
        log(`[DRY-RUN] Would POST ${postUrl}`);
      } else {
        const crRes = await fetch(postUrl, { method: 'POST', headers, body: JSON.stringify(role) });
        if (!crRes.ok) throw new Error(`POST failed for key=${entry.key}: ${crRes.status} ${await crRes.text()}`);
        log(`Created: ${entry.key}`);
      }
    } else {
      throw new Error(`GET failed for key=${entry.key}: ${res.status} ${await res.text()}`);
    }
  }
}

async function main(){
  const lines = fs.readFileSync(manifestPath, 'utf-8').split(/\r?\n/).filter(Boolean);
  let created=0, updated=0, failed=0, skipped=0;
  for (const line of lines){
    try{
      const entry = JSON.parse(line);
      if (dryRun) {
        console.log(`[DRY-RUN] Validate ${entry.key} (${entry.title})`);
      }
      await upsertRole(entry);
      // We can't know create vs update in dry-run reliably; just mark success.
    }catch(e){
      failed++;
      err(`Error: ${e.message}`);
    }
  }
  log(`\nDone. Failures: ${failed}`);
  if (failed>0) process.exit(1);
}

main().catch(e=>{ err(e.stack||e.message); process.exit(1); });
