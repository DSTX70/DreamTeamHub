# DTH Roles Importers

Two tiny importers to upsert Agent Lab role cards into your Dream Team Hub (DTH).

## Environment
Set env vars (in Replit or your shell):

```
export DTH_API_BASE="https://your-dth.example.com/api"
export DTH_API_TOKEN="YOUR_TOKEN"
```

## Manifest
The importer reads `../00_Canonical/roles/roles_manifest.jsonl` lines like:
```
{"key":"agentic_ai_master","title":"Agentic AI Master — Senior Adviser (Global)","short_title":"Agentic AI Master","autonomy_level":"Advisory","path":"/Agent-Lab/00_Canonical/roles/agentic_ai_master.json","effective_date":"2025-11-03"}
```

## Node (JavaScript)
```
cd Agent-Lab/importers
node dth_import_roles.js --manifest ../00_Canonical/roles/roles_manifest.jsonl --category "Agent Lab / Added Specialists" --dry-run
node dth_import_roles.js --manifest ../00_Canonical/roles/roles_manifest.jsonl --category "Agent Lab / Added Specialists"
```

> Node 18+ recommended (built-in `fetch`).

## Python
```
cd Agent-Lab/importers
python dth_import_roles.py --manifest ../00_Canonical/roles/roles_manifest.jsonl --category "Agent Lab / Added Specialists" --dry-run
python dth_import_roles.py --manifest ../00_Canonical/roles/roles_manifest.jsonl --category "Agent Lab / Added Specialists"
```

## Behavior
- **Dry-run** prints intended operations without calling DTH.
- Upsert logic: GET `/roles/{key}` → 200 → PUT, 404 → POST.
- Each payload includes a `category` field set from `--category`.
- Exits non-zero if any failures occur.
