# Agent Lab — Linked Sources Pack (Canonical Imports)
_Date: 2025-11-03_

This pack consolidates the essential material from prior threads into the new, brand‑agnostic **Agent Lab**. Everything below is neutralized and ready to use here without app/brand coupling.

---

## A) Imports from Thread #6 — Brand System Integration (Agent Specs & Autonomy Ladder)

### A.1 Autonomy Ladder (L0 → L3)
- **L0 — Advisor:** read-only; drafts only; *requires human sign‑off to act*.
- **L1 — Operator:** can transform/draft/export within policy and budget caps; no unilateral spend or posting.
- **L2 — Executor:** runs scoped workflows end‑to‑end (e.g., export packs, create checklists); auto posts Mirror‑Backs; within caps.
- **L3 — Orchestrator:** can spawn/coordinate other agents and multi‑step plans; reserved for OS/Helm‑class roles; highest scrutiny.

**Promotion Rule:** One level at a time (L0→L1→L2→L3). Each hop requires green KPIs for two consecutive runs + governance sign‑off (see Section C).

### A.2 Agent Spec Library — Guardrails & Task Templates
Common fields and conventions used across specs (brand‑agnostic here):
- **capabilities:** e.g., `plan`, `route_tools`, `retrieve`, `summarize`, `generate_code`.
- **tools:** declared by name with minimal permissions; include rate limits and scopes.
- **memory:** short‑term scratchpad window; optional long‑term embedding store.
- **policies:** safety constraints, approval rules, budget caps (time/tokens/USD).
- **kpi_contract:** success rate, latency targets, cost ceiling, error-rate ceiling.
- **evaluation:** test sets + scoring metrics for the harness.
- **audit:** emit deterministic traces of planning/tool calls for reproducibility.

**Task Template Examples**
- *Reader (L0):* extract → normalize → outline → cite.
- *Router (L1):* detect intent → select tool → run → validate → mirror-back.
- *Executor (L2):* plan → substeps → run tools → reconcile → export → post.

---

## B) Imports from Thread #7 — Runtime/Ops: Internal vs External Toolkits & Switchboard

### B.1 Two-Tier Architecture (text schematic)
- **Internal OS Toolkits:** first‑party adapters (files, datastore, eval harness, audit/logs). Tight policy/budget control, low surface area.
- **External Toolkits:** third‑party/partner APIs (e.g., cloud docs, tickets, chat). Wrapped in permission & rate gates with audit headers.
- **Execution Kernel:** planner + router + budget caps + safety filters + audit trail.
- **Governance Plane:** policy registry, approvals, role-based autonomy caps.
- **Observability Plane:** live KPIs, traces, cost ledger, error streams, R/A/G states.

### B.2 Visibility Flags (per agent)
```json
{
  "expose_to_users": false,
  "list_on_switchboard": true,
  "allow_external_tools": false,
  "telemetry": {
    "emit_traces": true,
    "emit_costs": true,
    "emit_metrics": true
  }
}
```

### B.3 KPI Hub Endpoint (aggregation contract)
- **Endpoint:** `GET /review/{run_id}`
- **Returns (example):**
```json
{
  "run_id": "abc123",
  "agent": "agent-router",
  "ts": "2025-11-03T12:00:00Z",
  "kpis": {
    "task_success": 0.86,
    "latency_p50_s": 2.1,
    "latency_p95_s": 4.9,
    "cost_usd_per_task": 0.037,
    "tool_error_rate": 0.02,
    "safety_incidents": 0
  },
  "traffic": {
    "tokens_in": 4200,
    "tokens_out": 3100
  }
}
```

### B.4 Switchboard Dashboard (spec excerpt)
- **Filters:** agent, autonomy level, status (R/A/G), last run date, cost band.
- **Tiles:** per‑agent card with sparkline (success/latency/cost), current R/A/G.
- **Actions:** “Promote to external” (toggles `allow_external_tools` and `expose_to_users` per SOP), “Pause”, “Open Traces”.
- **Status Widget:** shows KPIs vs thresholds per agent; turns green/amber/red.

---

## C) Imports from Thread #11 — Using Agents (Manuals & Quickstart)

### C.1 Linkage (assets live as neutral training material)
- **User Manual (PDF):** Getting started, running experiments, reading KPIs.
- **Quickstart:** First run, evidence capture, submitting a Promotion Request.
- **Safety Appendix:** Allowed/blocked categories; incident handling flow.

### C.2 Quickstart Checklist (inline copy)
1. Select agent spec and autonomy level (start at L0/L1).
2. Confirm tools + permissions + caps.
3. Run N trials with the Evaluation Harness.
4. Review KPIs (success, p95 latency, cost, errors, safety = 0).
5. If green 2× in a row, file Promotion Request (Gate 1–4).

---

## D) Governance & Promotion (SOP)
- **Gate 1 — Safety:** zero critical policy hits; medium risks mitigated.
- **Gate 2 — Performance:** KPIs ≥ thresholds for two consecutive runs.
- **Gate 3 — Cost:** within budget caps at steady state.
- **Gate 4 — Auditability:** traces complete; runbook reproducible.
- **Approval:** L0→L1→L2→L3 (no skipping levels). L3 requires OS sign‑off.

---

## E) Decision Log & Thread Split — Canonical Links
**Entry 1 — Establish Agent Lab (brand‑agnostic canonical)**  
Date: 2025-11-03  
Scope: fundamentals, specs, governance, experiments, evaluation harness, promotion flow.  
Links: #7 (runtime/ops toolkits & switchboard), #6 (specs & autonomy ladder), #11 (manuals).

**Entry 2 — Preserve Runtime/Ops Context**  
Canonical runtime/ops locus remains **#7 Gigster Garage — Agent Toolkits & Switchboard (Internal↔External)**. Agent Lab provides the neutral R&D outputs that #7 consumes.

---

## F) Next Actions
- Seed baseline specs (Reader L0, Router L1) — included below.
- Run experiment `exp_2025-11-03_tool-routing-accuracy` with thresholds:
  - success ≥ **0.80**, p95 ≤ **5s**, cost/task ≤ **$0.05**, safety incidents = **0**.
- Wire the KPI widget to `/review/{run_id}` and log evidence to `/30_EvidencePacks/`.
