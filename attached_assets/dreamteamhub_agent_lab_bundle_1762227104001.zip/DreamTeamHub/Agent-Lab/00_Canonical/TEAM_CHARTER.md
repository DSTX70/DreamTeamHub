# Agent Lab — Team Charter
_Date: 2025-11-03_

## Purpose
Run a brand-agnostic R&D lab for agentic AI focused on **Why** (principles), **What** (architecture/specs), and **How** (experiments, evaluation, promotion). Produce reusable patterns, specs, SOPs, and evidence-backed guidance.

## Scope
- **In:** Agent specs, autonomy models (L0–L3), tool adapters, memory/policy layers, evaluation harness, safety/governance, KPI dashboards, promotion SOPs.
- **Out:** Brand-specific UI/marketing; product delivery. (Those live in product threads.)

## Roles & Roster
- **Helm — Thread Lead (R)**: Runs lab backlog, experiments, promotions.
- **OS — Executive Sponsor (A)**: Sets goals/guardrails; approves L2→L3.
- **Forge — Tech Lead (R)**: Kernel design, tool router, harness integration.
- **LexiCode — Systems/Integration (R)**: Adapters, data pipes, eval hooks.
- **Pulse — Performance (R)**: Latency/cost SLOs, perf gates.
- **Verifier — QA & Replay (R)**: Deterministic runs, pass/fail gates, regression nets.
- **Sentinel — Safety & Risk (A/R)**: Policy filters, incident playbooks, approvals.
- **Coda — OSS & License (R)**: SBOM, third‑party notices, license gates.
- **Bridge — SDK Lead (R)**: Client/server SDKs, policy headers, telemetry emitters.
- **Conductor — Program Ops (R)**: Intake→SOW→KPIs→evidence; weekly reviews.
- **CodeBlock — Modular Builds (C)**: Experiment scaffolds, stubs, fixtures.
- **App Development Guru — App Hooks (C)**: Switchboard widgets, KPI tiles.
- **Lume — UX/Product (C)**: Experiment ergonomics, promote/retire flows.
- **Archivist — Evidence Curator (R)**: Logs/traces/screens; Claim↔Spec↔Evidence matrix.
- **Aegis — IP Counsel (C)**: Public/private boundaries, filings; doc hygiene.
- **Atlas — Patentability/FTO (C)**: Prior‑art sweeps before publishing patterns.
- **Praetor — Privacy (C)**: DPIAs/DPAs, data handling rules for test sets.
- **Ledger — BizOps (C)**: Budget caps, cost tracking, pricing implications.
- **Navi — Ops (C)**: Repo/lanes, cadence calendar, thread hygiene.
- **Beacon — Comms/Analyst (C)**: Neutral whitepapers after evidence is green.

## RACI Matrix (condensed)
| Workstream | R (Responsible) | A (Accountable) | C (Consulted) | I (Informed) |
|---|---|---|---|---|
| Spec authoring & updates | Forge, LexiCode | OS | CodeBlock, Sentinel | All |
| Execution kernel & adapters | Forge, Bridge, LexiCode | OS | CodeBlock | All |
| Evaluation harness & KPIs | Verifier, Pulse | OS | Conductor | All |
| Safety & governance | Sentinel | Sentinel | Praetor, Aegis | All |
| Performance gates (SLO/SLA) | Pulse | OS | Forge | All |
| Evidence packs & traces | Archivist | Conductor | Verifier | All |
| OSS/license compliance | Coda | OS | Sentinel | All |
| Promotion decisions | Helm | OS | Sentinel, Pulse, Verifier | All |
| SDK/telemetry headers | Bridge | OS | Forge, Pulse | All |
| Budget/cost controls | Ledger | OS | Pulse | All |
| Comms/whitepapers | Beacon | OS | Aegis, Atlas, Sentinel | All |

## Decision Rights
- **Technical architecture:** Forge (R) → OS (A).  
- **Safety policy & incidents:** Sentinel (A).  
- **Promotion L0→L1/L1→L2:** Helm (R) with Sentinel/Pulse/Verifier (C), OS (A).  
- **Promotion L2→L3:** OS approval required.  
- **Budget caps:** Ledger proposes; OS approves.

## Cadence
- **Weekly Lab Review (Mon):** KPIs, promotion requests, incident review (60 min).  
- **Stand‑up (Thu, 15 min):** blockers, next runs, evidence status.  
- **Ad‑hoc:** incident postmortems within 24h.

## SLAs / Gates
- **Gate 1 — Safety:** 0 critical policy hits; mitigations for mediums.  
- **Gate 2 — Performance:** KPIs ≥ thresholds for two consecutive runs.  
- **Gate 3 — Cost:** Within caps; variance ≤ 10% week‑over‑week.  
- **Gate 4 — Auditability:** Traces/logs complete; reproducible runbook.

## Definition of Done (DoD)
A) Spec + diagram + rationale committed  
B) Sandbox run(s) with KPIs captured (success, p50/p95 latency, cost, error, safety)  
C) Evidence bundle (logs, prompts, tool calls) attached  
D) Decision note (keep/iterate/promote) with owner/date  
E) Reusable assets published (spec, code, checklist)

## Communications
- Source of truth: `/Agent-Lab/00_Canonical/` (HEADER, DECISIONS, TEAM_CHARTER).  
- Results: Post weekly KPI snapshot + status (Green/Amber/Red) with links to evidence packs.  
- External comms require Beacon + Sentinel review.


## Added Specialists

**Senior Advisers**
- **Agentic AI Master — Senior Adviser (Global) (A/C):** Guides architecture/KPIs; chairs Lab Review.
- **Master Agentic AI Strategist — Senior Adviser (C):** Maps goals → experiment portfolio; owns scenario/benchmark design.
- **Master Agentic AI Advancement Officer — Senior Adviser (C):** Runs Accelerated Promotion Program (APP); pre-flight checks, reliability loops.

**Specialist Roles**
- **Evaluation Architect**
- **Prompt & Policy Systems Engineer**
- **Memory Architect**
- **Tooling Steward**
- **Safety Red Team Lead**
- **Reliability SRE (AgentOps)**
- **Data Curator**
- **Cost Controller**
- **Telemetry & Tracing Lead**
- **Experiment Designer**


## Change Control
- Charter edits require Helm (R) and OS (A) approval via Decision Log entry.
