# Agent Lab — Optional Roles (Import Pack)
_Date: 2025-11-03_

## Evaluation Architect
**Key:** `evaluation_architect`  |  **Short:** Eval Architect  |  **Autonomy:** Advisory
**Purpose:** Design and maintain the evaluation harness, golden tasks, perturbation suites, and R/A/G thresholds.
**Top Responsibilities:**
- Define KPI schemas and scoring functions; prevent metric drift.
- Author golden tasks and scenario packs; maintain distribution quality.
- Build perturbation/adversarial test suites (noisy inputs, edge cases).
- Manage benchmark versioning; deprecate stale tests safely.
- Publish weekly KPI roll-ups and regression alerts.
**KPIs:** Test coverage across capabilities, Regression catch rate before promotion, Time-to-add new scenario from request, Metric drift incidents per quarter

## Prompt & Policy Systems Engineer
**Key:** `prompt_policy_systems_engineer`  |  **Short:** Prompt/Policy Eng  |  **Autonomy:** Advisory
**Purpose:** Parameterize prompt graphs and policy guardrails; maintain testable templates and change logs.
**Top Responsibilities:**
- Design prompt graphs/templates with modular parameters.
- Implement machine-checkable policy filters/grammars.
- Maintain versioned prompt/policy change logs tied to KPIs.
- Partner with Sentinel on safety coverage and approvals.
- Automate prompt/policy A/B testing within harness.
**KPIs:** Rollback rate after prompt/policy change, Coverage of policy rules by tests, KPI uplift per approved revision, Time-to-deploy safe prompt changes

## Memory Architect
**Key:** `memory_architect`  |  **Short:** Memory Arch  |  **Autonomy:** Advisory
**Purpose:** Design short/long-term memory schemas, retrieval strategies, and privacy-aware embeddings; measure memory benefits.
**Top Responsibilities:**
- Define memory schemas (entity, task, evidence) and retention policies.
- Tune retrieval/indexing strategies; measure hit quality.
- Ensure privacy-aware embeddings and data minimization.
- Instrument memory benefit metrics (success uplift, latency impact).
- Manage memory lifecycle (write/evict/refresh) and versioning.
**KPIs:** Retrieval precision/recall @K, Task success uplift with memory, Latency overhead due to memory, PII incident rate (target zero)

## Tooling Steward
**Key:** `tooling_steward`  |  **Short:** Tool Steward  |  **Autonomy:** Advisory
**Purpose:** Curate the tool catalog, scopes/permissions, and rate limits; run tool certification and deprecation schedule.
**Top Responsibilities:**
- Maintain inventory of tools with scopes, rate limits, owners.
- Run tool certification (tests, failure modes, guardrails).
- Define deprecation schedule; manage breaking changes.
- Coordinate with Bridge/LexiCode for adapters/SDK exposure.
- Publish a tool capability map for routing quality.
**KPIs:** Tool-related failure rate, Time-to-certify new tool, Incidents from deprecated tools, Routing accuracy when tool available

## Safety Red Team Lead
**Key:** `safety_red_team_lead`  |  **Short:** Red Team Lead  |  **Autonomy:** Advisory
**Purpose:** Craft adversarial scenarios (jailbreaks, prompt injections, data exfil) and coordinate with Sentinel on fixes.
**Top Responsibilities:**
- Design adversarial tests targeting safety/policy weak points.
- Continuously update attack library; track bypass attempts.
- Partner with Sentinel to close gaps and verify fixes.
- Run red-team exercises before promotions to higher autonomy.
- Publish incident and remediation reports.
**KPIs:** Detection rate of known attacks, Time-to-mitigate from finding to fix, Post-fix recurrence rate, Incidents caught pre-promotion

## Reliability SRE (AgentOps)
**Key:** `reliability_sre_agentops`  |  **Short:** AgentOps SRE  |  **Autonomy:** Advisory
**Purpose:** Build runbooks, monitors, auto-retries/backoff, and circuit-breakers for agent operations.
**Top Responsibilities:**
- Define SLOs and error budgets per agent class.
- Implement monitors/alerts for KPIs and failure modes.
- Engineer retries/backoff and circuit-breakers for tools and kernel calls.
- Own incident response runbooks and on-call rotations (if any).
- Run postmortems and track action items.
**KPIs:** MTTR (mean time to recovery), SLO attainment rate, Incident recurrence rate, False-alert rate

## Data Curator
**Key:** `data_curator`  |  **Short:** Data Curator  |  **Autonomy:** Advisory
**Purpose:** Manage scenario packs, labeling guidelines, and feedback datasets; handle sensitive data pathways with Praetor.
**Top Responsibilities:**
- Collect and version scenario/test data with clear licenses.
- Define labeling guidelines; run QA for consistency.
- Maintain feedback datasets from runs and postmortems.
- Work with Praetor to ensure privacy-compliant data handling.
- Publish data cards with provenance and usage notes.
**KPIs:** Label agreement rate, Data freshness (time since last update), Data incident count (target zero), Coverage of priority scenarios

## Cost Controller
**Key:** `cost_controller`  |  **Short:** Cost Controller  |  **Autonomy:** Advisory
**Purpose:** Own budget caps, anomaly alerts, and per-agent cost dashboards; partner with Ledger and Pulse.
**Top Responsibilities:**
- Define budget caps per agent/experiment; track spend vs caps.
- Detect anomalies (cost spikes) and route to owners.
- Build per-agent cost dashboards and weekly roll-ups.
- Model cost/perf trade-offs and recommendations.
- Approve cost-related gates for promotion.
**KPIs:** Budget variance, Anomaly detection lead time, Cost-per-success trend, Gated promotions due to cost noncompliance

## Telemetry & Tracing Lead
**Key:** `telemetry_tracing_lead`  |  **Short:** Telemetry Lead  |  **Autonomy:** Advisory
**Purpose:** Maintain tracing schema, correlation IDs, and evidence pack automation with Archivist/Verifier.
**Top Responsibilities:**
- Define event/tracing schema and correlation ID rules.
- Automate evidence pack assembly (logs/traces/screens).
- Ensure KPI widgets pull from authoritative sources.
- Coordinate with Bridge on SDK emitters and headers.
- Guard against PII leakage in telemetry.
**KPIs:** Trace completeness (% runs with full traces), Evidence assembly time, Telemetry privacy incidents (target zero), Widget data freshness

## Experiment Designer
**Key:** `experiment_designer`  |  **Short:** Experiment Designer  |  **Autonomy:** Advisory
**Purpose:** Ensure statistical power, sampling strategy, and result interpretation; partner with the Strategist.
**Top Responsibilities:**
- Define sample sizes and randomization plans for runs.
- Select appropriate statistical tests and confidence levels.
- Review result validity and guard against p-hacking.
- Document limitations and external validity notes.
- Train teammates on experiment hygiene.
**KPIs:** Experiments with adequate power, Rework due to design flaws, Time-to-decision aided by analyses, Training adoption rate
