# Agent Lab — Additional Agentic-AI Roles (Suggestions)
_Date: 2025-11-03_

These roles are optional but often critical to accelerate agent reliability and rigor.

1. **Evaluation Architect** — designs the evaluation harness, golden tasks, perturbation tests, and R/A/G thresholds; owns test drift management.
2. **Prompt & Policy Systems Engineer** — parameterizes prompt graphs, policy filters, and guardrail grammars; owns testable templates and change logs.
3. **Memory Architect** — designs short/long-term memory schemas, retrieval strategies, and privacy-aware embeddings; measures memory benefits.
4. **Tooling Steward** — curates tool catalog, scopes/permissions, rate limits; runs tool certification and deprecation schedule.
5. **Safety Red Team Lead** — crafts adversarial scenarios (jailbreaks, prompt injections, data exfil) and coordinates with Sentinel on fixes.
6. **Reliability SRE (AgentOps)** — builds runbooks, monitors, auto-retries/backoff, and circuit-breakers for agent operations.
7. **Data Curator** — manages scenario packs, labeling guidelines, and feedback datasets; handles sensitive data pathways with Praetor.
8. **Cost Controller** — owns budget caps, anomaly alerts, and per-agent cost dashboards; partners with Ledger and Pulse.
9. **Telemetry & Tracing Lead** — maintains tracing schema, correlation IDs, and evidence pack automation with Archivist/Verifier.
10. **Experiment Designer** — ensures statistical power, sampling strategy, and result interpretation; partners with the Strategist.

If you want any of these formalized, say the word and I’ll generate import-ready role cards.
