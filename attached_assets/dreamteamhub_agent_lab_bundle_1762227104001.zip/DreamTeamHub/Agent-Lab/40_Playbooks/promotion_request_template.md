# Promotion Request — Agent Lab

**Agent:** <agent-name>  
**From:** <current-level L0/L1/L2>  →  **To:** <requested-level>  
**Owner:** <name>  |  **Date:** <YYYY-MM-DD>

## Summary
<Concise rationale for promotion — what’s improved, expected impact, risk posture.>

## KPI Evidence (last two green runs)
| Metric | Threshold | Run A | Run B |
|---|---:|---:|---:|
| Task Success | >= <min> | <A_success> | <B_success> |
| p95 Latency (s) | <= <max> | <A_p95> | <B_p95> |
| Cost / Task (USD) | <= <max> | <A_cost> | <B_cost> |
| Tool Error Rate | <= <max> | <A_err> | <B_err> |
| Safety Incidents | = 0 | <A_safe> | <B_safe> |

Evidence packs:  
- <path-to-evidence-pack-A>  
- <path-to-evidence-pack-B>

## Safety & Governance (Gate 1)
- Policy hits: <none / list>  
- Mitigations: <notes>  
- Approval route: Sentinel (required)

## Performance (Gate 2)
- KPIs meet/exceed thresholds in two consecutive runs.  
- Regressions: <none / notes>

## Cost (Gate 3)
- Within budget caps at steady state.  
- Cost controls in place: <notes>

## Auditability (Gate 4)
- Traces/logs complete; reproducible runbook attached.  
- Links: <traces/logs>

## Approvals
- **Helm (Thread Lead):** <Approve/Reject + date + signature/initials>  
- **Sentinel (Safety/Risk):** <Approve/Reject + date + signature/initials>  
- **Pulse (Performance):** <Approve/Reject + date + signature/initials>  
- **Verifier (QA/Replay):** <Approve/Reject + date + signature/initials>  
- **OS (Sponsor; required for L2→L3):** <Approve/Reject + date + signature/initials>

## Decision
- **Outcome:** <Keep / Iterate / Promote>  
- **Effective Date:** <YYYY-MM-DD>  
- **Next Steps:** <handoff tasks, caps, monitoring>

---

**SOP Note:** Promotions occur one level at a time (L0→L1→L2→L3). L3 requires OS approval. Safety incidents must be zero in both runs.
