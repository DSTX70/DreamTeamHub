export function toCSV(rows: any[], headers: string[]): string {
  const escape = (v: any) => String(v ?? '').replaceAll('\n',' ').replaceAll('\r',' ').replaceAll(',',';')
  const head = headers.join(',')
  const body = rows.map(r => headers.map(h => escape(r[h])).join(',')).join('\n')
  return head + '\n' + body
}

export function fromCSV(csv: string): { headers: string[], rows: string[][] } {
  const lines = csv.split(/\r?\n/).filter(Boolean)
  if(!lines.length) return { headers: [], rows: [] }
  const headers = lines[0].split(',').map(s=>s.trim())
  const rows = lines.slice(1).map(line => line.split(',').map(s=>s.trim()))
  return { headers, rows }
}
