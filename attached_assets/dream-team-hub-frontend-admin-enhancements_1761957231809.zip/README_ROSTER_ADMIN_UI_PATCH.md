# Frontend Admin Enhancements — UI Patch

Adds to Roster Admin:
1) Inline validation (required fields + JSON parse errors)
2) Bulk import/export (CSV/JSON) for **Agent Specs** and **Role Cards**
3) One-click **Clone Role → Agent Spec**

## Files
- `src/lib/csv.ts`         — lightweight CSV parse/stringify
- `src/lib/download.ts`    — helper to trigger downloads
- `src/lib/admin_ex.ts`    — extended helpers (Pods PUT/DELETE, Roles & Agent Specs CRUD)
- `src/components/RosterAdmin.patch.tsx` — drop-in replacement

## How to apply
1) Unzip into your Vite app root, merging into `src/`.
2) Replace `src/components/RosterAdmin.tsx` with `src/components/RosterAdmin.patch.tsx`.
3) Ensure backend has Pods PUT/DELETE and `/agent-specs` endpoints (from the previous backend patch).
4) Run:
```bash
npm install
npm run dev -- --host
```

## CSV formats
**Roles (export):** headers `handle,title,pod,purpose,core_functions,definition_of_done,tags`  
**Agent Specs (export):** headers `handle,title,pod,thread_id,system_prompt,instruction_blocks,tools,policies`  
- `instruction_blocks` and `tools` use `|` separator; newlines in system prompt are flattened.

**Import:** JSON array or CSV rows with the corresponding headers.

