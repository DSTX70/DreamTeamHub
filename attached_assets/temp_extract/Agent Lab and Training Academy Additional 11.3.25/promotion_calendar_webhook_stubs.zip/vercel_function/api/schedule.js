// Vercel Serverless Function — Promotion Calendar Webhook (Nodemailer SMTP)
// Place under /api/schedule.js in a Vercel project.

function buildICS({ title, description, startIso, endIso, organizer, attendees = [], location = '', uid = undefined }) {
  const dtstamp = new Date().toISOString().replace(/[-:]/g, '').split('.')[0] + 'Z';
  const start = startIso.replace(/[-:]/g, '').split('.')[0] + 'Z';
  const end = endIso.replace(/[-:]/g, '').split('.')[0] + 'Z';
  const id = uid || (Math.random().toString(36).slice(2) + '@agent-lab');
  const lines = [
    'BEGIN:VCALENDAR',
    'PRODID:-//Agent Lab//Promotion Scheduler//EN',
    'VERSION:2.0',
    'CALSCALE:GREGORIAN',
    'METHOD:REQUEST',
    'BEGIN:VEVENT',
    `UID:${id}`,
    `DTSTAMP:${dtstamp}`,
    `DTSTART:${start}`,
    `DTEND:${end}`,
    `SUMMARY:${(title||'Agent Promotion Review').replace(/\r?\n/g,' ')}`,
    `DESCRIPTION:${(description||'').replace(/\r?\n/g,' ')}`,
    `ORGANIZER:${organizer}`,
    location ? `LOCATION:${location}` : '',
    'SEQUENCE:0',
    'STATUS:CONFIRMED',
    'TRANSP:OPAQUE',
    ...attendees.map(a => `ATTENDEE;ROLE=REQ-PARTICIPANT;PARTSTAT=NEEDS-ACTION;RSVP=TRUE:mailto:${a}`),
    'END:VEVENT',
    'END:VCALENDAR'
  ].filter(Boolean);
  return lines.join('\r\n');
}

import nodemailer from 'nodemailer';

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).send('Use POST');
  const payload = req.body || {};
  try {
    const list = (process.env.MAILING_LIST||'').split(',').map(s=>s.trim()).filter(Boolean);
    if (!list.length) return res.status(500).json({error:'Missing MAILING_LIST'});
    const start = payload.scheduled_at_iso;
    const endIso = new Date(new Date(start).getTime() + 30*60*1000).toISOString();

    const ics = buildICS({
      title: `Promotion Board — ${payload.agent||'Agent'} (${payload.from_to||''})`,
      description: `Auto-scheduled via Agent Lab\nRepo: ${payload.repo} PR #${payload.pr_number}\nOwner: ${payload.owner}`,
      startIso: start,
      endIso: endIso,
      organizer: `MAILTO:${process.env.ORGANIZER_EMAIL}`,
      attendees: list,
      location: process.env.MEETING_LOCATION || 'Virtual'
    });

    const transporter = nodemailer.createTransport({
      host: process.env.SMTP_HOST,
      port: parseInt(process.env.SMTP_PORT||'587',10),
      secure: false,
      auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS }
    });

    await transporter.sendMail({
      from: process.env.FROM_EMAIL,
      to: list,
      subject: `Promotion: ${payload.agent||'Agent'} ${payload.from_to||''} @ ${start}`,
      text: 'Auto-scheduled promotion review. See attached calendar invite.',
      icalEvent: { filename: 'promotion.ics', method: 'REQUEST', content: ics }
    });

    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
}
