# Vercel — Promotion Calendar Webhook
**Purpose:** Receive JSON payloads and email a `.ics` invite to your mailing list via SMTP.

## Deploy
1. Create a Vercel project and add this folder. The function lives in `/api/schedule.js`.
2. Set env vars (SMTP_*, FROM_EMAIL, ORGANIZER_EMAIL, MAILING_LIST, MEETING_LOCATION).
3. Deploy. Call `POST /api/schedule` with the payload below.

## POST payload (example)
```json
{
  "agent":"agent-router",
  "from_to":"L1 -> L2",
  "pr_number": 42,
  "repo":"owner/repo",
  "scheduled_at_iso":"2025-11-05T17:00:00.000Z",
  "owner":"octocat"
}
```
