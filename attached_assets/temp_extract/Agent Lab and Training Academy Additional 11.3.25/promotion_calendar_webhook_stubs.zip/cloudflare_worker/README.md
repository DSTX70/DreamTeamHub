# Cloudflare Worker — Promotion Calendar Webhook
**Purpose:** Receive JSON payloads from the Promotion Auto-Scheduler workflow and email a `.ics` invite to a mailing list using MailChannels.

## Deploy
1. Install Wrangler: `npm i -g wrangler`
2. Edit `wrangler.toml` vars (FROM_EMAIL, ORGANIZER_EMAIL, MAILING_LIST).
3. Deploy: `wrangler deploy`

## POST payload (example)
```json
{
  "agent":"agent-router",
  "from_to":"L1 -> L2",
  "pr_number": 42,
  "repo":"owner/repo",
  "scheduled_at_iso":"2025-11-05T17:00:00.000Z",
  "owner":"octocat"
}
```
