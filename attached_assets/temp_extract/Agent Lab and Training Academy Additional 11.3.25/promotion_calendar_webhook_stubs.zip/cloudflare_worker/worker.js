// Cloudflare Worker — Promotion Calendar Webhook (MailChannels)
// Deploy with Wrangler. Sends .ics invite to a mailing list.

function buildICS({ title, description, startIso, endIso, organizer, attendees = [], location = '', uid = undefined }) {
  const dtstamp = new Date().toISOString().replace(/[-:]/g, '').split('.')[0] + 'Z';
  const start = startIso.replace(/[-:]/g, '').split('.')[0] + 'Z';
  const end = endIso.replace(/[-:]/g, '').split('.')[0] + 'Z';
  const id = uid || (Math.random().toString(36).slice(2) + '@agent-lab');
  const lines = [
    'BEGIN:VCALENDAR',
    'PRODID:-//Agent Lab//Promotion Scheduler//EN',
    'VERSION:2.0',
    'CALSCALE:GREGORIAN',
    'METHOD:REQUEST',
    'BEGIN:VEVENT',
    `UID:${id}`,
    `DTSTAMP:${dtstamp}`,
    `DTSTART:${start}`,
    `DTEND:${end}`,
    `SUMMARY:${(title||'Agent Promotion Review').replace(/\r?\n/g,' ')}`,
    `DESCRIPTION:${(description||'').replace(/\r?\n/g,' ')}`,
    `ORGANIZER:${organizer}`,
    location ? `LOCATION:${location}` : '',
    'SEQUENCE:0',
    'STATUS:CONFIRMED',
    'TRANSP:OPAQUE',
    ...attendees.map(a => `ATTENDEE;ROLE=REQ-PARTICIPANT;PARTSTAT=NEEDS-ACTION;RSVP=TRUE:mailto:${a}`),
    'END:VEVENT',
    'END:VCALENDAR'
  ].filter(Boolean);
  return lines.join('\r\n');
}

export default { 
  async fetch(request, env) {
    if (request.method !== 'POST') return new Response('Use POST', {status:405});
    let payload;
    try { payload = await request.json(); } catch (e) { return new Response('Bad JSON', {status:400}); }
    const mailingList = (env.MAILING_LIST || '').split(',').map(s=>s.trim()).filter(Boolean);
    if (!mailingList.length) return new Response('Missing MAILING_LIST', {status:500});

    const start = payload.scheduled_at_iso;
    // default to 30 min slot; adjust if needed
    const endIso = new Date(new Date(start).getTime() + 30*60*1000).toISOString();

    const ics = buildICS({
      title: `Promotion Board — ${payload.agent||'Agent'} (${payload.from_to||''})`,
      description: `Auto-scheduled via Agent Lab\nRepo: ${payload.repo} PR #${payload.pr_number}\nOwner: ${payload.owner}`,
      startIso: start,
      endIso: endIso,
      organizer: `MAILTO:${env.ORGANIZER_EMAIL}`,
      attendees: mailingList,
      location: env.MEETING_LOCATION || 'Virtual'
    });

    // Compose MailChannels payload
    const subject = `Promotion: ${payload.agent||'Agent'} ${payload.from_to||''} @ ${start}`;
    const boundary = 'BOUNDARY-' + Math.random().toString(36).slice(2);
    const icsPart = `--${boundary}\r\nContent-Type: text/calendar; charset="utf-8"; method=REQUEST\r\nContent-Transfer-Encoding: 7bit\r\n\r\n${ics}\r\n`;
    const textPart = `--${boundary}\r\nContent-Type: text/plain; charset="utf-8"\r\n\r\nAuto-scheduled promotion review. See attached calendar invite.\r\n\r\n${payload.repo} PR #${payload.pr_number}\r\n--${boundary}--`;

    const mail = {
      from: { email: env.FROM_EMAIL, name: 'Agent Lab Scheduler' },
      personalizations: [{ to: mailingList.map(e=>({email:e})), subject }],
      content: [{ type: 'multipart/mixed; boundary=' + boundary, value: textPart + icsPart }]
    };

    const resp = await fetch('https://api.mailchannels.net/tx/v1/send', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify(mail)
    });
    if (!resp.ok) {
      const text = await resp.text();
      return new Response('MailChannels error: ' + text, { status: 502 });
    }
    return new Response(JSON.stringify({ ok: true }), {headers:{'content-type':'application/json'}});
  }
};
