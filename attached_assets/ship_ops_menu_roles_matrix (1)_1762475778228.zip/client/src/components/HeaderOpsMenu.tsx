import React from "react";
import Tooltip from "./Tooltip";

const Item: React.FC<{ href: string; label: string; desc?: string }> = ({ href, label, desc }) => (
  <a href={href} className="block px-3 py-2 rounded hover:bg-gray-50">
    <div className="text-sm font-medium">{label}</div>
    {desc ? <div className="text-xs text-gray-500">{desc}</div> : null}
  </a>
);

const roleColors: Record<string, string> = {
  ops_viewer: "bg-gray-100 text-gray-700 border-gray-200",
  ops_editor: "bg-blue-100 text-blue-700 border-blue-200",
  ops_admin:  "bg-indigo-100 text-indigo-700 border-indigo-200",
};

const Chip: React.FC<{ role: string }> = ({ role }) => (
  <span className={`text-[10px] px-1 py-0.5 rounded border ${roleColors[role] || "bg-gray-100 text-gray-700 border-gray-200"}`}>{role}</span>
);

function hasAny(roles: string[], allowed: string[]) {
  return roles.some(r => allowed.includes(r));
}

const HeaderOpsMenu: React.FC = () => {
  const [open, setOpen] = React.useState(false);
  const [showHint, setShowHint] = React.useState(false);
  const [hotkeysEnabled, setHotkeysEnabled] = React.useState<boolean>(true);
  const [roles, setRoles] = React.useState<string[]>([]);
  const ref = React.useRef<HTMLDivElement | null>(null);
  const hintTimer = React.useRef<number | null>(null);

  React.useEffect(() => {
    const onDoc = (e: MouseEvent) => {
      if (!ref.current) return;
      if (!ref.current.contains(e.target as any)) setOpen(false);
    };
    document.addEventListener("click", onDoc);
    return () => document.removeEventListener("click", onDoc);
  }, []);

  React.useEffect(() => {
    (async () => {
      try {
        const r = await fetch("/api/ops/settings/notifiers");
        const j = await r.json();
        setHotkeysEnabled(j.settings?.hotkeysEnabled ?? true);
      } catch {
        setHotkeysEnabled(true);
      }
    })();
  }, []);

  React.useEffect(() => {
    (async () => {
      try {
        const r = await fetch("/api/ops/_auth/ping", { headers: { "Authorization": "" } });
        const j = await r.json();
        const rs = Array.isArray(j?.who?.roles) ? j.who.roles : [];
        setRoles(rs);
      } catch {
        setRoles([]);
      }
    })();
  }, []);

  React.useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (!hotkeysEnabled) return;
      const el = e.target as HTMLElement | null;
      const tag = el?.tagName;
      const editable = el?.getAttribute?.("contenteditable");
      if (tag === "INPUT" || tag === "TEXTAREA" || editable === "true") return;
      if (e.key === "?" || (e.key === "/" && e.shiftKey)) {
        setOpen(true);
        if (hintTimer.current) window.clearTimeout(hintTimer.current);
        setShowHint(true);
        hintTimer.current = window.setTimeout(() => setShowHint(false), 1500);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [hotkeysEnabled]);

  React.useEffect(() => () => { if (hintTimer.current) window.clearTimeout(hintTimer.current); }, []);

  const hotkeyList = (
    <div className="space-y-1">
      <div><span className="font-mono">g o</span> — Overview</div>
      <div><span className="font-mono">g i</span> — Inventory</div>
      <div><span className="font-mono">g m</span> — Images</div>
      <div><span className="font-mono">g a</span> — Affiliates</div>
      <div><span className="font-mono">g s</span> — Settings</div>
      <div className="text-[10px] text-gray-500 pt-1">Press keys in sequence within ~1.2s</div>
    </div>
  );

  const canOverview   = hasAny(roles, ["ops_viewer","ops_editor","ops_admin"]);
  const canInventory  = hasAny(roles, ["ops_viewer","ops_editor","ops_admin"]);
  const canImages     = hasAny(roles, ["ops_viewer","ops_editor","ops_admin"]);
  const canAffiliates = hasAny(roles, ["ops_viewer","ops_editor","ops_admin"]);
  const canSettings   = hasAny(roles, ["ops_admin"]);

  return (
    <div className="relative" ref={ref}>
      <button
        className="inline-flex items-center gap-2 px-3 py-1.5 border rounded-lg text-sm hover:shadow-sm"
        onClick={() => setOpen(v => !v)}
        aria-expanded={open}
        aria-haspopup="menu"
      >
        <span className="inline-flex items-center gap-2">
          <span>Ops</span>
          <span className="inline-flex items-center gap-1">
            {roles.slice(0,3).map(r => <Chip key={r} role={r} />)}
            {roles.length > 3 && <span className="text-[10px] px-1 py-0.5 rounded bg-gray-100 text-gray-700 border border-gray-200">+{roles.length-3}</span>}
          </span>
        </span>
        <svg width="16" height="16" viewBox="0 0 24 24" className="opacity-70"><path d="M7 10l5 5 5-5H7z"></path></svg>
      </button>
      {open && (
        <div role="menu" className="absolute right-0 mt-2 w-64 bg-white border rounded-lg shadow-lg p-2 z-50">
          <div className="flex items-center justify-between px-1 py-1">
            <div className="text-xs uppercase tracking-wide text-gray-500">Operations</div>
            <Tooltip
              muted={!hotkeysEnabled}
              content={hotkeysEnabled ? hotkeyList : <div className="text-gray-500">Hotkeys disabled by Ops</div>}
            />
          </div>
          {canOverview   && <Item href="/ops/overview"   label="Overview"   desc="Ops dashboard & health" />}
          {canInventory  && <Item href="/ops/inventory"  label="Inventory"  desc="Low stock & thresholds" />}
          {canImages     && <Item href="/ops/images"     label="Images"     desc="Allowlist & uploader" />}
          {canAffiliates && <Item href="/ops/affiliates" label="Affiliates" desc="E2E & Ops report" />}
          <div className="h-px bg-gray-200 my-1" />
          {canSettings   && <Item href="/ops/settings"   label="Settings"   desc="Alerts & notifications" />}
        </div>
      )}
    </div>
  );
};

export default HeaderOpsMenu;
