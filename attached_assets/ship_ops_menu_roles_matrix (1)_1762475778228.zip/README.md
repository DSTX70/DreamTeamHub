# Ops Menu — Roles Matrix & Chips

**Date:** 2025-11-07

Upgrades the Ops dropdown to support **role chips** and **link gating** via a simple matrix.

## Roles
- `ops_viewer` — read-only access to Ops pages
- `ops_editor` — can edit Ops settings for inventory/images/affiliates (but not global)
- `ops_admin` — full access including `/ops/settings`

## Gating Matrix
- Overview: viewer, editor, admin
- Inventory: viewer, editor, admin
- Images: viewer, editor, admin
- Affiliates: viewer, editor, admin
- Settings: admin only

## Files
- `client/src/components/HeaderOpsMenu.tsx` — fetches roles from `/api/ops/_auth/ping`, renders compact chips, and hides links based on matrix.
