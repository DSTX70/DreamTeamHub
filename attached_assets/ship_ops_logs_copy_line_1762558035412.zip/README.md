# /ops/logs — Copy line button

**Date:** 2025-11-07

Adds a tiny **copy-to-clipboard** icon/button next to each log line in `/ops/logs`.
Uses the Clipboard API (`navigator.clipboard.writeText`) with a brief inline “Copied!” flash.
