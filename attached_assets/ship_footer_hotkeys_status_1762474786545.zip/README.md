# Footer Status — Hotkeys On/Off

Date: 2025-11-07

Adds a tiny footer status mirroring the global hotkeys toggle from /api/ops/settings/notifiers.
- Shows "Hotkeys: On" (green dot) or "Hotkeys: Off" (gray dot).
- Polls every 30s to reflect changes.
