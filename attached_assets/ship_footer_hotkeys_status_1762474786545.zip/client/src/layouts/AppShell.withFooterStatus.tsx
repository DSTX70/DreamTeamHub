import React from "react";
import Header from "../components/Header";
import FooterStatus from "../components/FooterStatus";

const AppShellWithFooterStatus: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Header />
      <main className="mx-auto max-w-6xl px-4 py-6 flex-1">{children}</main>
      <footer className="w-full border-t bg-white">
        <div className="mx-auto max-w-6xl px-4 py-2 flex items-center justify-end">
          <FooterStatus />
        </div>
      </footer>
    </div>
  );
};

export default AppShellWithFooterStatus;
