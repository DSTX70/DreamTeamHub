import React from "react";

const Dot: React.FC<{ state: "on" | "off" | "loading" }> = ({ state }) => {
  const color = state === "on" ? "#16a34a" : state === "off" ? "#9ca3af" : "#f59e0b";
  return <span className="inline-block w-2 h-2 rounded-full" style={{ backgroundColor: color }} />;
};

const FooterStatus: React.FC = () => {
  const [state, setState] = React.useState<"on"|"off"|"loading">("loading");

  const fetchStatus = async () => {
    try {
      const r = await fetch("/api/ops/settings/notifiers");
      const j = await r.json();
      const enabled = j.settings?.hotkeysEnabled ?? true;
      setState(enabled ? "on" : "off");
    } catch {
      setState("off");
    }
  };

  React.useEffect(() => {
    fetchStatus();
    const t = window.setInterval(fetchStatus, 30_000);
    return () => window.clearInterval(t);
  }, []);

  return (
    <div className="text-xs text-gray-600 inline-flex items-center gap-2">
      <Dot state={state} />
      <span>Hotkeys: {state === "on" ? "On" : state === "off" ? "Off" : "…"}</span>
    </div>
  );
};

export default FooterStatus;
