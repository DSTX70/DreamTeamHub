export const COMMON_INSTRUCTION_BLOCKS = [
  "Respect Brand-Lock (colors, typography, logo lockups).",
  "Apply Definition of Done; include Owner, Due, Milestone, Next.",
  "Keep outputs concise; link artifacts and sources.",
  "If external send implied, output 'ready-to-send' draft.",
  "For agents: post Summon/Mirror using canonical format when requested."
]
