import React from 'react'
import { createRoot } from 'react-dom/client'
import { useEffect, useState } from 'react'

const API = import.meta.env.VITE_API_URL || 'http://localhost:8000'

function ControlTower() {
  const [top5, setTop5] = useState<any[]>([])
  useEffect(() => {
    fetch(`${API}/control/top5`).then(r=>r.json()).then(d=>setTop5(d.items||[]))
  }, [])
  return (
    <div>
      <h2>Control Tower — Top 5</h2>
      <ul>
        {top5.map(i => <li key={i.id}>{i.title} — {i.status} — due {i.due}</li>)}
      </ul>
    </div>
  )
}

function App() {
  return (
    <div style={{fontFamily:'Inter, system-ui, sans-serif', padding: 24}}>
      <h1>Dream Team Hub</h1>
      <p>API: {API}</p>
      <ControlTower />
    </div>
  )
}

createRoot(document.getElementById('root')!).render(<App />)
