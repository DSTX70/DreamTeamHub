from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from ..db.init import get_db
from ..db.models import WorkItem

router = APIRouter()

@router.get("/top5")
def top5(db: Session = Depends(get_db)):
    items = db.query(WorkItem).order_by(WorkItem.id.desc()).limit(5).all()
    return {"items": [{
        "id": i.id,
        "title": i.title,
        "status": i.status,
        "due": i.due,
        "milestone": i.milestone
    } for i in items]}

@router.get("/assignments")
def assignments(db: Session = Depends(get_db)):
    items = db.query(WorkItem).all()
    return {"items": [{
        "id": i.id, "title": i.title, "status": i.status, "due": i.due
    } for i in items]}
