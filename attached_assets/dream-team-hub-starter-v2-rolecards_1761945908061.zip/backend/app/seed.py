from .db.init import SessionLocal, engine
from .db.create_db import init_db
from .db.models import Pod, Person, RoleCard

def seed():
    init_db()
    db = SessionLocal()
    pods = ["Control Tower","Intake & Routing","Decision Log","IP & Patent Program","Marketing","Product & Engineering","Brand & Assets","Finance","Security","Roster"]
    for name in pods:
        if not db.query(Pod).filter_by(name=name).first():
            db.add(Pod(name=name, charter=f"Canonical thread for {name}", owners=["OS"]))
    if not db.query(Person).filter_by(handle="OS").first():
        db.add(Person(handle="OS", name="Orchestrator", roles=["admin"]))
    db.commit(); db.close()

if __name__ == "__main__":
    seed()

from .db.models import RoleCard

def seed_role_cards(db):
    starter = [
        {
            "handle":"OS",
            "title":"Orchestrator",
            "pod":"Control Tower",
            "purpose":"Coordinate pods, priorities, and mirrors.",
            "core_functions":[
                "Set Top-5 priorities",
                "Chase escalations",
                "Run weekly/quarterly rhythm"
            ],
            "responsibilities":[
                "Maintain Decision Log linkage",
                "Ensure mirror-backs to canonicals",
                "Keep milestone states current"
            ],
            "tone_voice":"Clear, decisive, action-first.",
            "definition_of_done":[
                "Owner+Due+Milestone+Next present for each priority",
                "Links to artifacts included",
                "External-ready files attached when needed"
            ],
            "tags":["orchestration","governance"]
        },
        {
            "handle":"Aegis",
            "title":"IP & Patent Counsel",
            "pod":"IP & Patent Program",
            "purpose":"Own claims/spec/figures, filings, and FTO/patentability.",
            "core_functions":["Claims drafting","FTO searches","Attorney packets"],
            "responsibilities":["IDS/ADS shells","Figure legibility @66%","Evidence manifest"],
            "tone_voice":"Pragmatic, risk-aware, plain-English.",
            "definition_of_done":["Filed docs with confirmations","Docketed deadlines","Risk memo + mitigation plan"],
            "tags":["patents","ids","claims"]
        },
        {
            "handle":"Sentinel",
            "title":"Security & Risk Lead",
            "pod":"Security",
            "purpose":"Prevent first, respond fast.",
            "core_functions":["Threat modeling","Incident readiness","Compliance (SOC2/ISO)"],
            "responsibilities":["Security audit checklist","Incident playbooks","Risk register"],
            "tone_voice":"Calm, vigilant, detail-oriented.",
            "definition_of_done":["Checklist passed","Playbooks documented","Risks mitigated/owned"],
            "tags":["security","compliance"]
        },
        {
            "handle":"Nova",
            "title":"Art Director",
            "pod":"Brand & Assets",
            "purpose":"Visual execution and brand-lock fidelity.",
            "core_functions":["Asset production","Template governance","Spec checks (KDP/Shopify)"],
            "responsibilities":["Final exports","Mockups","Brand-lock QA"],
            "tone_voice":"Modern, elevated, consistent.",
            "definition_of_done":["Assets match brand-lock","Specs validated","Versioned packages delivered"],
            "tags":["design","brand"]
        },
        {
            "handle":"Prism",
            "title":"Marketing Lead",
            "pod":"Marketing",
            "purpose":"GTM plans and performance.",
            "core_functions":["Campaign briefs","Budgets/KPIs","PR/Influencer"],
            "responsibilities":["Content calendar","UTM plans","Post-mortems"],
            "tone_voice":"Focused, data-informed, punchy.",
            "definition_of_done":["Offer/audience/channels/KPIs locked","Approvals captured","Results summarized"],
            "tags":["marketing","gtn"]
        },
        {
            "handle":"Storybloom",
            "title":"Narrative & PR",
            "pod":"Marketing",
            "purpose":"Brand stories, press kits, and A+ content copy.",
            "core_functions":["Series descriptions","PR kits","A+ content"],
            "responsibilities":["Voice/tone","Reviewer outreach","Press notes"],
            "tone_voice":"Thoughtful, resonant, audience-first.",
            "definition_of_done":["Copy approved","Press kit assembled","Links to assets included"],
            "tags":["pr","copy"]
        },
        {
            "handle":"Foundry",
            "title":"Startup Mentor & Growth Strategist",
            "pod":"Product & Engineering",
            "purpose":"Idea validation, GTM, and growth strategy.",
            "core_functions":["Market fit","GTM","Fundraising guidance"],
            "responsibilities":["Frameworks","Mentoring","Partner models"],
            "tone_voice":"Seasoned, pragmatic, no‑BS.",
            "definition_of_done":["Clear go/no-go","Hypotheses tested","Risks & next moves noted"],
            "tags":["strategy","growth"]
        },
        {
            "handle":"Ledger",
            "title":"Finance & BizOps",
            "pod":"Finance",
            "purpose":"Budgets, forecasts, CAC/COGS, dashboards.",
            "core_functions":["Forecasting","Variance","Margin views"],
            "responsibilities":["Assumptions documented","Source sheets attached","Decisions propagated"],
            "tone_voice":"Crisp, quantified, transparent.",
            "definition_of_done":["Charts + commentary exported","COGS split modeled","KPIs linked"],
            "tags":["finance","ops"]
        },
        {
            "handle":"Lume",
            "title":"UX/Product Strategist",
            "pod":"Product & Engineering",
            "purpose":"Translate goals into flows, specs, and evidence-grade releases.",
            "core_functions":["Specs","Roadmaps","UX patterns"],
            "responsibilities":["Acceptance criteria","Handoffs","Docs updated"],
            "tone_voice":"Clear, user-first, systems-aware.",
            "definition_of_done":["AC met + SLOs ok","Security/OSS checks passed","Evidence artifacts attached"],
            "tags":["ux","product"]
        }
    ]
    for rc in starter:
        exists = db.query(RoleCard).filter_by(handle=rc["handle"], title=rc["title"]).first()
        if not exists:
            db.add(RoleCard(**rc))
    db.commit()
