# Mailer — Consolidated Patch

This single file rolls up:
- Partials loader with **mtime-aware cache**
- **LRU caps** for partials (env-tunable: `PARTIAL_CACHE_MAX_DIRS`, `PARTIAL_CACHE_MAX_FILES`)
- **Safe HTML escaping** for `{{var}}`, with `{{{var}}}` unescaped
- Support for `{{> partial}}` and `{{#each items}} ... {{/each}}`

**Drop-in replacement:**
- `server/lib/mailer.ts`

**Env example**
```bash
PARTIAL_CACHE_MAX_DIRS=6 PARTIAL_CACHE_MAX_FILES=24 npm run start
```

**Usage**
```ts
import { renderTxEmailFromFile } from "./server/lib/mailer";

const html = renderTxEmailFromFile(
  "emails/tx/order_shipped.mjml",
  {
    orderId,
    etaDate: new Date(eta.etaDate).toLocaleDateString(),
    orderLink: `${appUrl}/orders/${orderId}`,        // {{{orderLink}}} if you embed html/hrefs
    brandHeaderUrl,                                   // {{{brandHeaderUrl}}} for <img src=...>
    brandName,
    lineItems: [{ thumbUrl, title, qty, price }],     // {{{thumbUrl}}} in partial for <img>
  },
  "emails/tx/partials"
);
```
