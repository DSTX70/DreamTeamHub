// server/lib/mailer.ts
// Consolidated: partials + caching (LRU, env caps) + escaping + triple braces + each + partials
import fs from "fs";
import path from "path";
import mjml2html from "mjml";

/** Simple HTML escape for safe text injection */
function escapeHtml(input: any): string {
  const s = String(input);
  return s
    .replaceAll(/&/g, "&amp;")
    .replaceAll(/</g, "&lt;")
    .replaceAll(/>/g, "&gt;")
    .replaceAll(/\"/g, "&quot;")
    .replaceAll(/'/g, "&#39;");
}

/** Env-configurable LRU caps */
const MAX_PARTIAL_DIRS = Math.max(1, parseInt(process.env.PARTIAL_CACHE_MAX_DIRS || "8", 10) || 8);
const MAX_FILES_PER_DIR = Math.max(1, parseInt(process.env.PARTIAL_CACHE_MAX_FILES || "32", 10) || 32);

type CacheEntry = { mtimeMs: number; content: string; at: number };
type DirCache = Record<string, CacheEntry>;
const PARTIAL_CACHE: Record<string, DirCache> = {};
let dirUseOrder: string[] = []; // LRU of dirs

function touchDir(dir: string) {
  const idx = dirUseOrder.indexOf(dir);
  if (idx !== -1) dirUseOrder.splice(idx, 1);
  dirUseOrder.unshift(dir);
  while (dirUseOrder.length > MAX_PARTIAL_DIRS) {
    const evict = dirUseOrder.pop();
    if (evict && PARTIAL_CACHE[evict]) delete PARTIAL_CACHE[evict];
  }
}

function pruneDirFiles(dir: string) {
  const cache = PARTIAL_CACHE[dir];
  const keys = Object.keys(cache);
  if (keys.length <= MAX_FILES_PER_DIR) return;
  // Evict least recently used files
  keys.sort((a,b) => cache[a].at - cache[b].at);
  const toRemove = keys.slice(0, keys.length - MAX_FILES_PER_DIR);
  for (const k of toRemove) delete cache[k];
}

function loadPartialsCached(dir: string): Record<string, string> {
  if (!fs.existsSync(dir)) return {};
  if (!PARTIAL_CACHE[dir]) PARTIAL_CACHE[dir] = {};
  touchDir(dir);

  const out: Record<string, string> = {};
  for (const filename of fs.readdirSync(dir)) {
    const filePath = path.join(dir, filename);
    const stat = fs.statSync(filePath);
    const key = path.basename(filename, path.extname(filename)); // header.mjml -> header

    const cache = PARTIAL_CACHE[dir];
    const entry = cache[filename];
    if (!entry || entry.mtimeMs !== stat.mtimeMs) {
      cache[filename] = { mtimeMs: stat.mtimeMs, content: fs.readFileSync(filePath, "utf-8"), at: Date.now() };
    } else {
      entry.at = Date.now();
    }
    out[key] = cache[filename].content;
  }

  pruneDirFiles(dir);
  return out;
}

function lookupPath(obj: any, dotted: string) {
  return dotted.split(".").reduce((acc: any, k: string) => (acc ? acc[k] : undefined), obj);
}

/**
 * Very small Handlebars-like expander for:
 *  - {{> partialName}}
 *  - {{#each arrayName}} ... {{/each}}
 *  - {{{var}}} (unescaped) and {{var}} (escaped) replacements
 */
function expandTemplate(input: string, vars: any, partials: Record<string, string>): string {
  let tpl = input;

  // 1) Expand top-level partials {{> name}}
  tpl = tpl.replace(/\{\{\>\s*([a-zA-Z0-9_\-]+)\s*\}\}/g, (_m, name) => partials[name] || "");

  // 2) Expand each-blocks
  tpl = tpl.replace(/\{\{#each\s+([a-zA-Z0-9_\.]+)\}\}([\s\S]*?)\{\{\/each\}\}/g, (_m, arrKey, inner) => {
    const arr = lookupPath(vars, arrKey);
    if (!Array.isArray(arr) || arr.length === 0) return "";
    return arr.map((item:any) => {
      // Nested partials inside loop
      let block = inner.replace(/\{\{\>\s*([a-zA-Z0-9_\-]+)\s*\}\}/g, (_m2, name2) => partials[name2] || "");

      // Triple-brace (unescaped) inside loop
      block = block.replace(/\{\{\{\s*([a-zA-Z0-9_\.]+)\s*\}\}\}/g, (_m3, key) => {
        const val = lookupPath(item, key);
        return (val !== undefined && val !== null) ? String(val) : "";
      });

      // Double-brace (escaped) inside loop
      block = block.replace(/\{\{\s*([a-zA-Z0-9_\.]+)\s*\}\}/g, (_m4, key) => {
        const val = lookupPath(item, key);
        return (val !== undefined && val !== null) ? escapeHtml(val) : "";
      });

      return block;
    }).join("");
  });

  // 3) Root triple-brace (unescaped) then double-brace (escaped)
  tpl = tpl.replace(/\{\{\{\s*([a-zA-Z0-9_\.]+)\s*\}\}\}/g, (_m, key) => {
    const val = lookupPath(vars, key);
    return (val !== undefined && val !== null) ? String(val) : "";
  });
  tpl = tpl.replace(/\{\{\s*([a-zA-Z0-9_\.]+)\s*\}\}/g, (_m, key) => {
    const val = lookupPath(vars, key);
    return (val !== undefined && val !== null) ? escapeHtml(val) : "";
  });

  return tpl;
}

/**
 * Render MJML from a template file with partials + escaping + caching.
 * @param mjmlPath main .mjml template path (e.g., emails/tx/order_shipped.mjml)
 * @param vars data object (etaDate, orderId, lineItems[], brandHeaderUrl, etc.)
 * @param partialsDir directory of .mjml partials (default emails/tx/partials)
 */
export function renderTxEmailFromFile(mjmlPath: string, vars: Record<string, any> = {}, partialsDir = "emails/tx/partials") {
  const raw = fs.readFileSync(mjmlPath, "utf-8");
  const partials = loadPartialsCached(partialsDir);
  const expanded = expandTemplate(raw, vars, partials);
  const { html, errors } = mjml2html(expanded, { validationLevel: "soft" });
  if (errors && errors.length) console.warn("[MJML] warnings:", errors);
  return html;
}

/**
 * Back-compat helper for rendering from a raw MJML string.
 * Triple braces are unescaped; double braces are escaped.
 */
export function renderTxEmail(mjmlTemplate: string, vars: Record<string, string|number> = {}) {
  let mjml = mjmlTemplate.replace(/\{\{\{\s*([a-zA-Z0-9_]+)\s*\}\}\}/g, (_m, key) => {
    const v = (vars as any)[key]; return v !== undefined && v !== null ? String(v) : "";
  });
  mjml = mjml.replace(/\{\{\s*([a-zA-Z0-9_]+)\s*\}\}/g, (_m, key) => {
    const v = (vars as any)[key]; return v !== undefined && v !== null ? escapeHtml(v) : "";
  });
  const { html, errors } = mjml2html(mjml, { validationLevel: "soft" });
  if (errors && errors.length) console.warn("[MJML] warnings:", errors);
  return html;
}
