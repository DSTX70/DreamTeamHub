# Env Matrix

| Variable | Required | Default | Where Used | Notes |
|---|---|---|---|---|
| `RBAC_API_KEY` | yes (prod) | — | RBAC middleware | Required to access admin/emit/presets routes |
| `REDIS_URL` | yes (prod) | `redis://localhost:6379` | Ops logs SSE | TLS/auth for prod |
| `OPS_LOGS_CHANNEL` | no | `ops:logs` | Ops logs SSE | Pub/sub channel |
| `S3_BUCKET` / `AWS_S3_BUCKET` | yes (if S3 probe) | — | `/api/healthz` | IAM `s3:ListBucket` required |
| `AWS_REGION` | yes (if S3 probe) | `us-east-1` | `/api/healthz` | Accepts `AWS_DEFAULT_REGION` |
| `SMTP_HOST` | yes (if SMTP probe) | — | `/api/healthz` | Optional `SMTP_PORT`, `SMTP_USER`, `SMTP_PASS` |
| `HEALTHZ_PROBE_TIMEOUT_MS` | no | `3000` | `/api/healthz` | Per-probe timeout |
| `HEALTHZ_GLOBAL_CAP_MS` | no | `2500` | `/api/healthz` | Total request cap |
| `HEALTHZ_CACHE_TTL_MS` | no | `7000` | `/api/healthz` | Result cache TTL |
| `DATABASE_URL` | yes | — | DB client | Used by DB layer/migrations |
| `GITHUB_SHA` / `RELEASE_TAG` / `GITHUB_ACTOR` | no | — | `/api/admin/deploy/mark` | Also accepted via JSON body |

**Tip:** keep all secrets in a vault (1Password/Secrets Manager), not in repo or CI logs.
