# Ops Runbooks

This folder contains short, actionable runbooks for the Ops Health + LLM Presets + Logs pod.

## 1) Health Probes
**Endpoints**
- Readiness: `GET /api/healthz`
- Liveness:  `GET /api/healthz/livez`

**What they mean**
- `db`: DB connection and trivial `SELECT 1`
- `s3`: S3 list probe (Bucket + Region required)
- `smtp`: SMTP handshake `transporter.verify()`

**Common failures & fixes**
- `db` fails → Check DB URL/creds, security groups, migrations.
- `s3` fails → Verify `S3_BUCKET`/`AWS_REGION`, IAM perms (`s3:ListBucket`).
- `smtp` fails → `SMTP_HOST`/PORT wrong or auth blocked; verify via Mailhog in dev.

**Global cap & cache**
- `HEALTHZ_GLOBAL_CAP_MS` caps total probe time (defaults 2500ms).
- `HEALTHZ_CACHE_TTL_MS` caches payload (defaults 7000ms) to avoid thundering herds.

**Playbooks**
- Spike in latency → Check deploy markers, DB saturation, S3 region issues.
- 503 on readiness → Inspect `checks[].details`; roll back if multiple probes failing.

## 2) Deploy Markers
**Endpoints**
- `POST /api/admin/deploy/mark` → record deploy (guarded by RBAC)
- `GET /api/admin/deploy/last` → fetch last marker

**Grafana**
- Add annotation query from `/api/admin/deploy/last` (or your TS series).

## 3) Ops Logs
**Streaming**
- SSE: `GET /api/ops/logs/stream` (Redis-backed in prod)
- Emit: `POST /api/ops/logs/emit` (guard + rate limit)

**Fallback**
- REST tail: `GET /api/ops/logs/rest?since=15m|1h|24h|epochMs`
- CSV export: `GET /api/ops/logs/csv`

**Quick triage**
- Error surge → Click `Err M` in Overview to filter logs; grep owner/kind.
- Redis down → Switch to REST tail; restart Redis; watch reconnects.

## 4) LLM Presets & Augment
**DB table**
- `llm_presets(family,label,tips,augment_lines,enabled,updated_at)`

**Endpoints**
- CRUD: `/api/llm/presets-db`
- Augment: `POST /api/llm/augment` → `{ augmented, tips }`

**Restore defaults**
- Re-run seed SQL: `server/db/seeds/20251107_llm_presets_seed.sql`

## 5) RBAC & Rate Limits
**Guards**
- `x-api-key` via `RBAC_API_KEY` for `/api/admin/*`, `/api/ops/logs/*`, `/api/llm/presets-db*`
- Rate limit `/emit` and `/deploy/mark` (default 30/min)

---

# Incident Checklist (TL;DR)
1. Confirm impact (user-facing vs internal).
2. Check `/api/healthz` and `/api/admin/deploy/last`.
3. Tail `/ops/logs-sse` or REST since=15m for errors.
4. Roll back or flip feature flag if needed.
5. Update Grafana annotation + start incident doc.
6. Post-mortem: add guardrails, tests, and alerts if missing.
