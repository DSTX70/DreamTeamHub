// server/routes/ops_logs_sse.route.ts
import type { Request, Response } from "express";
import { Router } from "express";
import type { OpsEvent } from "../../shared/types/ops";

const router = Router();

// Minimal in-memory broadcaster (replace with EventEmitter/Kafka/etc. in prod)
type Client = { id: number; res: Response };
const clients: Client[] = [];

function send(res: Response, data: any) {
  res.write(`data: ${JSON.stringify(data)}\n\n`);
}

let counter = 0;

// Client subscribe
router.get("/stream", (req: Request, res: Response) => {
  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache");
  res.setHeader("Connection", "keep-alive");
  res.flushHeaders();

  const id = ++counter;
  clients.push({ id, res });

  req.on("close", () => {
    const idx = clients.findIndex(c => c.id === id);
    if (idx >= 0) clients.splice(idx, 1);
  });

  // initial hello
  send(res, { hello: true, ts: new Date().toISOString() });
});

// Broadcast endpoint that ops emitters can call (optional)
router.post("/emit", (req: Request, res: Response) => {
  const evt = req.body as OpsEvent;
  for (const c of clients) send(c.res, { event: evt });
  res.json({ ok: true, sent: clients.length });
});

export default router;
