# ship_ops_logs_sse_and_filters

Adds Server-Sent Events (SSE) stream for ops logs, quick time filters and JSON-copy on the client, and turns the Overview error counter into a deep link.

## Server
- Route: `server/routes/ops_logs_sse.route.ts`
```ts
import opsLogsSseRouter from "./routes/ops_logs_sse.route";
app.use("/api/ops/logs", express.json(), opsLogsSseRouter);
```
- POST `/api/ops/logs/emit` to broadcast an event to connected clients (optional — you can also wire your existing emitter to call this internally).

## Client
- Page: `client/src/pages/ops/LogsSSE.tsx` (uses EventSource to `/api/ops/logs/stream`)
- The per-line copy now uses **Copy as JSON**.
- Quick time filter: 15m / 1h / 24h / All.

## Overview deep link
- Apply `patches/ops_overview_error_link.diff` to make the `Err M` counter link to `/ops/logs?level=error`.

## Notes
- Replace the in-memory broadcaster with your event pipeline in production.
- Keep the polling `/ops/logs` page as a fallback; this SSE page is an alternative when you want instant streaming.
