// client/src/pages/ops/LogsSSE.tsx
import React, { useEffect, useMemo, useRef, useState } from "react";
import CopyBtn from "../../components/ops/CopyBtn";
import type { OpsEvent } from "../../../shared/types/ops";

type Since = "15m" | "1h" | "24h" | "";

function parseSince(s: Since): number | null {
  const now = Date.now();
  if (s === "15m") return now - 15*60*1000;
  if (s === "1h") return now - 60*60*1000;
  if (s === "24h") return now - 24*60*60*1000;
  return null;
}

export default function OpsLogsSSEPage() {
  const [level, setLevel] = useState<string>("");
  const [owner, setOwner] = useState<string>("");
  const [kind, setKind] = useState<string>("");
  const [since, setSince] = useState<Since>("15m");

  const [events, setEvents] = useState<OpsEvent[]>([]);
  const cutoff = useMemo(() => parseSince(since), [since]);

  useEffect(() => {
    const es = new EventSource("/api/ops/logs/stream");
    es.onmessage = (msg) => {
      try {
        const payload = JSON.parse(msg.data);
        if (payload?.event) {
          setEvents(prev => {
            const next = prev.concat(payload.event as OpsEvent);
            return next.slice(-5000);
          });
        }
      } catch {}
    };
    return () => es.close();
  }, []);

  const filtered = events.filter(e => {
    if (level && e.level !== level) return false;
    if (owner && e.owner !== owner) return false;
    if (kind && e.kind !== kind) return false;
    if (cutoff && new Date(e.ts).getTime() < cutoff) return false;
    return true;
  });

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-2">
        <select className="rounded border px-2 py-1 text-sm" value={since} onChange={(e) => setSince(e.target.value as Since)}>
          <option value="15m">Last 15m</option>
          <option value="1h">Last 1h</option>
          <option value="24h">Last 24h</option>
          <option value="">All</option>
        </select>
        <select className="rounded border px-2 py-1 text-sm" value={level} onChange={(e) => setLevel(e.target.value)}>
          <option value="">All levels</option>
          <option value="info">info</option>
          <option value="warn">warn</option>
          <option value="error">error</option>
        </select>
        <input className="rounded border px-2 py-1 text-sm" placeholder="owner" value={owner} onChange={(e) => setOwner(e.target.value)} />
        <input className="rounded border px-2 py-1 text-sm" placeholder="kind" value={kind} onChange={(e) => setKind(e.target.value)} />
      </div>

      <div className="rounded-xl border">
        <div className="grid grid-cols-12 border-b bg-gray-50 p-2 text-xs font-semibold">
          <div className="col-span-2">Time</div>
          <div className="col-span-1">Lvl</div>
          <div className="col-span-2">Kind</div>
          <div className="col-span-2">Owner</div>
          <div className="col-span-4">Message</div>
          <div className="col-span-1 text-right">Copy</div>
        </div>
        <div className="max-h-[60vh] overflow-auto text-xs">
          {filtered.map((e) => (
            <div key={e.id} className="grid grid-cols-12 items-start border-b p-2">
              <div className="col-span-2 font-mono">{new Date(e.ts).toLocaleString()}</div>
              <div className="col-span-1">{e.level}</div>
              <div className="col-span-2">{e.kind}</div>
              <div className="col-span-2">{e.owner || ""}</div>
              <div className="col-span-4 break-words">{e.msg}</div>
              <div className="col-span-1 text-right">
                <CopyBtn text={JSON.stringify(e)} />
              </div>
            </div>
          ))}
          {!filtered.length && <div className="p-3 text-gray-500">No events</div>}
        </div>
      </div>
    </div>
  );
}
