# Low-Stock Scheduler (DB-backed) + Notifiers (Slack webhook / Email)

**Date:** 2025-11-06

This drop backfills the scheduler to use the DB DAOs and adds tiny notifiers:
- Webhook notifier (Slack-compatible): POSTs a JSON payload to WEBHOOK_URL.
- Email notifier (optional, via nodemailer) for quick alerts.

Mix-and-match notifiers when starting the scheduler.

## Files

Scheduler
- server/scheduler/lowStockScheduler.db.ts — startLowStockSchedulerDB(opts).

Notifiers
- server/notifiers/types.ts — Notifier interface.
- server/notifiers/webhook.ts — simple HTTP POST (Slack-compatible).
- server/notifiers/email.ts — optional nodemailer-based email notifier.

Routes (utility)
- server/routes/inventory.scheduler.route.ts — POST /api/ops/inventory/scan-now.

Env
- .env.example — webhook + SMTP examples.

## Install (email notifier optional)
pnpm add nodemailer

## Wire up (example)
server/index.ts:
  import {{ startLowStockSchedulerDB }} from "./server/scheduler/lowStockScheduler.db";
  import {{ webhookNotifier }} from "./server/notifiers/webhook";
  import {{ emailNotifier }} from "./server/notifiers/email";

  const notifiers = [
    webhookNotifier({{ url: process.env.SLACK_WEBHOOK_URL }}),
    emailNotifier({{
      enabled: !!process.env.SMTP_HOST,
      from: process.env.EMAIL_FROM!,
      to: process.env.EMAIL_TO!,
      transport: {{ host: process.env.SMTP_HOST!, port: Number(process.env.SMTP_PORT || 587), secure: false, auth: {{ user: process.env.SMTP_USER!, pass: process.env.SMTP_PASS! }} }}
    }})
  ].filter(Boolean) as any[];

  startLowStockSchedulerDB({{ intervalMs: 60_000, notifiers }});

(Manual scan route)
server/app.ts:
  app.use(require("./server/routes/inventory.scheduler.route").router);

## Payload
Notifiers receive: {{ kind: "low-stock", sku, stock, threshold, at: ISO }}.

## Notes
- De-dup key is sku:stock to prevent duplicates when stock hasn’t changed.
- Extend webhook.ts to sign payloads or map to Slack blocks if needed.
