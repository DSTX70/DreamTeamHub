This bundle doesn't include unit tests for the scheduler because it is time-based and integration-heavy.
You can exercise the manual scan route after seeding products to see events fire.
