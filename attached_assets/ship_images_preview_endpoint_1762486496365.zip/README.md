# Images — In‑Memory Preview Endpoint

Date: 2025-11-07

Adds POST /api/ops/images/preview which runs the Sharp transformer in memory and returns projected sizes.

Fields: file (required), sizes CSV (optional), avifQ, webpQ, jpgQ (optional).

Mount: app.use(require("./server/routes/images.preview.route").router);
