# Dream Team Hub — Starter

Monorepo scaffold: **FastAPI** backend + **Vite React** frontend.

## Quick Start (Replit)
1) Create a new **Replit** from **"Python"** (for the backend).
2) Upload this ZIP and extract in the Replit workspace root.
3) Open the `backend/` folder in the Replit tree and run: `pip install -r requirements.txt`
4) In the Replit **Shell**, run:
   ```bash
   cd backend
   uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
   ```
5) In a new Replit **tab** or a local terminal, you can run the frontend (optional in Replit; many run just the API first):
   ```bash
   cd frontend
   npm install
   npm run dev -- --host
   ```
6) Visit the backend docs at: `https://<your-repl-url>/docs` (FastAPI Swagger).
7) Visit the frontend dev server URL (shown by Vite).

> **Note:** For a single-repl approach, you can initially use just the backend and hit JSON endpoints.
> Frontend is optional for first boot.

## Env
Copy `backend/.env.sample` → `backend/.env` and set values.
If you later move to Supabase/Postgres, update `DATABASE_URL` accordingly.

## Modules included
- Control Tower (Top-5, Escalations, Assignments)
- Brainstorm Studio (multi-pod ideation with roles)
- Audit Engine (cross-pod checklists + evidence list)
- Decision Log (immutable entries)
- Intake & Routing (basic)

## DB: SQLite (dev)
A simple SQLite file is used by default. Tables are defined with SQLAlchemy.
You can migrate to Postgres later.
