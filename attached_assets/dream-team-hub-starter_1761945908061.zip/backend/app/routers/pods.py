from fastapi import APIRouter, Depends
from pydantic import BaseModel
from sqlalchemy.orm import Session
from ..db.init import get_db
from ..db.models import Pod, Person

router = APIRouter()

class PodIn(BaseModel):
    name: str
    charter: str = ""
    owners: list[str] = []
    thread_id: str = ""

@router.post("")
def create_pod(body: PodIn, db: Session = Depends(get_db)):
    p = Pod(name=body.name, charter=body.charter, owners=body.owners, thread_id=body.thread_id)
    db.add(p); db.commit(); db.refresh(p)
    return {"id": p.id, "name": p.name}

@router.get("")
def list_pods(db: Session = Depends(get_db)):
    rows = db.query(Pod).all()
    return {"items":[{"id":r.id,"name":r.name,"owners":r.owners} for r in rows]}

class PersonIn(BaseModel):
    handle: str
    name: str = ""
    roles: list[str] = []
    pod_id: int | None = None
    contact: str = ""

@router.post("/persons")
def create_person(body: PersonIn, db: Session = Depends(get_db)):
    person = Person(handle=body.handle, name=body.name, roles=body.roles, pod_id=body.pod_id, contact=body.contact)
    db.add(person); db.commit(); db.refresh(person)
    return {"id": person.id, "handle": person.handle}

@router.get("/persons")
def list_persons(db: Session = Depends(get_db)):
    rows = db.query(Person).all()
    return {"items":[{"id":r.id,"handle":r.handle,"roles":r.roles,"pod_id":r.pod_id} for r in rows]}
