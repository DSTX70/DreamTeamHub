from sqlalchemy import Column, Integer, String, Text, DateTime, Boolean, ForeignKey, JSON
from sqlalchemy.orm import relationship
from .init import Base
import datetime

class Pod(Base):
    __tablename__ = "pods"
    id = Column(Integer, primary_key=True)
    name = Column(String, unique=True, nullable=False)
    charter = Column(Text, default="")
    owners = Column(JSON, default=list) # list of person handles
    thread_id = Column(String, default="") # external chat thread id

class Person(Base):
    __tablename__ = "persons"
    id = Column(Integer, primary_key=True)
    handle = Column(String, unique=True, nullable=False) # e.g., Prism, Aegis
    name = Column(String, default="")
    roles = Column(JSON, default=list)
    pod_id = Column(Integer, ForeignKey("pods.id"))
    contact = Column(String, default="")
    pod = relationship("Pod", backref="members")

class WorkItem(Base):
    __tablename__ = "work_items"
    id = Column(Integer, primary_key=True)
    title = Column(String, nullable=False)
    pod_id = Column(Integer, ForeignKey("pods.id"))
    owner_id = Column(Integer, ForeignKey("persons.id"))
    status = Column(String, default="new") # new, in_flight, review, done
    due = Column(String, default="")
    milestone = Column(String, default="draft") # draft, styled, final
    source_links = Column(JSON, default=list)
    pod = relationship("Pod")
    owner = relationship("Person")

class Decision(Base):
    __tablename__ = "decisions"
    id = Column(Integer, primary_key=True)
    summary = Column(Text, nullable=False)
    rationale = Column(Text, default="")
    approver = Column(String, default="")
    effective_at = Column(String, default="")
    status = Column(String, default="active") # active, superseded
    links = Column(JSON, default=list)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

class Event(Base):
    __tablename__ = "events"
    id = Column(Integer, primary_key=True)
    type = Column(String, nullable=False)
    ts = Column(DateTime, default=datetime.datetime.utcnow)
    actor = Column(String, default="system")
    payload = Column(JSON, default=dict)

class BrainstormSession(Base):
    __tablename__ = "brainstorm_sessions"
    id = Column(Integer, primary_key=True)
    title = Column(String, nullable=False)
    goal = Column(Text, default="")
    facilitator_id = Column(Integer, ForeignKey("persons.id"))
    status = Column(String, default="draft") # draft, running, committed
    started_at = Column(String, default="")
    ended_at = Column(String, default="")

class BrainstormIdea(Base):
    __tablename__ = "brainstorm_ideas"
    id = Column(Integer, primary_key=True)
    session_id = Column(Integer, ForeignKey("brainstorm_sessions.id"))
    author_id = Column(Integer, ForeignKey("persons.id"))
    text = Column(Text, nullable=False)
    tags = Column(JSON, default=list)
    cluster_id = Column(Integer, default=0)
    score_json = Column(JSON, default=dict)
    status = Column(String, default="open")

class Audit(Base):
    __tablename__ = "audits"
    id = Column(Integer, primary_key=True)
    title = Column(String, nullable=False)
    type = Column(String, nullable=False) # security_soc2_spot, brand_lock, ip_readiness, finance_ops
    facilitator_id = Column(Integer, ForeignKey("persons.id"))
    status = Column(String, default="open")
    due_at = Column(String, default="")
    pods = Column(JSON, default=list)  # ["Security","Product"]

class AuditCheck(Base):
    __tablename__ = "audit_checks"
    id = Column(Integer, primary_key=True)
    audit_id = Column(Integer, ForeignKey("audits.id"))
    key = Column(String, nullable=False)
    title = Column(String, nullable=False)
    severity = Column(String, default="medium")
    owner_id = Column(Integer, ForeignKey("persons.id"))
    status = Column(String, default="pending") # pending, pass, fail
    notes = Column(Text, default="")

class AuditFinding(Base):
    __tablename__ = "audit_findings"
    id = Column(Integer, primary_key=True)
    audit_id = Column(Integer, ForeignKey("audits.id"))
    check_id = Column(Integer, ForeignKey("audit_checks.id"))
    summary = Column(Text, default="")
    severity = Column(String, default="medium")
    recommendation = Column(Text, default="")
