from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from .routers import control_tower, brainstorm, audits, decisions, intake, pods

app = FastAPI(title="Dream Team Hub API", version="0.1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Routers
app.include_router(control_tower.router, prefix="/control", tags=["control-tower"])
app.include_router(brainstorm.router, prefix="/brainstorm", tags=["brainstorm"])
app.include_router(audits.router, prefix="/audits", tags=["audits"])
app.include_router(decisions.router, prefix="/decisions", tags=["decisions"])
app.include_router(intake.router, prefix="/intake", tags=["intake"])
app.include_router(pods.router, prefix="/pods", tags=["pods & roster"])

@app.get("/", tags=["root"])
def root():
    return {"ok": True, "service": "Dream Team Hub API", "version": "0.1.0"}
