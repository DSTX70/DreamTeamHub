# Patch: LRU Partial Cache + Triple-Brace Unescaped Vars

**What’s new**
- **LRU-capped partial cache**: limits to 8 directories and 32 files per directory (oldest evicted automatically). mtime-aware to refresh when files change.
- **Triple-brace `{{{var}}}` support**: insert unescaped values (e.g., trusted URLs or HTML snippets) at both root and inside `#each`. Double-brace `{{var}}` remains **escaped**.

**File updated**
- `server/lib/mailer.ts`

**Notes**
- Use triple braces *only* for trusted content you control (e.g., image src, anchors). Keep user content with double braces.
