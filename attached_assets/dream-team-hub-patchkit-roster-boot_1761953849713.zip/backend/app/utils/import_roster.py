from __future__ import annotations
import json, os
from sqlalchemy.orm import Session
from app.db.init import SessionLocal
from app.db.models import RoleCard

ROSTER_PATH = os.getenv("ROSTER_JSON_PATH", "backend/data/dream_team_roster_full.json")

def upsert_role(db: Session, rec: dict):
    handle = rec.get("handle")
    title = rec.get("title")
    existing = db.query(RoleCard).filter(RoleCard.handle==handle, RoleCard.title==title).first()
    if existing:
        for k,v in rec.items():
            if hasattr(existing, k) and k not in ("id",):
                setattr(existing, k, v)
        return existing, False
    rc = RoleCard(**rec)
    db.add(rc)
    return rc, True

def import_roster():
    path = ROSTER_PATH
    if not os.path.exists(path):
        return {"ok": False, "error": f"Roster file not found: {path}"}
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    db = SessionLocal()
    created = 0; updated = 0
    try:
        for rec in data:
            payload = {
                "handle": rec.get("handle",""),
                "title": rec.get("title",""),
                "pod": rec.get("pod",""),
                "purpose": rec.get("purpose",""),
                "core_functions": rec.get("core_functions",[]),
                "responsibilities": rec.get("responsibilities",[]),
                "definition_of_done": rec.get("definition_of_done",[]),
                "tone_voice": "",
                "links": rec.get("links",[]),
                "tags": rec.get("tags",[]),
            }
            _, is_new = upsert_role(db, payload)
            if is_new: created += 1
            else: updated += 1
        db.commit()
    except Exception as e:
        db.rollback()
        return {"ok": False, "error": str(e)}
    finally:
        db.close()
    return {"ok": True, "created": created, "updated": updated}
