# One-shot CLI to import the roster JSON into the DB.
from app.db.create_db import init_db
from app.utils.import_roster import import_roster

if __name__ == "__main__":
    init_db()
    print(import_roster())
