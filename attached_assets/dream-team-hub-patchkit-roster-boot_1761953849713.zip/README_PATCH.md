# Dream Team Hub — Patch Kit (Roster Auto-Import)

This kit embeds the **Dream Team roster** and adds an **auto-import** utility so your Replit app can populate Role Cards on boot.

## What’s inside
```
backend/
  data/
    dream_team_roster_full.json
    dream_team_roster_full.csv
  app/
    utils/
      import_roster.py     # idempotent import utility
  import_roster.py         # one-shot CLI to import manually
```

## How to apply (copy these into your Replit repo)
1. Drop the folders in this zip into your repo root (merge into existing `backend/`).
2. Ensure your project already has these files from the starter:
   - `backend/app/db/init.py`, `backend/app/db/models.py` (includes RoleCard model)
   - `backend/app/main.py` (FastAPI app)
3. Add this **startup hook** to `backend/app/main.py` (bottom of file is fine):

```python
# --- Optional: import roster on boot (idempotent) ---
import os
from app.db.create_db import init_db
from app.utils.import_roster import import_roster

@app.on_event("startup")
def startup_seed():
    # Ensure tables exist
    init_db()
    if os.getenv("IMPORT_ROSTER_ON_BOOT", "0") in ("1","true","True","YES","yes"):
        res = import_roster()
        print("[boot] roster import:", res)
```

4. Add these to your `.env` (or Replit Secrets):
```
IMPORT_ROSTER_ON_BOOT=1
ROSTER_JSON_PATH=backend/data/dream_team_roster_full.json
```

5. **Run it**
   - API boot will import automatically (idempotent).
   - Or run the CLI once:
     ```bash
     cd backend
     python import_roster.py
     ```

## Notes
- Import is **idempotent** (handle+title). Re-running updates existing entries.
- `pod_color`, `icon`, `thread_id` are UI/integration fields — keep those in your app DB or UI layer as needed.
- If you renamed directories, adjust `ROSTER_JSON_PATH` accordingly.
