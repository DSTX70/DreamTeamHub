# Ops Dropdown — Hotkeys "?" Tooltip

**Date:** 2025-11-06

Adds a tiny **"?"** tooltip inside the Ops dropdown that lists the keyboard combos:
- g o → /ops/overview
- g i → /ops/inventory
- g m → /ops/images
- g a → /ops/affiliates
- g s → /ops/settings

## Files
- client/src/components/Tooltip.tsx — lightweight tooltip.
- client/src/components/HeaderOpsMenu.tsx — updated dropdown with "?" hint.

Drop-in: replace your existing `HeaderOpsMenu.tsx` with this one and add `Tooltip.tsx`.
