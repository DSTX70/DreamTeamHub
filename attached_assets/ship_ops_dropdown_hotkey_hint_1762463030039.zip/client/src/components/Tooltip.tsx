import React from "react";

const Tooltip: React.FC<{ content: React.ReactNode; children: React.ReactNode }> = ({ content, children }) => {
  const [open, setOpen] = React.useState(false);
  return (
    <span className="relative inline-block">
      <span
        onMouseEnter={() => setOpen(true)}
        onMouseLeave={() => setOpen(false)}
        className="inline-flex items-center justify-center w-5 h-5 rounded-full border text-xs cursor-default select-none"
        aria-label="Keyboard shortcuts"
        title="Keyboard shortcuts"
      >
        ?
      </span>
      {open && (
        <div className="absolute right-0 mt-2 w-56 bg-white border rounded-lg shadow-lg p-2 text-xs z-50">
          {content}
        </div>
      )}
    </span>
  );
};

export default Tooltip;
