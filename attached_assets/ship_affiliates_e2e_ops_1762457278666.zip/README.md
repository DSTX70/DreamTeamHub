# Ship: Affiliate E2E & Ops Report Polish

This drop finishes the affiliate flow:
- **Attribution** during checkout with IP+email+UA heuristic
- **Ops report UI** with filters (date/code/owner), totals, CSV export
- **Routes** for JSON report, CSV, and code management

## Mount
```ts
app.use(require("./server/routes/affiliate.route").router);
```
(If you haven't already) also mount:
```ts
import cookieParser from "cookie-parser";
import { captureAffiliateFromQuery } from "./server/middleware/affiliateCookie";
app.use(cookieParser());
app.use(captureAffiliateFromQuery);
```

## Client Router
Add a route for `/ops/affiliates` that renders `client/src/pages/ops/AffiliatesReport.tsx`.

## Notes
- In-memory stores are used here for demo; DB migrations will replace them later.
- CSV mirrors the filtered result set; JSON adds aggregate totals.
