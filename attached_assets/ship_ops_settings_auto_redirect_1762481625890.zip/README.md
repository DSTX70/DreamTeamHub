# /ops/settings — Auto-Redirect by Role

Date: 2025-11-07

Adds an index component that redirects `/ops/settings` to:
- `/ops/settings/global` if the user has ops_admin
- otherwise `/ops/settings/alerts` if the user has ops_editor
- otherwise shows a friendly "no access" note

Router usage:
<Route path="/ops/settings/*" element={<SettingsLayout />}>
  <Route index element={<SettingsIndexRedirect />} />
  <Route path="alerts" element={<RequireRole roles={['ops_editor','ops_admin']}><SettingsAlerts/></RequireRole>} />
  <Route path="global" element={<RequireRole roles={['ops_admin']}><SettingsGlobal/></RequireRole>} />
</Route>
