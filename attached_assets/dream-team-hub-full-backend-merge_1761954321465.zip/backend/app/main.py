from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.routers import control_tower, brainstorm, audits, decisions, intake, pods, roles, agents
from app.db.create_db import init_db
from app.utils.import_roster import import_roster
from app.agents.registry import load_all_specs

app = FastAPI(title="Dream Team Hub API", version="0.2.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])

# Routers
app.include_router(control_tower.router, prefix="/control", tags=["control-tower"])
app.include_router(brainstorm.router, prefix="/brainstorm", tags=["brainstorm"])
app.include_router(audits.router, prefix="/audits", tags=["audits"])
app.include_router(decisions.router, prefix="/decisions", tags=["decisions"])
app.include_router(intake.router, prefix="/intake", tags=["intake"])
app.include_router(pods.router, prefix="/pods", tags=["pods & roster"])
app.include_router(roles.router, prefix="/roles", tags=["roles & raci"])
app.include_router(agents.router, prefix="/agents", tags=["agents"])

@app.on_event("startup")
def startup():
    init_db()
    load_all_specs()
    import os
    if os.getenv("IMPORT_ROSTER_ON_BOOT", "0").lower() in ("1","true","yes"):
        print("[boot] roster import:", import_roster())

@app.get("/", tags=["root"])
def root(): return {"ok": True, "service": "Dream Team Hub API", "version": "0.2.0"}
