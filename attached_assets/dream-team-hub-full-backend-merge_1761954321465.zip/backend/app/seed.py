from .db.init import SessionLocal
from .db.create_db import init_db
from .db.models import Pod, Person, RoleCard

def seed():
    init_db()
    db = SessionLocal()
    pods = ["Control Tower","Intake & Routing","Decision Log","IP & Patent Program","Marketing & Comms","Product & Engineering","Brand & Assets","Finance & BizOps","Security & Compliance","Roster"]
    for name in pods:
        if not db.query(Pod).filter_by(name=name).first():
            db.add(Pod(name=name, charter=f"Canonical thread for {name}", owners=["OS"]))
    if not db.query(Person).filter_by(handle="OS").first():
        db.add(Person(handle="OS", name="Orchestrator", roles=["admin"]))
    db.commit(); db.close()
if __name__ == "__main__":
    seed()
