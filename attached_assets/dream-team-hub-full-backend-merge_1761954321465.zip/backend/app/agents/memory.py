from __future__ import annotations
import datetime, json
from typing import List, Dict, Any
from app.db.init import SessionLocal
from app.db.models import AgentMemory, AgentRun

def add_memory(handle: str, kind: str, content: str, score:int=0, meta:Dict[str,Any]|None=None):
    db = SessionLocal()
    try:
        rec = AgentMemory(handle=handle, kind=kind, content=content, score=score, meta=meta or {})
        db.add(rec); db.commit(); db.refresh(rec)
        return {"ok": True, "id": rec.id}
    finally:
        db.close()

def list_memories(handle:str, limit:int=20, kinds:List[str]|None=None):
    db = SessionLocal()
    try:
        q = db.query(AgentMemory).filter(AgentMemory.handle==handle).order_by(AgentMemory.created_at.desc())
        if kinds:
            q = q.filter(AgentMemory.kind.in_(kinds))
        rows = q.limit(limit).all()
        return [{
            "id":r.id,"kind":r.kind,"content":r.content,"score":r.score,
            "meta":r.meta,"created_at":r.created_at.isoformat()
        } for r in rows]
    finally:
        db.close()

def record_run(handle:str, task:str, links:list, output:str):
    db = SessionLocal()
    try:
        rec = AgentRun(handle=handle, task=task, links=links or [], output=output)
        db.add(rec); db.commit(); db.refresh(rec)
        return {"ok": True, "id": rec.id}
    finally:
        db.close()

def recent_context(handle:str, k:int=5):
    db = SessionLocal()
    try:
        runs = db.query(AgentRun).filter(AgentRun.handle==handle).order_by(AgentRun.created_at.desc()).limit(k).all()
        notes = db.query(AgentMemory).filter(AgentMemory.handle==handle).order_by(AgentMemory.score.desc(), AgentMemory.created_at.desc()).limit(k).all()
        return {
            "recent_runs":[{"task":r.task,"output":(r.output[:4000]+"…") if len(r.output)>4000 else r.output} for r in runs],
            "notes":[{"kind":n.kind,"content":n.content,"score":n.score} for n in notes]
        }
    finally:
        db.close()
