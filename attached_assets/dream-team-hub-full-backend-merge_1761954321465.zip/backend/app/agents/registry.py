import json, os, glob
from app.routers.agents import AGENTS, AgentSpec
def load_all_specs(spec_dir="backend/app/agents/specs"):
    for path in glob.glob(os.path.join(spec_dir, "*.json")):
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f); AGENTS[data["handle"]] = AgentSpec(**data)
    return {"ok": True, "count": len(AGENTS)}
