def threads_post(thread_id:str, content:str, meta:dict|None=None):
    print("[threads.post]", {"thread_id":thread_id, "content":content[:200] + ("…" if len(content)>200 else ""), "meta":meta or {}})
    return {"ok": True, "thread_id": thread_id}
