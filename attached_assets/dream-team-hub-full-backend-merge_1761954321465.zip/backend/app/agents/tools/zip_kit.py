import zipfile, os, hashlib
from pathlib import Path
def _hash(path:str)->str:
    h=hashlib.sha256()
    with open(path,"rb") as f:
        for chunk in iter(lambda:f.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()
def zip_kit(file_paths:list[str], out_zip:str):
    out = Path(out_zip); out.parent.mkdir(parents=True, exist_ok=True)
    manifest = []
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        for p in file_paths:
            if os.path.exists(p):
                z.write(p, os.path.basename(p))
                manifest.append((os.path.basename(p), _hash(p)))
    idx = out.with_suffix(".INDEX.txt")
    with open(idx, "w", encoding="utf-8") as f:
        for name, digest in manifest: f.write(f"{digest}  {name}\n")
    return {"ok": True, "zip": str(out), "index": str(idx)}
