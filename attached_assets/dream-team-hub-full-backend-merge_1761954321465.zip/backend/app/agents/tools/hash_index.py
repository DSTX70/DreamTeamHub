import hashlib
def hash_index(items: list[dict]):
    out = []
    for it in items:
        b = (it.get("bytes","") or "").encode("utf-8")
        out.append({"name":it.get("name","item"), "sha256": hashlib.sha256(b).hexdigest()})
    return {"items": out}
