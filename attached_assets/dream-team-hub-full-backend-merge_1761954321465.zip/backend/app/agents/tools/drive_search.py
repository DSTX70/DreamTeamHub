def drive_search(query:str):
    return {"items":[{"name":"Spec_v1.pdf","path":"drive://Specs/Spec_v1.pdf"}]}
