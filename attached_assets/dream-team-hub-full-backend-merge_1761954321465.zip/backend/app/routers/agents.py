from __future__ import annotations
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from typing import List, Dict, Any
import os, json
from app.db.init import get_db
from sqlalchemy.orm import Session
from app.agents.memory import add_memory, list_memories, record_run, recent_context
from app.agents.tools.threads_post import threads_post

USE_OPENAI = os.getenv("USE_OPENAI", "0").lower() in ("1","true","yes")
LLM_MODEL = os.getenv("LLM_MODEL", "gpt-4o-mini")
client = None
if USE_OPENAI:
    try:
        from openai import OpenAI
        client = OpenAI()
    except Exception:
        client = None

router = APIRouter()

class AgentSpec(BaseModel):
    handle: str; title: str; pod: str; thread_id: str = ""
    system_prompt: str; instruction_blocks: List[str] = []; tools: List[str] = []
    policies: Dict[str, Any] = {}

AGENTS: Dict[str, AgentSpec] = {}

class RunInput(BaseModel):
    agent: str; task: str; links: List[str] = []; post_to_thread: bool = False

class FeedbackIn(BaseModel):
    agent: str; feedback: str; score: int = 0; kind: str = "feedback"

@router.get("")
def list_agents(): return {"agents": list(AGENTS.values())}

@router.post("")
def upsert_agent(spec: AgentSpec):
    AGENTS[spec.handle] = spec; return {"ok": True, "handle": spec.handle}

def _compose_prompt(spec: AgentSpec, task:str):
    ctx = recent_context(spec.handle, k=5)
    blocks = "\n\n".join(spec.instruction_blocks or [])
    context_txt = "Recent notes & runs (for learning):\n" + json.dumps(ctx, ensure_ascii=False, indent=2)
    return f"""{spec.system_prompt}

{blocks}

{context_txt}

Task: {task}

Output: deliver concise, concrete steps or artifacts; include links if provided; apply Definition of Done for your role.
"""

def _llm_call(prompt:str):
    if client:
        try:
            completion = client.chat.completions.create(
                model=LLM_MODEL,
                messages=[{"role":"system","content":"You are a helpful expert agent."},
                          {"role":"user","content":prompt}],
                temperature=0.25,
            )
            return completion.choices[0].message.content
        except Exception as e:
            return "[LLM error] " + str(e) + "\n\nECHO:\n" + prompt[:2000]
    return "[stubbed LLM]\n" + prompt[:2000]

@router.post("/run")
def run_agent(body: RunInput, db: Session = Depends(get_db)):
    spec = AGENTS.get(body.agent)
    if not spec: raise HTTPException(404, f"Unknown agent: {body.agent}")
    prompt = _llm_call(_compose_prompt(spec, body.task))
    record_run(spec.handle, body.task, body.links, prompt)
    if body.post_to_thread and spec.thread_id: threads_post(spec.thread_id, prompt, {"task": body.task})
    return {"ok": True, "agent": spec.handle, "output": prompt}

@router.post("/feedback")
def add_feedback(body: FeedbackIn):
    add_memory(body.agent, body.kind, body.feedback, body.score); return {"ok": True}

@router.get("/{handle}/memory")
def get_memory(handle:str, limit:int=20): return {"items": list_memories(handle, limit=limit)}
