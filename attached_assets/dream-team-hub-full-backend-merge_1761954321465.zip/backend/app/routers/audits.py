from fastapi import APIRouter, Depends
from pydantic import BaseModel
from sqlalchemy.orm import Session
from app.db.init import get_db
from app.db.models import Audit, AuditCheck
router = APIRouter()
class AuditCreate(BaseModel):
    title: str; type: str; pods: list[str] = []
@router.post("")
def create_audit(body: AuditCreate, db: Session = Depends(get_db)):
    a = Audit(title=body.title, type=body.type, pods=body.pods); db.add(a); db.commit(); db.refresh(a)
    return {"id": a.id, "title": a.title, "type": a.type, "status": a.status}
class CheckCreate(BaseModel):
    key: str; title: str; severity: str = "medium"
@router.post("/{audit_id}/checks")
def add_check(audit_id: int, body: CheckCreate, db: Session = Depends(get_db)):
    chk = AuditCheck(audit_id=audit_id, key=body.key, title=body.title, severity=body.severity); db.add(chk); db.commit(); db.refresh(chk)
    return {"id": chk.id, "key": chk.key, "title": chk.title, "severity": chk.severity}
