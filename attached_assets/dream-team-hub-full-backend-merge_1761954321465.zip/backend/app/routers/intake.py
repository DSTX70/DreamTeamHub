from fastapi import APIRouter, Depends
from pydantic import BaseModel
from sqlalchemy.orm import Session
from app.db.init import get_db
from app.db.models import WorkItem
router = APIRouter()
class IntakeIn(BaseModel):
    title: str; pod_id: int | None = None; owner_id: int | None = None; due: str = ""; source_links: list[str] = []
@router.post("")
def create_work(body: IntakeIn, db: Session = Depends(get_db)):
    item = WorkItem(title=body.title, pod_id=body.pod_id, owner_id=body.owner_id, due=body.due, source_links=body.source_links); db.add(item); db.commit(); db.refresh(item)
    return {"id": item.id, "title": item.title}
@router.get("")
def list_work(db: Session = Depends(get_db)):
    rows = db.query(WorkItem).order_by(WorkItem.id.desc()).all()
    return {"items":[{"id":r.id,"title":r.title,"status":r.status,"due":r.due} for r in rows]}
