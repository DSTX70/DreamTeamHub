from fastapi import APIRouter, Depends
from pydantic import BaseModel
from sqlalchemy.orm import Session
from app.db.init import get_db
from app.db.models import Decision
router = APIRouter()
class DecisionIn(BaseModel):
    summary: str; rationale: str = ""; approver: str = ""; effective_at: str = ""; links: list[str] = []
@router.post("")
def create_decision(body: DecisionIn, db: Session = Depends(get_db)):
    d = Decision(summary=body.summary, rationale=body.rationale, approver=body.approver, effective_at=body.effective_at, links=body.links); db.add(d); db.commit(); db.refresh(d)
    return {"id": d.id, "summary": d.summary}
@router.get("")
def list_decisions(db: Session = Depends(get_db)):
    rows = db.query(Decision).order_by(Decision.id.desc()).all()
    return {"items":[{"id":r.id,"summary":r.summary,"status":r.status,"links":r.links} for r in rows]}
