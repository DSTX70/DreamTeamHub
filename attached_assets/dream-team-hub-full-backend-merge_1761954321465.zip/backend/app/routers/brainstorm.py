from fastapi import APIRouter, Depends
from pydantic import BaseModel
from sqlalchemy.orm import Session
from app.db.init import get_db
from app.db.models import BrainstormSession, BrainstormIdea
router = APIRouter()
class CreateSession(BaseModel):
    title: str; goal: str = ""
@router.post("")
def create_session(body: CreateSession, db: Session = Depends(get_db)):
    s = BrainstormSession(title=body.title, goal=body.goal, status="draft"); db.add(s); db.commit(); db.refresh(s)
    return {"id": s.id, "title": s.title, "goal": s.goal, "status": s.status}
class IdeaIn(BaseModel):
    text: str; author_id: int | None = None
@router.post("/{session_id}/ideas")
def add_idea(session_id: int, body: IdeaIn, db: Session = Depends(get_db)):
    idea = BrainstormIdea(session_id=session_id, author_id=body.author_id or 0, text=body.text); db.add(idea); db.commit(); db.refresh(idea)
    return {"id": idea.id, "text": idea.text}
