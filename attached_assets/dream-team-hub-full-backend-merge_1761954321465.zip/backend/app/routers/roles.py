from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from typing import List, Optional
from sqlalchemy.orm import Session
from app.db.init import get_db
from app.db.models import RoleCard, RoleRaci
router = APIRouter()
class RoleCardIn(BaseModel):
    handle: str; title: str; pod: str = ""; purpose: str = ""; core_functions: List[str] = []; responsibilities: List[str] = []; tone_voice: str = ""; definition_of_done: List[str] = []; links: List[str] = []; tags: List[str] = []
class RoleCardOut(RoleCardIn):
    id: int
    class Config: from_attributes = True
@router.post("", response_model=RoleCardOut)
def create_role(body: RoleCardIn, db: Session = Depends(get_db)):
    rc = RoleCard(**body.dict()); db.add(rc); db.commit(); db.refresh(rc); return rc
@router.get("", response_model=List[RoleCardOut])
def list_roles(pod: Optional[str] = None, handle: Optional[str] = None, db: Session = Depends(get_db)):
    q = db.query(RoleCard)
    if pod: q = q.filter(RoleCard.pod == pod)
    if handle: q = q.filter(RoleCard.handle == handle)
    return q.order_by(RoleCard.handle.asc()).all()
@router.get("/{role_id}", response_model=RoleCardOut)
def get_role(role_id:int, db: Session = Depends(get_db)):
    rc = db.query(RoleCard).get(role_id)
    if not rc: raise HTTPException(404, "Role card not found")
    return rc
@router.put("/{role_id}", response_model=RoleCardOut)
def update_role(role_id:int, body: RoleCardIn, db: Session = Depends(get_db)):
    rc = db.query(RoleCard).get(role_id)
    if not rc: raise HTTPException(404, "Role card not found")
    for k,v in body.dict().items(): setattr(rc, k, v)
    db.commit(); db.refresh(rc); return rc
@router.delete("/{role_id}")
def delete_role(role_id:int, db: Session = Depends(get_db)):
    rc = db.query(RoleCard).get(role_id)
    if not rc: raise HTTPException(404, "Role card not found")
    db.delete(rc); db.commit(); return {"ok": True}
class RoleRaciIn(BaseModel):
    workstream: str; role_handle: str; r: List[str] = []; a: List[str] = []; c: List[str] = []; i: List[str] = []
class RoleRaciOut(RoleRaciIn):
    id: int
    class Config: from_attributes = True
@router.post("/raci", response_model=RoleRaciOut)
def create_raci(body: RoleRaciIn, db: Session = Depends(get_db)):
    rec = RoleRaci(**body.dict()); db.add(rec); db.commit(); db.refresh(rec); return rec
@router.get("/raci", response_model=List[RoleRaciOut])
def list_raci(workstream: Optional[str] = None, role_handle: Optional[str] = None, db: Session = Depends(get_db)):
    q = db.query(RoleRaci)
    if workstream: q = q.filter(RoleRaci.workstream == workstream)
    if role_handle: q = q.filter(RoleRaci.role_handle == role_handle)
    return q.order_by(RoleRaci.workstream.asc()).all()
@router.post("/import")
def bulk_import(body: List[RoleCardIn], db: Session = Depends(get_db)):
    out=[]; 
    for b in body:
        rc = RoleCard(**b.dict()); db.add(rc); db.flush(); out.append(rc)
    db.commit(); 
    return out
