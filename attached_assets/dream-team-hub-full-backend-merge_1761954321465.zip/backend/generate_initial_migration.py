import os, subprocess, sys
msg = sys.argv[1] if len(sys.argv)>1 else "init schema"
os.environ.setdefault("DATABASE_URL","sqlite:///./dream_team_hub.db")
subprocess.check_call(["alembic", "-c", "alembic.ini", "revision", "--autogenerate", "-m", msg])
