# Dream Team Hub — Full Backend Merge

This repo is a ready-to-run backend for Replit that includes:
- Core APIs (Control Tower, Intake, Decisions, Brainstorm, Audits, Pods/People, Roles/RACI)
- Role Cards with **auto-import on boot** (from `backend/data/dream_team_roster_full.json`)
- **Agents runtime** with specs for all Dream Team members + learning memory
- Alembic scaffolding (optional; DB is SQLite by default)

## Quick Start (Replit)
```bash
cd backend
pip install -r requirements.txt
pip install -r requirements.agent.txt   # only if USE_OPENAI=1
python -c "from app.seed import seed; seed()"
uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
```
Open `/docs` for the API.

## Agents
- List: `GET /agents`
- Run: `POST /agents/run` with `{ "agent":"Prism", "task":"...", "links":[], "post_to_thread": false }`
- Feedback (learning): `POST /agents/feedback` `{ "agent":"Prism", "feedback":"...", "score":2, "kind":"rule" }`
- Memory: `GET /agents/{handle}/memory`

## Env
Copy `backend/.env.sample` → `.env` or set Replit Secrets.
- `IMPORT_ROSTER_ON_BOOT=1` auto-imports role cards at startup
- `USE_OPENAI=1` to enable real LLM calls (`OPENAI_API_KEY` required)

## Alembic (optional)
```bash
cd backend
python generate_initial_migration.py "init schema"
alembic -c alembic.ini upgrade head
```
