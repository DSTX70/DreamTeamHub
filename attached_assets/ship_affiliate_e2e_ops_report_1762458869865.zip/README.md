# Affiliate E2E & Ops Report — Drop

**Date:** 2025-11-06

This drop wires a minimal end‑to‑end affiliate flow (click → cookie → purchase attribution) and an Ops‑facing report page with filters + CSV export.

## What’s included

### Server
- `server/routes/affiliate.route.ts`
  - `GET /api/aff/click` — records a click for `?code=AFFCODE` and sets an `aff_code` cookie (HttpOnly, 30d).
  - `POST /api/aff/attribute` — attributes an order to the affiliate cookie `{{ orderId, orderTotal }}`.
  - `GET /api/ops/aff/report` — summarized totals by affiliate in the given date window.
  - `GET /api/ops/aff/events` — recent event feed (clicks, attributions).
  - `GET /api/ops/aff/report.csv` — CSV export for the report result.

- `server/storage/affiliateStore.ts` — lightweight in‑memory store with an interface you can later back with your DB. (There’s a TODO for “DB migrations to replace in‑memory stores.”)

### Shared
- `shared/affiliates/types.ts` — types for events, report items.
- `shared/affiliates/config.ts` — default commission rate (10%) and cookie name.
- `shared/utils/csv.ts` — tiny CSV helper (safe for commas/quotes).

### Client
- `client/src/pages/ops/AffiliateReport.tsx` — Ops UI with:
  - Date range filters (last 7d, 30d, custom)
  - Table: Clicks, Unique, Orders, Revenue, Commission, Conv%
  - CSV export button
  - “Events” pane (latest 100)
  - Totals row & badges
- `client/src/pages/ops/components/SummaryCards.tsx` — top‑level KPI cards.

### Tests
- `tests/affiliate_e2e.test.ts` — simulates click → cookie → attributed order → checks report.

## Mount

```ts
// server/app.ts (or similar)
app.use(require("./server/routes/affiliate.route").router);
```

If you don’t already, add cookie parser:

```ts
import cookieParser from "cookie-parser";
app.use(cookieParser());
```

## Client route

Add a route to your client router for `/ops/affiliates` pointing to `AffiliateReport`.

## Notes

- Cookies: `aff_code` (HttpOnly) is used for attribution. You can also pass an override `aff` query param to `/api/aff/attribute` for server‑side attribution if needed.
- Commission: flat percentage (default 10%). Tweak in `shared/affiliates/config.ts` or add per‑affiliate rates in your DB layer later.
- Timezones: server uses UTC; client shows local (browser). All server filters accept ISO dates.
- Security: events endpoints are read‑only; ensure your auth middleware wraps `/api/ops/*` in your real app.
