export const AFF_COOKIE_NAME = "aff_code";
export const DEFAULT_COMMISSION_RATE = 0.10; // 10%
