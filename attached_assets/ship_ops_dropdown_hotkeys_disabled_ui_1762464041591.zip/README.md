# Ops Dropdown — Disabled Hotkeys UX

**Date:** 2025-11-06

Updates the Ops dropdown so that when **hotkeysEnabled=false** in `/api/ops/settings/notifiers`:
- The **"?"** hint appears greyed out.
- Tooltip content says: “Hotkeys disabled by Ops” (no combos).
- The **"?"** keypress (Shift+/) will NOT open the menu.

Files:
- `client/src/components/HeaderOpsMenu.tsx` — fetches setting, gates behavior, greys the hint.
- `client/src/components/Tooltip.tsx` — adds a `muted` style prop (no logic change required elsewhere).

Drop-in: replace these two files.
