import React from "react";
import Tooltip from "./Tooltip";

const Item: React.FC<{ href: string; label: string; desc?: string }> = ({ href, label, desc }) => (
  <a href={href} className="block px-3 py-2 rounded hover:bg-gray-50">
    <div className="text-sm font-medium">{label}</div>
    {desc ? <div className="text-xs text-gray-500">{desc}</div> : null}
  </a>
);

const HeaderOpsMenu: React.FC = () => {
  const [open, setOpen] = React.useState(false);
  const [showHint, setShowHint] = React.useState(false);
  const [hotkeysEnabled, setHotkeysEnabled] = React.useState<boolean>(true);
  const ref = React.useRef<HTMLDivElement | null>(null);
  const hintTimer = React.useRef<number | null>(null);

  React.useEffect(() => {
    const onDoc = (e: MouseEvent) => {
      if (!ref.current) return;
      if (!ref.current.contains(e.target as any)) setOpen(false);
    };
    document.addEventListener("click", onDoc);
    return () => document.removeEventListener("click", onDoc);
  }, []);

  // Load global hotkeys toggle
  React.useEffect(() => {
    (async () => {
      try {
        const r = await fetch("/api/ops/settings/notifiers");
        const j = await r.json();
        setHotkeysEnabled(j.settings?.hotkeysEnabled ?? true);
      } catch {
        setHotkeysEnabled(true);
      }
    })();
  }, []);

  // Listen for "?" (Shift+/) to open menu + hint, ONLY if enabled
  React.useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (!hotkeysEnabled) return;
      const el = e.target as HTMLElement | null;
      const tag = el?.tagName;
      const editable = el?.getAttribute?.("contenteditable");
      if (tag === "INPUT" || tag === "TEXTAREA" || editable === "true") return;
      if (e.key === "?" || (e.key === "/" && e.shiftKey)) {
        setOpen(true);
        if (hintTimer.current) window.clearTimeout(hintTimer.current);
        setShowHint(true);
        hintTimer.current = window.setTimeout(() => setShowHint(false), 1500);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [hotkeysEnabled]);

  React.useEffect(() => () => { if (hintTimer.current) window.clearTimeout(hintTimer.current); }, []);

  const hotkeyList = (
    <div className="space-y-1">
      <div><span className="font-mono">g o</span> — Overview</div>
      <div><span className="font-mono">g i</span> — Inventory</div>
      <div><span className="font-mono">g m</span> — Images</div>
      <div><span className="font-mono">g a</span> — Affiliates</div>
      <div><span className="font-mono">g s</span> — Settings</div>
      <div className="text-[10px] text-gray-500 pt-1">Press keys in sequence within ~1.2s</div>
    </div>
  );

  return (
    <div className="relative" ref={ref}>
      <button
        className="inline-flex items-center gap-1 px-3 py-1.5 border rounded-lg text-sm hover:shadow-sm"
        onClick={() => setOpen(v => !v)}
        aria-expanded={open}
        aria-haspopup="menu"
      >
        Ops
        <svg width="16" height="16" viewBox="0 0 24 24" className="opacity-70"><path d="M7 10l5 5 5-5H7z"></path></svg>
      </button>
      {open && (
        <div role="menu" className="absolute right-0 mt-2 w-64 bg-white border rounded-lg shadow-lg p-2 z-50">
          <div className="flex items-center justify-between px-1 py-1">
            <div className="text-xs uppercase tracking-wide text-gray-500">Operations</div>
            <Tooltip
              muted={!hotkeysEnabled}
              content={hotkeysEnabled ? hotkeyList : <div className="text-gray-500">Hotkeys disabled by Ops</div>}
            />
          </div>
          <Item href="/ops/overview"   label="Overview"   desc="Ops dashboard & health" />
          <Item href="/ops/inventory"  label="Inventory"  desc="Low stock & thresholds" />
          <Item href="/ops/images"     label="Images"     desc="Allowlist & uploader" />
          <Item href="/ops/affiliates" label="Affiliates" desc="E2E & Ops report" />
          <div className="h-px bg-gray-200 my-1" />
          <Item href="/ops/settings"   label="Settings"   desc="Alerts & notifications" />
        </div>
      )}
    </div>
  );
};

export default HeaderOpsMenu;
