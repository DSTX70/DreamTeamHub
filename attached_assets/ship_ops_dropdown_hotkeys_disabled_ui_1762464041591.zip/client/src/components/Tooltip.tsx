import React from "react";

const Tooltip: React.FC<{ content: React.ReactNode; children?: React.ReactNode; muted?: boolean }> = ({ content, children, muted }) => {
  const [open, setOpen] = React.useState(false);
  return (
    <span className="relative inline-block">
      <span
        onMouseEnter={() => !muted && setOpen(true)}
        onMouseLeave={() => !muted && setOpen(false)}
        className={`inline-flex items-center justify-center w-5 h-5 rounded-full border text-xs select-none ${muted ? 'opacity-40 cursor-not-allowed' : 'cursor-default'}`}
        aria-label="Keyboard shortcuts"
        title={muted ? "Hotkeys disabled" : "Keyboard shortcuts"}
      >
        ?
      </span>
      {open && (
        <div className="absolute right-0 mt-2 w-56 bg-white border rounded-lg shadow-lg p-2 text-xs z-50">
          {content}
        </div>
      )}
    </span>
  );
};

export default Tooltip;
