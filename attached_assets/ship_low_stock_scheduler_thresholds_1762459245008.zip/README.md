# Low-Stock Scheduler & Threshold Editor — Drop

**Date:** 2025-11-06

This bundle adds:
- A minimal inventory store (in-memory) with per-SKU low-stock **thresholds**.
- An **Ops UI** to edit thresholds and view current low-stock items.
- A **scheduler** that periodically scans inventory and records low-stock alerts.
- Simple recount endpoint to simulate stock updates.

## What’s included

### Server
- `server/routes/inventory.route.ts`
  - `GET /api/ops/inventory/thresholds` → list products with stock, threshold, status.
  - `POST /api/ops/inventory/thresholds` → set thresholds (body: `{ items: [{ sku, threshold }] }`).
  - `GET /api/ops/inventory/low-stock` → list current low-stock items.
  - `POST /api/ops/inventory/recount` → update stock counts (body: `{ items: [{ sku, stock }] }`).
  - `GET /api/ops/inventory/events?limit=100` → recent low-stock events.

- `server/storage/inventoryStore.ts` — in-memory store with seed data and helpers.
- `server/scheduler/lowStockScheduler.ts` — `startLowStockScheduler({ intervalMs })` scan loop.

### Shared
- `shared/inventory/types.ts` — shared types.

### Client
- `client/src/pages/ops/InventoryLowStock.tsx` — table with inline **threshold editor**, filters, recount, and a low-stock panel.
- `client/src/pages/ops/components/ThresholdCell.tsx` — small input cell with optimistic UI.

### Tests
- `tests/inventory_low_stock.test.ts` — exercises threshold update, recount, and low-stock listing.

## Mount

```ts
// server/app.ts (or similar)
app.use(require("./server/routes/inventory.route").router);
```

## Scheduler

```ts
// server/index.ts (or wherever you boot the server)
const { startLowStockScheduler } = require("./server/scheduler/lowStockScheduler");
startLowStockScheduler({ intervalMs: 60_000 }); // scan every 60s
```

> The scheduler logs low-stock detections into the store’s event log. You can wire an email/slack/webhook in `lowStockScheduler.ts` (look for the TODO).

## Client route

Add a route to your client router for `/ops/inventory` pointing to `InventoryLowStock`.

## Notes
- This is intentionally in-memory for now. Your upcoming “DB migrations to replace in-memory stores” task can back `InventoryStore` with your DB.
- All server dates are UTC ISO strings. Client renders in the browser’s local time.
- Wrap `/api/ops/*` with your auth/ops guard.
