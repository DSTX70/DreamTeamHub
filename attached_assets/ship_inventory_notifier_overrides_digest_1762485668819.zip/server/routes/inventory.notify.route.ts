import express, { Request, Response } from "express";
import { inventoryNotifyDao } from "../db/inventoryDao.notify";

const router = express.Router();

router.get("/api/ops/inventory/notify", async (_req: Request, res: Response) => {
  const items = await inventoryNotifyDao.listProductsWithNotify();
  res.json({ items });
});

router.post("/api/ops/inventory/notify", express.json(), async (req: Request, res: Response) => {
  const items = Array.isArray(req.body?.items) ? req.body.items : [];
  await inventoryNotifyDao.setMany(items.map((x:any)=>({ sku: String(x.sku), notifySlack: !!x.notifySlack, notifyEmail: !!x.notifyEmail })));
  const out = await inventoryNotifyDao.listProductsWithNotify();
  res.json({ ok: true, items: out });
});

export default router;
