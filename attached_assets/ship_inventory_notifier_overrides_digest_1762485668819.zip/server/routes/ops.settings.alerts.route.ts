import express, { Request, Response } from "express";
import { opsAuth } from "../middleware/opsAuth";
import { effectiveSettings, writeSettings } from "../notifiers/settingsStore";

const router = express.Router();

function allowEditorOrAdmin(req: Request, res: Response, next: any) {
  const roles = ((req as any).auth?.roles || []) as string[];
  if (roles.includes("ops_admin") || roles.includes("ops_editor")) return next();
  return res.status(403).json({ error: "Forbidden (role)" });
}

router.get("/api/ops/settings/alerts", opsAuth(), allowEditorOrAdmin, async (_req: Request, res: Response) => {
  const s = await effectiveSettings();
  res.json({
    slackWebhookUrl: s.slackWebhookUrl,
    emailEnabled: s.emailEnabled,
    emailFrom: s.emailFrom,
    emailTo: s.emailTo,
    smtpHost: s.smtpHost,
    smtpPort: s.smtpPort,
    smtpUser: s.smtpUser,
    weeklyDigestEnabled: s.weeklyDigestEnabled,
    weeklyDigestDay: s.weeklyDigestDay,
    weeklyDigestHour: s.weeklyDigestHour,
    weeklyDigestTo: s.weeklyDigestTo,
  });
});

router.post("/api/ops/settings/alerts", opsAuth(), allowEditorOrAdmin, express.json(), async (req: Request, res: Response) => {
  const body = req.body || {};
  await writeSettings({
    slackWebhookUrl: String(body.slackWebhookUrl || ""),
    emailEnabled: !!body.emailEnabled,
    emailFrom: String(body.emailFrom || ""),
    emailTo: String(body.emailTo || ""),
    smtpHost: String(body.smtpHost || ""),
    smtpPort: Number(body.smtpPort || 587),
    smtpUser: String(body.smtpUser || ""),
    smtpPass: String(body.smtpPass || ""),
    weeklyDigestEnabled: !!body.weeklyDigestEnabled,
    weeklyDigestDay: String(body.weeklyDigestDay || "Mon"),
    weeklyDigestHour: Number(body.weeklyDigestHour ?? 9),
    weeklyDigestTo: String(body.weeklyDigestTo || ""),
  });
  const s = await effectiveSettings();
  res.json({ ok: true, weeklyDigestEnabled: s.weeklyDigestEnabled });
});

export default router;
