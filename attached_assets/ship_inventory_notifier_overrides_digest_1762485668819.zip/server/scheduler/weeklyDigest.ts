import { effectiveSettings } from "../notifiers/settingsStore";
import { inventoryDao } from "../db/inventoryDao";

const DAY_MAP: Record<string, number> = { Sun:0, Mon:1, Tue:2, Wed:3, Thu:4, Fri:5, Sat:6 };

export function startWeeklyDigest(opts: { now?: ()=>Date } = {}) {
  let timer: NodeJS.Timeout | null = null;
  const nowFn = opts.now || (() => new Date());

  async function tick() {
    try {
      const s = await effectiveSettings();
      if (!s.weeklyDigestEnabled) return;
      const now = nowFn();
      const targetDow = DAY_MAP[s.weeklyDigestDay] ?? 1; // default Mon
      if (now.getDay() !== targetDow) return;
      if (now.getHours() !== s.weeklyDigestHour) return;

      const lows = await inventoryDao.getLowStock();
      if (!lows || !lows.length) return;

      const lines = lows.map((it:any)=> `• ${it.sku} — ${it.name || ""} (stock ${it.stock}, thr ${it.threshold})`).join("\n");
      const subject = `Weekly Low-Stock Digest (${now.toISOString().slice(0,10)}) — ${lows.length} SKUs`;
      const text = `Low-stock items:\n\n${lines}\n\n— Dream Team Hub`;

      // eslint-disable-next-line @typescript-eslint/no-var-requires
      const nodemailer = require("nodemailer");
      const to = s.weeklyDigestTo || s.emailTo;
      if (!to || !s.emailEnabled) return;
      const transporter = nodemailer.createTransport({
        host: s.smtpHost, port: s.smtpPort, secure: false,
        auth: { user: s.smtpUser, pass: s.smtpPass }
      });
      await transporter.sendMail({ from: s.emailFrom, to, subject, text });
    } catch (e) {
      console.error("weeklyDigest tick error", e);
    }
  }

  timer = setInterval(tick, 60_000);
  tick().catch(()=>{});

  return { stop() { if (timer) clearInterval(timer); timer = null; } };
}
