import { db } from "./client";
import { sql } from "drizzle-orm";

export const inventoryNotifyDao = {
  async listProductsWithNotify() {
    const res = await db.execute(sql`
      SELECT sku, name, stock, threshold, COALESCE(notify_slack, true) AS notify_slack, COALESCE(notify_email, false) AS notify_email, updated_at
      FROM products
      ORDER BY sku
    `);
    return res.rows.map((r:any)=>({
      sku: r.sku,
      name: r.name,
      stock: Number(r.stock),
      threshold: Number(r.threshold),
      notifySlack: !!r.notify_slack,
      notifyEmail: !!r.notify_email,
      updatedAt: r.updated_at
    }));
  },

  async setNotifyFlags(sku: string, flags: { notifySlack?: boolean; notifyEmail?: boolean }) {
    await db.execute(sql`
      UPDATE products
      SET notify_slack = COALESCE(${flags.notifySlack}, notify_slack),
          notify_email = COALESCE(${flags.notifyEmail}, notify_email),
          updated_at = NOW()
      WHERE sku = ${sku}
    `);
  },

  async setMany(items: { sku: string; notifySlack?: boolean; notifyEmail?: boolean }[]) {
    for (const it of items) {
      await this.setNotifyFlags(it.sku, { notifySlack: it.notifySlack, notifyEmail: it.notifyEmail });
    }
  }
};
