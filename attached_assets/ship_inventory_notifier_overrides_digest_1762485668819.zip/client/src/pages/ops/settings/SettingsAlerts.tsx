import React from "react";

const days = ["Sun","Mon","Tue","Wed","Thu","Fri","Sat"] as const;

const SettingsAlerts: React.FC = () => {
  const [s, setS] = React.useState<any | null>(null);
  const [busy, setBusy] = React.useState(false);
  const [note, setNote] = React.useState("");

  const load = async () => {
    const r = await fetch("/api/ops/settings/alerts");
    const j = await r.json();
    setS(j);
  };
  React.useEffect(()=>{ load(); }, []);

  const save = async () => {
    setBusy(true);
    setNote("");
    await fetch("/api/ops/settings/alerts", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(s) });
    setBusy(false);
    setNote("Saved.");
  };

  if (!s) return <div>Loading…</div>;

  return (
    <div className="space-y-4">
      <div className="font-semibold">Alerts (editor/admin)</div>

      {/* existing alert fields kept ... */}

      <div className="border-t pt-3 space-y-3">
        <div className="font-semibold">Weekly Digest</div>
        <label className="flex items-center gap-2 text-sm">
          <input type="checkbox" checked={!!s.weeklyDigestEnabled} onChange={e=>setS({ ...s, weeklyDigestEnabled: e.target.checked })} />
          <span>Enabled</span>
        </label>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <label className="flex flex-col gap-1 text-sm">
            <span className="text-xs text-gray-600">Day</span>
            <select className="border rounded px-2 py-1" value={s.weeklyDigestDay || "Mon"} onChange={e=>setS({ ...s, weeklyDigestDay: e.target.value })}>
              {days.map(d => <option key={d} value={d}>{d}</option>)}
            </select>
          </label>
          <label className="flex flex-col gap-1 text-sm">
            <span className="text-xs text-gray-600">Hour (0–23)</span>
            <input type="number" min={0} max={23} className="border rounded px-2 py-1" value={s.weeklyDigestHour ?? 9} onChange={e=>setS({ ...s, weeklyDigestHour: Number(e.target.value) })} />
          </label>
          <label className="flex flex-col gap-1 text-sm">
            <span className="text-xs text-gray-600">To (override)</span>
            <input className="border rounded px-2 py-1" placeholder="leave blank to use Email To" value={s.weeklyDigestTo || ""} onChange={e=>setS({ ...s, weeklyDigestTo: e.target.value })} />
          </label>
        </div>
      </div>

      <div className="flex gap-2">
        <button className="px-3 py-2 border rounded" onClick={save} disabled={busy}>Save</button>
        <span className="text-sm text-gray-600">{note}</span>
      </div>
    </div>
  );
};

export default SettingsAlerts;
