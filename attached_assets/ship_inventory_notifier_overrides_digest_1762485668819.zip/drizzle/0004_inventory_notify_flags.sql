-- drizzle/0004_inventory_notify_flags.sql
ALTER TABLE products ADD COLUMN IF NOT EXISTS notify_slack boolean DEFAULT true;
ALTER TABLE products ADD COLUMN IF NOT EXISTS notify_email boolean DEFAULT false;

CREATE INDEX IF NOT EXISTS products_notify_idx ON products (notify_slack, notify_email);
