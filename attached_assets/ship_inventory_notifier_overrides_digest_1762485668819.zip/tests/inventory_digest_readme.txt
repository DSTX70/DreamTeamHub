Manual/Integration:
1) Apply migration 0004 to add notify flags.
2) Visit /ops/inventory — Slack/Email checkboxes appear per row; toggling persists.
3) In /ops/settings/alerts, configure weekly digest; start server with startWeeklyDigest(); verify an email on schedule.
