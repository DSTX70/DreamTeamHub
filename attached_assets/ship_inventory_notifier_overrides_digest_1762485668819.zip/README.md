# Inventory — Notifier Overrides & Weekly Digest

Date: 2025-11-07

Adds per-SKU notifier overrides and a weekly low-stock digest.

DB:
- drizzle/0004_inventory_notify_flags.sql — adds notify_slack, notify_email to products

Server:
- server/db/inventoryDao.notify.ts — list/set flags
- server/routes/inventory.notify.route.ts — GET/POST flags
- server/notifiers/settingsStore.ts — adds weeklyDigestEnabled, weeklyDigestDay, weeklyDigestHour, weeklyDigestTo
- server/routes/ops.settings.alerts.route.ts — exposes digest fields
- server/scheduler/weeklyDigest.ts — startWeeklyDigest(opts) runs once per minute, sends email when window matches

Client:
- client/src/pages/ops/InventoryLowStock.tsx — Slack/Email toggles per row
- client/src/pages/ops/settings/SettingsAlerts.tsx — digest controls
