
export async function listSkuMap(brand='fcc') {
  const res = await fetch(`/api/fcc/sku-map?brand=${encodeURIComponent(brand)}`, { credentials:'include' });
  if (!res.ok) throw new Error('Failed to load sku map');
  return res.json();
}
export async function upsertSkuMap(row: { brand?:string; shot_key:string; label:string; base_key:string }) {
  const res = await fetch('/api/fcc/sku-map', {
    method: 'POST',
    headers: { 'Content-Type':'application/json' },
    body: JSON.stringify(row),
    credentials:'include'
  });
  if (!res.ok) throw new Error('Failed to save row');
  return res.json();
}
