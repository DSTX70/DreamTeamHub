
import * as React from 'react';
import { listSkuMap, upsertSkuMap } from '@/client/lib/fccSkuMap';
type Row = { id?: number; brand: string; shot_key: string; label: string; base_key: string };
export default function FCCSkuSwitcher() {
  const [rows, setRows] = React.useState<Row[]>([]);
  const [brand, setBrand] = React.useState('fcc');
  const [busy, setBusy] = React.useState(false);
  const [err, setErr] = React.useState<string | null>(null);
  const load = async () => { setErr(null); try { const j = await listSkuMap(brand); setRows(j.items || []); } catch (e:any) { setErr(String(e)); } };
  React.useEffect(() => { load(); }, [brand]);
  const save = async (i:number) => { setBusy(true); try { const r = rows[i]; await upsertSkuMap({ brand, shot_key: r.shot_key, label: r.label, base_key: r.base_key }); await load(); } catch (e:any) { setErr(String(e)); } finally { setBusy(false); } };
  return (
    <div className="max-w-5xl mx-auto p-6 space-y-6">
      <h1 className="text-xl font-semibold">Fab Card Co — SKU Switcher</h1>
      <p className="text-sm text-muted-foreground">Flip lifestyle banner SKUs without code. Changes apply immediately.</p>
      <div className="overflow-x-auto border rounded-lg">
        <table className="w-full text-sm">
          <thead className="bg-muted/50">
            <tr><th className="text-left p-3">Shot Key</th><th className="text-left p-3">Label</th><th className="text-left p-3">Base Key</th><th className="text-left p-3 w-32">Actions</th></tr>
          </thead>
          <tbody>
            {rows.map((r, idx) => (
              <tr key={r.shot_key} className="border-t">
                <td className="p-3 font-mono">{r.shot_key}</td>
                <td className="p-3"><input className="border rounded px-2 py-1 w-full" value={r.label} onChange={e=>setRows(prev=>prev.map((x,i)=>i===idx?{...x,label:e.target.value}:x))} /></td>
                <td className="p-3"><input className="border rounded px-2 py-1 w-full font-mono" value={r.base_key} onChange={e=>setRows(prev=>prev.map((x,i)=>i===idx?{...x,base_key:e.target.value}:x))} /></td>
                <td className="p-3"><button disabled={busy} className="border rounded px-2 py-1" onClick={()=>save(idx)}>{busy?'Saving…':'Save'}</button></td>
              </tr>
            ))}
            {rows.length===0 && <tr><td className="p-6 text-muted-foreground" colSpan={4}>No rows yet.</td></tr>}
          </tbody>
        </table>
      </div>
      {err && <div className="text-xs text-red-600">Error: {err}</div>}
    </div>
  );
}
