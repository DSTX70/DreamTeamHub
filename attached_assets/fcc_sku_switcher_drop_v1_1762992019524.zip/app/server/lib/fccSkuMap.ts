
import { db } from '@/server/db';
import { sql } from 'drizzle-orm';
export type SkuMapRow = { shot_key: string; label: string; base_key: string };
export async function getFccSkuMap(): Promise<SkuMapRow[]> {
  const rows:any = await db.execute(sql`SELECT shot_key, label, base_key FROM sku_mappings WHERE brand='fcc' ORDER BY shot_key`);
  return rows as SkuMapRow[];
}
