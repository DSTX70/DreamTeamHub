
import { Router } from 'express';
import { db } from '@/server/db';
import { sql } from 'drizzle-orm';
export const fccSkuMapRouter = Router();
fccSkuMapRouter.get('/fcc/sku-map', async (req, res) => {
  const brand = (req.query.brand as string) || 'fcc';
  try {
    const rows:any = await db.execute(sql`SELECT id, brand, shot_key, label, base_key, updated_by, updated_at FROM sku_mappings WHERE brand=${brand} ORDER BY shot_key`);
    res.json({ ok:true, items: rows });
  } catch (e:any) { res.status(500).json({ ok:false, error: e.message }); }
});
fccSkuMapRouter.post('/fcc/sku-map', async (req, res) => {
  const { brand='fcc', shot_key, label, base_key } = req.body || {};
  if (!shot_key || !label || !base_key) return res.status(400).json({ ok:false, error:'shot_key, label, base_key required' });
  try {
    await db.execute(sql`INSERT INTO sku_mappings (brand, shot_key, label, base_key, updated_by) VALUES (${brand}, ${shot_key}, ${label}, ${base_key}, ${req.user?.id || 'ops'}) ON CONFLICT (brand, shot_key) DO UPDATE SET label=EXCLUDED.label, base_key=EXCLUDED.base_key, updated_by=EXCLUDED.updated_by, updated_at=NOW()`);
    res.json({ ok:true });
  } catch (e:any) { res.status(500).json({ ok:false, error: e.message }); }
});
