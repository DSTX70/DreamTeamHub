
CREATE TABLE IF NOT EXISTS sku_mappings (
  id BIGSERIAL PRIMARY KEY,
  brand TEXT NOT NULL DEFAULT 'fcc',
  shot_key TEXT NOT NULL,
  label TEXT NOT NULL,
  base_key TEXT NOT NULL,
  updated_by TEXT,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (brand, shot_key)
);
INSERT INTO sku_mappings (brand, shot_key, label, base_key) VALUES
('fcc','home.lifestyle_ol1','OL-1 Brunch Banter','fcc/lifestyle/OL-1_Brunch_Banter_SKU-OL-PRIDE-001'),
('fcc','home.lifestyle_ol2','OL-2 Stoop Affirmation','fcc/lifestyle/OL-2_Stoop_Affirmation_SKU-OL-AFFIRM-002'),
('fcc','home.lifestyle_me1','ME-1 Candlelight Foil','fcc/lifestyle/ME-1_Candlelight_Foil_SKU-ME-FOIL-001'),
('fcc','home.lifestyle_me2','ME-2 Bar Congrats Clink','fcc/lifestyle/ME-2_Bar_Congrats_Clink_SKU-ME-CONGRATS-003'),
('fcc','home.lifestyle_cc1','CC-1 Kitchen Table Thank-You','fcc/lifestyle/CC-1_Kitchen_Table_ThankYou_SKU-CC-THANKS-004'),
('fcc','home.lifestyle_cc2','CC-2 At-Home Birthday','fcc/lifestyle/CC-2_AtHome_Birthday_SKU-CC-BDAY-005')
ON CONFLICT (brand, shot_key) DO NOTHING;
