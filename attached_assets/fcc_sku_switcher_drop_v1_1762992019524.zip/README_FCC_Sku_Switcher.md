Fab Card Co — SKU Switcher (Admin) v1
Generated: 2025-11-12T23:58:17.511469Z

Install:
1) psql "$DATABASE_URL" -f migrations/006_sku_mappings.sql
2) app.use('/api', fccSkuMapRouter)
3) Add sidebar route /ops/fcc-sku-switcher → <FCCSkuSwitcher /> (ops_admin)
Homepage mapping: getFccSkuMap() and feed base_key into <PictureBanner />
