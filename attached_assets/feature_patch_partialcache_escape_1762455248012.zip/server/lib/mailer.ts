// server/lib/mailer.ts
import fs from "fs";
import path from "path";
import mjml2html from "mjml";

/** Simple HTML escape to prevent accidental HTML injection in transactional emails. */
function escapeHtml(input: any): string {
  const s = String(input);
  return s
    .replaceAll(/&/g, "&amp;")
    .replaceAll(/</g, "&lt;")
    .replaceAll(/>/g, "&gt;")
    .replaceAll(/"/g, "&quot;")
    .replaceAll(/'/g, "&#39;");
}

/**
 * mtime-aware partial cache:
 * caches by partialsDir + filename, invalidates if file mtime changes.
 */
type CacheEntry = { mtimeMs: number; content: string };
const PARTIAL_CACHE: Record<string, Record<string, CacheEntry>> = {};

function loadPartialsCached(dir: string): Record<string, string> {
  if (!fs.existsSync(dir)) return {};
  if (!PARTIAL_CACHE[dir]) PARTIAL_CACHE[dir] = {};
  const cache = PARTIAL_CACHE[dir];
  const out: Record<string, string> = {};
  for (const filename of fs.readdirSync(dir)) {
    const filePath = path.join(dir, filename);
    const key = path.basename(filename, path.extname(filename)); // e.g., header
    const stat = fs.statSync(filePath);
    const entry = cache[filename];
    if (!entry || entry.mtimeMs !== stat.mtimeMs) {
      cache[filename] = { mtimeMs: stat.mtimeMs, content: fs.readFileSync(filePath, "utf-8") };
    }
    out[key] = cache[filename].content;
  }
  return out;
}

/**
 * Very small Handlebars-like expander for:
 *  - {{> partialName}}
 *  - {{#each arrayName}} ... {{/each}}
 *  - {{var}} replacements (shallow, HTML-escaped)
 */
function expandTemplate(input: string, vars: any, partials: Record<string, string>): string {
  let tpl = input;

  // 1) Expand top-level partials {{> name}}
  tpl = tpl.replace(/\{\{\>\s*([a-zA-Z0-9_\-]+)\s*\}\}/g, (_m, name) => partials[name] || "");

  // 2) Expand each-blocks
  tpl = tpl.replace(/\{\{#each\s+([a-zA-Z0-9_\.]+)\}\}([\s\S]*?)\{\{\/each\}\}/g, (_m, arrKey, inner) => {
    const arr = arrKey.split(".").reduce((acc:any, k:string) => (acc ? acc[k] : undefined), vars);
    if (!Array.isArray(arr) || arr.length === 0) return "";
    return arr.map((item:any) => {
      // Nested partials inside loop
      let block = inner.replace(/\{\{\>\s*([a-zA-Z0-9_\-]+)\s*\}\}/g, (_m2, name2) => partials[name2] || "");
      // Replace {{var}} from item (escaped)
      block = block.replace(/\{\{\s*([a-zA-Z0-9_\.]+)\s*\}\}/g, (_m3, key) => {
        const val = key.split(".").reduce((acc:any, k:string) => (acc ? acc[k] : undefined), item);
        return (val !== undefined && val !== null) ? escapeHtml(val) : "";
      });
      return block;
    }).join("");
  });

  // 3) Root-level {{var}} (escaped)
  tpl = tpl.replace(/\{\{\s*([a-zA-Z0-9_\.]+)\s*\}\}/g, (_m, key) => {
    const val = key.split(".").reduce((acc:any, k:string) => (acc ? acc[k] : undefined), vars);
    return (val !== undefined && val !== null) ? escapeHtml(val) : "";
  });

  return tpl;
}

/**
 * Render MJML from file with partials + escaping + caching.
 */
export function renderTxEmailFromFile(mjmlPath: string, vars: Record<string, any> = {}, partialsDir = "emails/tx/partials") {
  const raw = fs.readFileSync(mjmlPath, "utf-8");
  const partials = loadPartialsCached(partialsDir);
  const expanded = expandTemplate(raw, vars, partials);
  const { html, errors } = mjml2html(expanded, { validationLevel: "soft" });
  if (errors && errors.length) console.warn("[MJML] warnings:", errors);
  return html;
}

/**
 * Back-compat: render from a raw MJML string with root var replacements (escaped).
 */
export function renderTxEmail(mjmlTemplate: string, vars: Record<string, string|number> = {}) {
  let mjml = mjmlTemplate;
  for (const [k, v] of Object.entries(vars)) {
    const re = new RegExp(`{{\\s*${k}\\s*}}`, "g");
    mjml = mjml.replace(re, escapeHtml(v));
  }
  const { html, errors } = mjml2html(mjml, { validationLevel: "soft" });
  if (errors && errors.length) console.warn("[MJML] warnings:", errors);
  return html;
}
