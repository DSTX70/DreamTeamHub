# Patch: Partial Cache + Safe HTML Escape

## Partial Cache
- `renderTxEmailFromFile()` now loads partials through an **mtime-aware cache**, avoiding disk reads per render.
- Cache key: directory + filename; invalidates automatically if file mtime changes.

## Safe HTML Escape
- All `{{var}}` replacements (root and inside `#each`) are escaped:
  - `& < > " '` → `&amp; &lt; &gt; &quot; &#39;`
- Keeps transactional emails safe from accidental HTML injection.

**File changed:** `server/lib/mailer.ts`
