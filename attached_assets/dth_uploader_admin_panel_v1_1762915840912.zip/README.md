# DTH Uploader — Admin Toggle Page (Standalone Drop)

This is a tiny Ops menu admin page to manage the uploader config (backend, allowlist, max size).
Targets endpoints:
- GET /api/ops/uploader/config
- POST /api/ops/uploader/config

Files:
- client/UploaderAdminPanel.tsx
- server/routes/uploader_admin_backup.ts (optional)
- server/services/config.ts (optional helper)

Client usage:
1) Place client/UploaderAdminPanel.tsx in your UI.
2) Mount it in your Ops route/page:

import { UploaderAdminPanel } from '@/client/UploaderAdminPanel';
export default function OpsUploaderSettings() {
  return <UploaderAdminPanel />;
}

Server backup wiring (only if you didn't install the prior routes):
import { uploaderAdminBackupRouter } from './server/routes/uploader_admin_backup';
app.use('/api/ops/uploader', uploaderAdminBackupRouter);
