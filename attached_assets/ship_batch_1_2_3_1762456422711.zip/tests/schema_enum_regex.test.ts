import { validateVars } from "../shared/email/schema";
import { orderUpdateSchema } from "../emails/tx/schemas/order_update.schema";

test("enum + regex", () => {
  const good = {
    orderId: "X",
    statusCopy: "Shipped",
    etaDate: "Nov 10, 2025",
    orderLink: "https://example.com/x",
    brandHeaderUrl: "https://example.com/h.png",
    brandName: "Brand",
    lineItems: [{ thumbUrl: "https://example.com/i.webp", title: "A", qty: 1, price: "$3.99" }]
  };
  expect(validateVars(orderUpdateSchema, good)).toHaveLength(0);

  const bad = { ...good, statusCopy: "Weird", lineItems: [{ ...good.lineItems[0], price: "3.9" }] };
  const errs = validateVars(orderUpdateSchema, bad);
  expect(errs.length).toBeGreaterThan(0);
});
