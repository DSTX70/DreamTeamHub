import fs from "fs";
import path from "path";
import { renderTxEmailFromFile } from "../server/lib/mailer";

test("partials cache respects mtime changes", () => {
  const p = path.join(process.cwd(), "emails/tx/partials/header.mjml");
  const orig = fs.readFileSync(p, "utf-8");
  try {
    // Render once
    renderTxEmailFromFile("emails/tx/order_shipped.mjml", { orderId:"1", etaDate:"Nov 10, 2025", orderLink:"#", brandHeaderUrl:"#", brandName:"Test", lineItems: [] });
    // Update partial
    fs.writeFileSync(p, orig.replace("Your order is on the way!", "On the way!"), "utf-8");
    // Render again should pick up change without restart
    renderTxEmailFromFile("emails/tx/order_shipped.mjml", { orderId:"1", etaDate:"Nov 10, 2025", orderLink:"#", brandHeaderUrl:"#", brandName:"Test", lineItems: [] });
  } finally {
    fs.writeFileSync(p, orig, "utf-8");
  }
});
