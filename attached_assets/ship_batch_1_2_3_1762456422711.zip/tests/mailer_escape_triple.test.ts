import { renderTxEmail } from "../server/lib/mailer";

test("escaped vs unescaped", () => {
  const tmpl = "<mjml><mj-body><mj-section><mj-column><mj-text>{{safe}}</mj-text><mj-text>{{{raw}}}</mj-text></mj-column></mj-section></mj-body></mjml>";
  const html = renderTxEmail(tmpl, { safe: "<b>x</b>", raw: "<b>y</b>" });
  expect(html).toContain("&lt;b&gt;x&lt;/b&gt;"); // escaped
  expect(html).toContain("<b>y</b>");           // unescaped
});
