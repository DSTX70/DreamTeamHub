# Ship Batch: #1 Mailer Merge + Tests, #2 TX Mail Transport + Preview, #3 ETA Integration

This drop folds in:
1) **Mailer consolidation** + typed wrapper + schema DSL (+ enum/regex), with tests.
2) **Transactional email** transport and a developer preview route.
3) **ETA** real inputs + friendly date formatting and email injection.

## Install
```bash
npm i mjml nodemailer sharp
# optional: dotenv for local env loads
```

## Env
```
SMTP_HOST=localhost
SMTP_PORT=1025
SMTP_SECURE=false
SMTP_USER=
SMTP_PASS=
MAIL_FROM="Fab Card Co. <noreply@example.com>"
PARTIAL_CACHE_MAX_DIRS=8
PARTIAL_CACHE_MAX_FILES=32
APP_URL=http://localhost:3000
```

## Mount (server bootstrap)
```ts
import cookieParser from "cookie-parser";
app.use(cookieParser());
app.use(require("./server/routes/img.route").router);              // if not mounted yet
app.use(require("./server/routes/email_preview.route").router);
app.use(require("./server/routes/dev_send_example.route").router);
```

## Dev preview
- Visit: `/dev/email/preview?template=order_shipped&orderId=123&postalFrom=85001&postalTo=10001`
- Or: `/dev/email/preview?template=order_update&status=Shipped&orderId=123&postalFrom=85001&postalTo=10001`

## Tests
- `npm test` after adding your jest/vitest harness.
- Included tests: partial cache/LRU/env caps, escaping/triple-brace, schema enum/regex.
