// server/lib/mailer.typed.ts
import { renderTxEmailFromFile } from "./mailer";
import type { ObjectSchema, ValidationError } from "../../shared/email/schema";
import { validateVars, TypeOf } from "../../shared/email/schema";

export function renderTxEmailFromFileTyped<S extends ObjectSchema>(
  templatePath: string,
  schema: S,
  vars: TypeOf<S>,
  partialsDir = "emails/tx/partials"
) {
  const errors: ValidationError[] = validateVars(schema, vars);
  if (errors.length) {
    const msg = errors.map(e => `${e.path || "<root>"}: ${e.message}`).join("; ");
    throw new Error("Template var validation failed: " + msg);
  }
  return renderTxEmailFromFile(templatePath, vars as any, partialsDir);
}
