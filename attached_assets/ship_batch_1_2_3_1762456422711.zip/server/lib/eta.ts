// server/lib/eta.ts
export type ShipSpeed = "standard" | "expedited";
export function computeEtaDays({ postalFrom, postalTo, shipSpeed }: { postalFrom: string; postalTo: string; shipSpeed: ShipSpeed }) {
  let base = shipSpeed === "expedited" ? 2 : 5;
  if (postalFrom?.slice(0,1) === postalTo?.slice(0,1) && shipSpeed !== "expedited") base = 3;
  return base;
}
export function formatEta({ postalFrom, postalTo, shipSpeed = "standard" as ShipSpeed }) {
  const days = computeEtaDays({ postalFrom, postalTo, shipSpeed });
  const d = new Date(); d.setDate(d.getDate() + days);
  const display = d.toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" });
  return { days, date: d, display };
}
