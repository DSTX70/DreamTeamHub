// server/routes/email_preview.route.ts
import express, { Request, Response } from "express";
import { renderTxEmailFromFileTyped } from "../lib/mailer.typed";
import { orderShippedSchema } from "../../emails/tx/schemas/order_shipped.schema";
import { orderUpdateSchema } from "../../emails/tx/schemas/order_update.schema";
import { formatEta } from "../lib/eta";

export const router = express.Router();

router.get("/dev/email/preview", async (req: Request, res: Response) => {
  try {
    const { template = "order_shipped", orderId = "X0001", postalFrom = "85001", postalTo = "10001", status = "Shipped" } = req.query as any;
    const eta = formatEta({ postalFrom, postalTo, shipSpeed: "standard" });
    const baseVars = {
      orderId,
      etaDate: eta.display,
      orderLink: `${process.env.APP_URL || ""}/orders/${orderId}`,
      brandHeaderUrl: `${process.env.APP_URL || ""}/static/brand/header.png`,
      brandName: "Fab Card Co.",
      lineItems: [
        { thumbUrl: `${process.env.APP_URL || ""}/static/img/sample1.webp`, title: "Card A", qty: 1, price: "$3.99" },
        { thumbUrl: `${process.env.APP_URL || ""}/static/img/sample2.webp`, title: "Card B", qty: 2, price: "$7.98" },
      ]
    };

    let html = "";
    if (template === "order_update") {
      html = renderTxEmailFromFileTyped("emails/tx/order_update.mjml", orderUpdateSchema, { ...baseVars, statusCopy: String(status) });
    } else {
      html = renderTxEmailFromFileTyped("emails/tx/order_shipped.mjml", orderShippedSchema, baseVars);
    }
    res.type("text/html").send(html);
  } catch (e:any) {
    res.status(400).send(e.message);
  }
});
