// server/routes/dev_send_example.route.ts
import express, { Request, Response } from "express";
import { makeTransport } from "../lib/mailTransport";
import { renderTxEmailFromFileTyped } from "../lib/mailer.typed";
import { orderShippedSchema } from "../../emails/tx/schemas/order_shipped.schema";
import { formatEta } from "../lib/eta";

export const router = express.Router();

router.post("/dev/email/send-shipped", async (req: Request, res: Response) => {
  try {
    const { to = "test@example.com", orderId = "X0002", postalFrom = "85001", postalTo = "10001" } = req.body || {};
    const eta = formatEta({ postalFrom, postalTo, shipSpeed: "standard" });
    const vars = {
      orderId,
      etaDate: eta.display,
      orderLink: `${process.env.APP_URL || ""}/orders/${orderId}`,
      brandHeaderUrl: `${process.env.APP_URL || ""}/static/brand/header.png`,
      brandName: "Fab Card Co.",
      lineItems: [{ thumbUrl: `${process.env.APP_URL || ""}/static/img/sample1.webp`, title: "Card A", qty: 1, price: "$3.99" }]
    };
    const html = renderTxEmailFromFileTyped("emails/tx/order_shipped.mjml", orderShippedSchema, vars);
    const transport = makeTransport();
    const info = await transport.sendMail({ from: process.env.MAIL_FROM || "noreply@example.com", to, subject: `Your order #${orderId} shipped`, html });
    res.json({ ok: true, id: info.messageId });
  } catch (e:any) {
    res.status(400).json({ error: e.message });
  }
});
