// shared/email/schema.ts
export type PrimitiveKind = "string" | "number" | "boolean" | "url" | "html";

export interface BaseField {
  optional?: boolean;
  enum?: readonly (string | number | boolean)[];
  pattern?: string; // regex source
}
export interface FieldSchema extends BaseField { kind: PrimitiveKind; }
export interface ObjectSchema { kind: "object"; fields: Record<string, Schema>; optional?: boolean; }
export interface ArraySchema { kind: "array"; of: Schema; optional?: boolean; }
export type Schema = FieldSchema | ObjectSchema | ArraySchema;

export type TypeOf<S extends Schema> =
  S extends { kind: "string" } ? string :
  S extends { kind: "number" } ? number :
  S extends { kind: "boolean" } ? boolean :
  S extends { kind: "url" } ? string :
  S extends { kind: "html" } ? string :
  S extends { kind: "array", of: infer Item extends Schema } ? Array<TypeOf<Item>> :
  S extends { kind: "object", fields: infer F extends Record<string, Schema> } ? {
    [K in keyof F as F[K] extends { optional: true } ? K : K]-?:
      F[K] extends Schema ? TypeOf<F[K]> : never
  } : never;

export type ValidationError = { path: string; message: string };
const isNil = (v:any) => v === undefined || v === null;
const E = (path:string, msg:string): ValidationError[] => [{ path, message: msg }];

function checkEnum(schema: FieldSchema, value: any, path: string): ValidationError[] {
  if (!schema.enum) return [];
  const ok = (schema.enum as any[]).some((e) => e === value);
  return ok ? [] : E(path, `Value '${String(value)}' not in enum [${(schema.enum as any[]).map(String).join(", ")}]`);
}
function checkPattern(schema: FieldSchema, value: any, path: string): ValidationError[] {
  if (!schema.pattern) return [];
  if (typeof value !== "string") return E(path, "Pattern provided but value is not a string");
  try { const re = new RegExp(schema.pattern); return re.test(value) ? [] : E(path, `Value '${value}' does not match /${schema.pattern}/`); }
  catch { return E(path, `Invalid regex pattern: ${schema.pattern}`); }
}

export function validateVars(schema: Schema, value: any, path = ""): ValidationError[] {
  switch (schema.kind) {
    case "string":
    case "html":
      if (isNil(value)) return schema.optional ? [] : E(path, "Required string missing");
      if (typeof value !== "string") return E(path, "Expected string");
      return [...checkEnum(schema, value, path), ...checkPattern(schema, value, path)];
    case "url":
      if (isNil(value)) return schema.optional ? [] : E(path, "Required url missing");
      if (typeof value !== "string") return E(path, "Expected url string");
      try { new URL(value); } catch { return E(path, "Invalid URL"); }
      return [...checkEnum(schema, value, path), ...checkPattern(schema, value, path)];
    case "number":
      if (isNil(value)) return schema.optional ? [] : E(path, "Required number missing");
      if (typeof value !== "number" || Number.isNaN(value)) return E(path, "Expected number");
      return checkEnum(schema, value, path);
    case "boolean":
      if (isNil(value)) return schema.optional ? [] : E(path, "Required boolean missing");
      if (typeof value !== "boolean") return E(path, "Expected boolean");
      return checkEnum(schema, value, path);
    case "array":
      if (isNil(value)) return schema.optional ? [] : E(path, "Required array missing");
      if (!Array.isArray(value)) return E(path, "Expected array");
      return value.flatMap((v, i) => validateVars(schema.of, v, `${path}[${i}]`));
    case "object":
      if (isNil(value)) return schema.optional ? [] : E(path, "Required object missing");
      if (typeof value !== "object") return E(path, "Expected object");
      return Object.entries(schema.fields || {}).flatMap(([k, s]) => validateVars(s as Schema, (value as any)[k], path ? `${path}.${k}` : k));
    default:
      return E(path, "Unknown schema kind");
  }
}
