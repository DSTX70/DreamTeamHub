Manual QA:
1) Mount routes: app.use(require("./server/routes/ops_settings.route").router);
2) Open /ops/settings (route to OpsSettings.tsx).
3) Enter Slack URL, Save, Test Webhook (verify Slack receives message).
4) Toggle Email + SMTP creds, Save, Test Email.
5) Press Scan now; verify low-stock events + alert firing if any SKUs are below threshold.
