# Ops Settings — Notifiers Toggle + Scan Now

**Date:** 2025-11-06

This drop adds a tiny **Ops Settings** pane to configure low-stock notifiers (Slack webhook URL, email on/off + SMTP) and a **Scan now** button that triggers the DB-backed scheduler once.

## What’s included

### Server
- `server/routes/ops_settings.route.ts`
  - `GET /api/ops/settings/notifiers` — read settings (env-defaults overlaid by stored values).
  - `POST /api/ops/settings/notifiers` — save settings (persists to a small JSON file on disk).
  - `POST /api/ops/settings/test-webhook` — sends a test payload with the current Slack URL.
  - `POST /api/ops/settings/test-email` — sends a test email (if enabled and SMTP config present).

- `server/notifiers/settingsStore.ts` — simple JSON-backed store (`/data/ops_settings.json`) with safe fallbacks.

### Client
- `client/src/pages/ops/OpsSettings.tsx` — UI with fields for Slack URL, Email enable switch, SMTP fields, **Save**, **Test**, and **Scan now** buttons.
- `client/src/pages/ops/components/FormRow.tsx` — small shared form row.

### Notes
- Route responses are plain JSON; ensure your ops auth protects `/api/ops/settings/*` endpoints.
- The scheduler runner from the previous drop exposes an on-demand scan via `POST /api/ops/inventory/scan-now` (already included earlier).

## Mount

```ts
// server/app.ts
app.use(require("./server/routes/ops_settings.route").router);
```

## Add a client route
Render `OpsSettings` at something like `/ops/settings`.

