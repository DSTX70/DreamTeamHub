# Ops Menu — Role Badge + Conditional Settings

**Date:** 2025-11-07

Updates the Ops dropdown menu to:
- Fetch roles from `/api/ops/_auth/ping` (uses your new auth middleware)
- Show a small **ops_admin** badge if the role is present
- **Hide the Settings link** unless the user has the `ops_admin` role

Drop-in replacement for `client/src/components/HeaderOpsMenu.tsx`.
