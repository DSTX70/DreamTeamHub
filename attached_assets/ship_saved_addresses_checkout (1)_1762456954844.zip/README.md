# Ship: Saved Addresses → Checkout Hook (Autofill + Validation)

This drop wires checkout to:
- **Autofill** from the user's default saved address
- **Picker** to swap to any saved address
- **Validation** for country/state/postal + phone normalization
- **Server endpoints** for default address + validation
- **Tests** for the validation logic

## Mount
```ts
app.use(require("./server/routes/checkout_address.route").router);
```

## Client router
Add a route for `/checkout` rendering `client/src/pages/checkout/Checkout.tsx`.

## Notes
- Uses existing `/api/account/addresses` CRUD (seed endpoint available).
- `POST /api/checkout/address/validate` returns structured field errors.
