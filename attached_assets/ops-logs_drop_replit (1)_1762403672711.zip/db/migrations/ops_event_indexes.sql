-- Optional performance indexes for ops_event
CREATE INDEX IF NOT EXISTS idx_ops_event_at_desc ON ops_event (at DESC);
CREATE INDEX IF NOT EXISTS idx_ops_event_kind ON ops_event (kind);
CREATE INDEX IF NOT EXISTS idx_ops_event_owner ON ops_event (owner_type, owner_id);
