// Basic sanity test for /ops/logs
import { test, expect } from "@playwright/test";

test("ops logs page lists events and filters", async ({ page }) => {
  await page.goto("/ops/logs");
  await expect(page.getByText("Ops Logs")).toBeVisible();
  await page.selectOption('select:has-text("Kind")', "PUBLISH");
  await page.click("text=Refresh");
  // If no PUBLISH events exist yet, page still loads fine.
  await expect(page).toHaveTitle(/Ops|Logs/i);
});
