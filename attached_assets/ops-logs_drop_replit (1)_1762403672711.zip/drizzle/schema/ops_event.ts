import { pgTable, text, timestamp, uuid, jsonb } from "drizzle-orm/pg-core";

export const opsEvent = pgTable("ops_event", {
  id: uuid("id").defaultRandom().primaryKey(),
  at: timestamp("at", { withTimezone: true }).defaultNow().notNull(),
  kind: text("kind").notNull(),       // PUBLISH, ERROR, WO_START, PROMOTE, BU_VIEW, etc.
  message: text("message"),
  actor: text("actor"),
  ownerType: text("owner_type"),      // BU | BRAND | PRODUCT | PROJECT (or custom)
  ownerId: text("owner_id"),
  meta: jsonb("meta"),
});
