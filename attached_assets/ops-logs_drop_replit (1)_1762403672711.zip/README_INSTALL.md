# /ops/logs Drop — Replit Install

> Owner: Forge • Branch: `feature/ops-logs` • Gate: page loads, filters work, CSV downloads

## 1) Copy files
- `drizzle/schema/ops_event.ts`
- `db/migrations/ops_event_indexes.sql`
- `server/api/ops_events.route.ts`
- `server/sse_ops_tail.ts` (optional live tail)
- `web/pages/ops/logs.tsx`
- `web/lib/ops.ts`
- `e2e/e2e_ops_logs.spec.ts` (optional)

## 2) Wire routes
In your Express bootstrap (e.g., `server/index.ts`):

```ts
import express from "express";
import rateLimit from "express-rate-limit";
import { postOpsEvent, getOpsEvents, getOpsEventsCsv } from "./api/ops_events.route";

const app = express();
app.use(express.json({ limit: "1mb" }));

// Protect with staff/admin auth as appropriate
app.use("/api/ops/events", rateLimit({ windowMs: 60_000, max: 120 }));

app.post("/api/ops/events", postOpsEvent);
app.get("/api/ops/events", getOpsEvents);
app.get("/api/ops/events.csv", getOpsEventsCsv);

// optional: live tail
// import { sseOpsTail } from "./sse_ops_tail";
// app.get("/api/ops/tail", sseOpsTail);
```

## 3) DB
- Ensure `ops_event` table exists; run `db/migrations/ops_event_indexes.sql`.
- Confirm `db` import path in `server/api/ops_events.route.ts` matches your project.

## 4) Client
- Visit `/ops/logs` to view, filter, auto-refresh, and **Export CSV**.
- Fire sample event from anywhere in the app:
```ts
import { logOpsEvent } from "@/web/lib/ops";
logOpsEvent({ kind: "PUBLISH", message: "hello", owner_type: "BU", owner_id: "test" });
```

## 5) Done criteria
- Page renders with filters and refresh.
- CSV downloads and opens in a spreadsheet.
- (Optional) Playwright test passes: `npx playwright test e2e/e2e_ops_logs.spec.ts`
