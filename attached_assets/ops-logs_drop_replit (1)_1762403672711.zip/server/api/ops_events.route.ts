import type { Request, Response } from "express";
import { db } from "../drizzle/db";          // <-- adapt import path to your project
import { opsEvent } from "../drizzle/schema/ops_event";
import { and, desc, eq, gt, lt } from "drizzle-orm";
import z from "zod";

// ---------- POST /api/ops/events ----------
// Create a new ops event (fire-and-forget logging from services / UI)
const EventBody = z.object({
  kind: z.string().min(2),
  message: z.string().optional(),
  actor: z.string().optional(),
  owner_type: z.string().optional(),
  owner_id: z.string().optional(),
  meta: z.record(z.any()).optional(),
});

export async function postOpsEvent(req: Request, res: Response) {
  const parsed = EventBody.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });

  const b = parsed.data;
  const row = {
    kind: b.kind,
    message: b.message ?? null,
    actor: b.actor ?? (req.user?.email ?? "system"),
    ownerType: b.owner_type ?? null,
    ownerId: b.owner_id ?? null,
    meta: b.meta ?? null,
  };

  const [inserted] = await db.insert(opsEvent).values(row).returning();
  return res.status(201).json(inserted);
}

// Shared query builder
async function fetchEvents(req: Request) {
  const limit = Math.max(1, Math.min(Number(req.query.limit ?? 100), 200));
  const kind = (req.query.kind ? String(req.query.kind).trim() : "") || undefined;
  const ownerType = (req.query.owner_type ? String(req.query.owner_type).trim().toUpperCase() : "") || undefined;
  const ownerId = (req.query.owner_id ? String(req.query.owner_id).trim() : "") || undefined;
  const cursor = req.query.cursor ? new Date(String(req.query.cursor)) : null;
  const dir = (String(req.query.dir || "prev") === "next") ? "next" : "prev";

  const where = and(
    kind ? eq(opsEvent.kind, kind) : undefined,
    ownerType ? eq(opsEvent.ownerType, ownerType) : undefined,
    ownerId ? eq(opsEvent.ownerId, ownerId) : undefined,
    cursor ? (dir === "prev" ? lt(opsEvent.at, cursor) : gt(opsEvent.at, cursor)) : undefined
  );

  const rows = await db.select().from(opsEvent)
    .where(where as any)
    .orderBy(desc(opsEvent.at))
    .limit(limit + 1);

  // pagination headers
  const hasMore = rows.length > limit;
  const page = hasMore ? rows.slice(0, limit) : rows;
  const nextCursor = page.length ? page[page.length - 1].at : null;
  (req as any)._fetchedRows = page;

  return { page, hasMore, nextCursor };
}

// ---------- GET /api/ops/events ----------
export async function getOpsEvents(req: Request, res: Response) {
  const { page, hasMore, nextCursor } = await fetchEvents(req);
  res.setHeader("X-Has-More", hasMore ? "1" : "0");
  res.setHeader("X-Next-Cursor", nextCursor ? new Date(nextCursor).toISOString() : "");
  return res.json(page);
}

// ---------- GET /api/ops/events.csv ----------
export async function getOpsEventsCsv(req: Request, res: Response) {
  req.query.limit = String(Math.min(Number(req.query.limit ?? 1000), 5000)); // cap CSV
  const { page } = await fetchEvents(req);
  const header = ["id","at","kind","actor","owner_type","owner_id","message","meta"].join(",");
  const rows = page.map((x: any) => {
    const meta = x.meta ? JSON.stringify(x.meta).replaceAll('"','""') : "";
    const cols = [
      x.id, x.at?.toISOString?.() ?? x.at, x.kind, x.actor ?? "", x.ownerType ?? "", x.ownerId ?? "",
      (x.message ?? "").replaceAll('"','""'),
      meta
    ];
    return '"' + cols.join('","') + '"';
  });
  res.setHeader("content-type", "text/csv; charset=utf-8");
  res.send([header, *rows].join("\n"));
}
