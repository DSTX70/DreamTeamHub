import type { Request, Response } from "express";
import { EventEmitter } from "node:events";

export const opsEmitter = new EventEmitter();

export function sseOpsTail(req: Request, res: Response) {
  res.writeHead(200, {
    "Content-Type": "text/event-stream",
    "Cache-Control": "no-cache",
    Connection: "keep-alive",
  });
  const onEvent = (row: any) => res.write(`data: ${JSON.stringify(row)}\n\n`);
  opsEmitter.on("ops", onEvent);
  req.on("close", () => opsEmitter.off("ops", onEvent));
}
