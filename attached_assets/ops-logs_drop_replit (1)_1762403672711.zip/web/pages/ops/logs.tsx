import React, { useEffect, useMemo, useState } from "react";

type OpsRow = {
  id: string;
  at: string;
  kind: string;
  actor?: string | null;
  ownerType?: "BU" | "BRAND" | "PRODUCT" | "PROJECT" | null;
  ownerId?: string | null;
  message?: string | null;
  meta?: Record<string, any> | null;
};

const KIND_OPTIONS = ["", "BU_VIEW", "KNOWLEDGE_DRAFT", "KNOWLEDGE_PUBLISH", "PUBLISH", "WO_START", "PROMOTE", "ERROR"];
const OWNER_TYPES = ["", "BU", "BRAND", "PRODUCT", "PROJECT"];

function Badge({ children, tone = "default" }: { children: React.ReactNode; tone?: "default" | "green" | "amber" | "red" | "blue" }) {
  const map: Record<string, string> = {
    default: "border text-gray-700 bg-white",
    green: "border-green-300 text-green-800 bg-green-50",
    amber: "border-amber-300 text-amber-800 bg-amber-50",
    red: "border-rose-300 text-rose-800 bg-rose-50",
    blue: "border-blue-300 text-blue-800 bg-blue-50",
  };
  return <span className={`px-2 py-0.5 rounded-full text-xs border ${map[tone]}`}>{children}</span>;
}

function kindTone(kind: string) {
  if (kind === "ERROR") return "red";
  if (kind === "PUBLISH") return "green";
  if (kind.startsWith("KNOWLEDGE_")) return "blue";
  if (kind.includes("PROMOTE") || kind.includes("WO_")) return "amber";
  return "default";
}

export default function OpsLogsPage() {
  const [rows, setRows] = useState<OpsRow[]>([]);
  const [kind, setKind] = useState<string>("");
  const [ownerType, setOwnerType] = useState<string>("");
  const [ownerId, setOwnerId] = useState<string>("");
  const [loading, setLoading] = useState(false);
  const [auto, setAuto] = useState(false);

  const query = useMemo(() => {
    const p = new URLSearchParams();
    p.set("limit", "100");
    if (kind) p.set("kind", kind);
    if (ownerType) p.set("owner_type", ownerType);
    if (ownerId) p.set("owner_id", ownerId);
    return p.toString();
  }, [kind, ownerType, ownerId]);

  const load = async () => {
    setLoading(true);
    try {
      const r = await fetch(`/api/ops/events?${query}`, { headers: { "accept": "application/json" } });
      if (!r.ok) throw new Error(`HTTP ${r.status}`);
      const data = await r.json();
      setRows(data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);
  useEffect(() => { load(); }, [query]);
  useEffect(() => {
    if (!auto) return;
    const t = setInterval(load, 8000);
    return () => clearInterval(t);
  }, [auto, query]);

  const exportCsv = () => {
    const q = new URLSearchParams(query);
    window.location.href = `/api/ops/events.csv?${q.toString()}`;
  };

  return (
    <div className="max-w-6xl mx-auto p-6 space-y-4">
      <h1 className="text-2xl font-semibold">Ops Logs</h1>

      {/* Filters */}
      <div className="rounded-2xl border p-4 flex flex-wrap items-end gap-3">
        <div>
          <label className="text-sm block mb-1">Kind</label>
          <select className="border rounded px-2 py-1" value={kind} onChange={(e) => setKind(e.target.value)}>
            {KIND_OPTIONS.map(k => <option key={k} value={k}>{k || "All"}</option>)}
          </select>
        </div>
        <div>
          <label className="text-sm block mb-1">Owner Type</label>
          <select className="border rounded px-2 py-1" value={ownerType} onChange={(e) => setOwnerType(e.target.value)}>
            {OWNER_TYPES.map(o => <option key={o} value={o}>{o || "All"}</option>)}
          </select>
        </div>
        <div className="grow min-w-[240px]">
          <label className="text-sm block mb-1">Owner ID (UUID)</label>
          <input className="border rounded px-2 py-1 w-full" placeholder="optional" value={ownerId} onChange={(e) => setOwnerId(e.target.value)} />
        </div>
        <div className="flex items-center gap-2 ml-auto">
          <label className="text-sm flex items-center gap-2">
            <input type="checkbox" checked={auto} onChange={(e) => setAuto(e.target.checked)} />
            Auto-refresh
          </label>
          <button className="px-3 py-1 border rounded" onClick={load} disabled={loading}>
            {loading ? "Loading…" : "Refresh"}
          </button>
          <button className="px-3 py-1 border rounded" onClick={exportCsv}>
            Export CSV
          </button>
        </div>
      </div>

      {/* Table */}
      <div className="rounded-2xl border overflow-auto">
        <table className="min-w-full text-sm">
          <thead>
            <tr>
              <th className="text-left p-2 border-b">Time</th>
              <th className="text-left p-2 border-b">Kind</th>
              <th className="text-left p-2 border-b">Owner</th>
              <th className="text-left p-2 border-b">Actor</th>
              <th className="text-left p-2 border-b">Message</th>
              <th className="text-left p-2 border-b">Meta</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((r) => (
              <tr key={r.id}>
                <td className="p-2 border-b text-gray-700">{new Date(r.at).toLocaleString()}</td>
                <td className="p-2 border-b"><Badge tone={kindTone(r.kind)}>{r.kind}</Badge></td>
                <td className="p-2 border-b text-gray-700">{(r.ownerType || "—")}{r.ownerId ? ` · ${r.ownerId}` : ""}</td>
                <td className="p-2 border-b text-gray-700">{r.actor || "—"}</td>
                <td className="p-2 border-b text-gray-700">{r.message || "—"}</td>
                <td className="p-2 border-b text-xs text-gray-600">
                  {r.meta ? <pre className="whitespace-pre-wrap">{JSON.stringify(r.meta, null, 2)}</pre> : "—"}
                </td>
              </tr>
            ))}
            {!rows.length && (
              <tr><td className="p-2 text-gray-500" colSpan={6}>No events.</td></tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
