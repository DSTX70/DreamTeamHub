export async function logOpsEvent(input: {
  kind: string;
  message?: string;
  owner_type?: "BU" | "BRAND" | "PRODUCT" | "PROJECT";
  owner_id?: string;
  meta?: Record<string, unknown>;
}) {
  try {
    await fetch("/api/ops/events", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(input),
      keepalive: true,
    });
  } catch {}
}
