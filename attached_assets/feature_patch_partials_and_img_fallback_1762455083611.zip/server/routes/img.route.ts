// server/routes/img.route.ts
import express, { Request, Response } from "express";
import path from "path";
import fs from "fs";
import sharp from "sharp";

export const router = express.Router();

router.get("/img", async (req: Request, res: Response) => {
  try {
    const rawSrc = String(req.query.src || "");
    if (!rawSrc.startsWith("/")) return res.status(400).send("Invalid src");

    const publicRoot = path.join(process.cwd(), "public");
    const abs = path.join(publicRoot, rawSrc);
    if (!abs.startsWith(publicRoot)) return res.status(403).send("Forbidden src");
    if (!fs.existsSync(abs)) return res.status(404).send("Not found");

    const w = Number(req.query.w || 0);
    const fmt = String(req.query.fmt || "").toLowerCase();

    const meta = await sharp(abs).metadata();
    const sourceWidth = meta.width || 0;
    const ext = path.extname(abs).toLowerCase();

    // If a width was requested but the source is already smaller, and no format conversion requested:
    // fallback to original (no resize, no convert).
    if (w > 0 && sourceWidth > 0 && sourceWidth <= w && !fmt) {
      if (ext === ".png") res.type("image/png");
      else if (ext === ".webp") res.type("image/webp");
      else if (ext === ".avif") res.type("image/avif");
      else res.type("image/jpeg");
      res.setHeader("Cache-Control", "public, max-age=31536000, immutable");
      return fs.createReadStream(abs).pipe(res);
    }

    let pipeline = sharp(abs);
    if (w > 0) pipeline = pipeline.resize({ width: w, withoutEnlargement: true });

    switch (fmt) {
      case "webp": pipeline = pipeline.webp({ quality: 82 }); res.type("image/webp"); break;
      case "avif": pipeline = pipeline.avif({ quality: 60 }); res.type("image/avif"); break;
      case "jpeg":
      case "jpg": pipeline = pipeline.jpeg({ quality: 85, mozjpeg: true }); res.type("image/jpeg"); break;
      case "png": pipeline = pipeline.png({ compressionLevel: 9 }); res.type("image/png"); break;
      default:
        if (ext === ".png") res.type("image/png");
        else if (ext === ".webp") res.type("image/webp");
        else if (ext === ".avif") res.type("image/avif");
        else res.type("image/jpeg");
        break;
    }

    res.setHeader("Cache-Control", "public, max-age=31536000, immutable");
    const buf = await pipeline.toBuffer();
    res.end(buf);
  } catch (e: any) {
    res.status(500).send("img error: " + e.message);
  }
});
