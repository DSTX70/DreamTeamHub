// server/lib/mailer.ts
import fs from "fs";
import path from "path";
import mjml2html from "mjml";

/**
 * Load partial file contents from directory (e.g., emails/tx/partials).
 */
function loadPartials(dir: string): Record<string, string> {
  const map: Record<string, string> = {};
  if (!fs.existsSync(dir)) return map;
  for (const f of fs.readdirSync(dir)) {
    const name = path.basename(f, path.extname(f)); // header.mjml -> header
    map[name] = fs.readFileSync(path.join(dir, f), "utf-8");
  }
  return map;
}

/**
 * Very small Handlebars-like expander for:
 *  - {{> partialName}}
 *  - {{#each arrayName}} ... {{/each}}
 *  - {{var}} replacements (shallow)
 * This is intentionally minimal and safe for transactional email blocks.
 */
function expandTemplate(input: string, vars: any, partials: Record<string, string>): string {
  let tpl = input;

  // 1) Expand {{> partial }} first (top-level includes)
  tpl = tpl.replace(/\{\{\>\s*([a-zA-Z0-9_\-]+)\s*\}\}/g, (_m, name) => {
    return partials[name] || "";
  });

  // 2) Expand {{#each items}} ... {{/each}}
  tpl = tpl.replace(/\{\{#each\s+([a-zA-Z0-9_\.]+)\}\}([\s\S]*?)\{\{\/each\}\}/g, (_m, arrKey, inner) => {
    const arr = arrKey.split(".").reduce((acc:any, k:string) => (acc ? acc[k] : undefined), vars);
    if (!Array.isArray(arr) || arr.length === 0) return "";
    return arr.map((item:any) => {
      // inner may contain {{> partial}} — expand again with item-level vars
      let block = inner.replace(/\{\{\>\s*([a-zA-Z0-9_\-]+)\s*\}\}/g, (_m2, name2) => partials[name2] || "");
      // shallow variable replacement from item
      block = block.replace(/\{\{\s*([a-zA-Z0-9_\.]+)\s*\}\}/g, (_m3, key) => {
        const val = key.split(".").reduce((acc:any, k:string) => (acc ? acc[k] : undefined), item);
        return (val !== undefined && val !== null) ? String(val) : "";
      });
      return block;
    }).join("");
  });

  // 3) Replace simple {{var}} (from root vars)
  tpl = tpl.replace(/\{\{\s*([a-zA-Z0-9_\.]+)\s*\}\}/g, (_m, key) => {
    const val = key.split(".").reduce((acc:any, k:string) => (acc ? acc[k] : undefined), vars);
    return (val !== undefined && val !== null) ? String(val) : "";
  });

  return tpl;
}

/**
 * Render MJML with minimal templating + partials.
 * @param mjmlPath path to main .mjml template
 * @param vars template variables (etaDate, orderId, lineItems[], brandHeaderUrl, etc.)
 * @param partialsDir directory with .mjml partials (e.g., emails/tx/partials)
 */
export function renderTxEmailFromFile(mjmlPath: string, vars: Record<string, any> = {}, partialsDir = "emails/tx/partials") {
  const raw = fs.readFileSync(mjmlPath, "utf-8");
  const partials = loadPartials(partialsDir);
  const expanded = expandTemplate(raw, vars, partials);
  const { html, errors } = mjml2html(expanded, { validationLevel: "soft" });
  if (errors && errors.length) console.warn("[MJML] warnings:", errors);
  return html;
}

/**
 * Legacy helper: directly render a string without file/partials
 * (kept for backwards-compat)
 */
export function renderTxEmail(mjmlTemplate: string, vars: Record<string, string|number> = {}) {
  let mjml = mjmlTemplate;
  for (const [k, v] of Object.entries(vars)) {
    mjml = mjml.replaceAll(new RegExp(`{{\\s*${k}\\s*}}`, "g"), String(v));
  }
  const { html, errors } = mjml2html(mjml, { validationLevel: "soft" });
  if (errors && errors.length) console.warn("[MJML] warnings:", errors);
  return html;
}
