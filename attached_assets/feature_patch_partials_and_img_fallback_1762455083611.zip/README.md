# Patch: Partials + Image Fallback

## Partials (MJML)
Use `renderTxEmailFromFile("emails/tx/order_shipped.mjml", vars, "emails/tx/partials")`.
Supports:
- `{{> header}}`, `{{> line_item}}`
- `{{#each lineItems}} ... {{/each}}`
- `{{var}}` (root and within each)

## Image Fallback
When `w` is provided and the source image is **already smaller** than `w`, and no `fmt` is provided, the original image is streamed without upscaling.
