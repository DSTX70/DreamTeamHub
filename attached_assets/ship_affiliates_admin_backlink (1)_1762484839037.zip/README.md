# Affiliates Admin — "Back to Report" link

**Date:** 2025-11-07

Adds a **Back to Report** link at the top of Affiliates Admin when a `?code=` filter is present.
The link targets `/ops/affiliates` (adjust if your router uses a different path for the report page).

## File
- `client/src/pages/ops/AffiliatesAdmin.tsx` — updated to show the link conditionally.
