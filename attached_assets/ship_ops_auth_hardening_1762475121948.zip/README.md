# Ops Auth Hardening — Middleware + Guards + Tests

Date: 2025-11-07

Adds a minimal, production-friendly auth layer for /api/ops endpoints:

- opsAuth() middleware
  - Supports static bearer token via OPS_API_TOKEN (recommended quick start).
  - Optional JWT support if you later add jsonwebtoken and set OPS_JWT_SECRET.
  - Attaches req.auth = {{ sub, roles: string[] }} when authenticated.
- requireRole("ops_admin") guard
  - Blocks unless roles contains the required role.

Includes a demo route (/api/ops/_auth/ping) and supertest unit tests.

Env:
- OPS_API_TOKEN: super-long random token
- ALLOW_DEV_OPS_ROLES=true (optional for dev/tests)
- OPS_JWT_SECRET (optional if you add jsonwebtoken)

Mount:
  app.use("/api/ops", opsAuth());
  app.use(require("./server/routes/ops.auth.ping.route").default);

Tests assume static token with OPS_API_TOKEN=test-token.
