export type AuthContext = {
  sub?: string;
  roles: string[];
};
