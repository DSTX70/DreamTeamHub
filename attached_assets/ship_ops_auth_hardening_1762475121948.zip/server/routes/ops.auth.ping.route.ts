import express, { Request, Response } from "express";
import { opsAuth } from "../middleware/opsAuth";
import { requireRole } from "../middleware/requireRole";

const router = express.Router();

router.get("/api/ops/_auth/ping", opsAuth(), (req: Request, res: Response) => {
  res.json({ ok: true, who: (req as any).auth || null });
});

router.get("/api/ops/_auth/admin", opsAuth(), requireRole("ops_admin"), (_req: Request, res: Response) => {
  res.json({ ok: true, admin: true });
});

export default router;
