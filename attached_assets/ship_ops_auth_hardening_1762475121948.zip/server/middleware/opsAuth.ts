import type { Request, Response, NextFunction } from "express";
import type { AuthContext } from "../types/auth";

declare global {
  // eslint-disable-next-line no-var
  var __allowDevRoles: boolean | undefined;
}

function getBearer(req: Request) {
  const h = req.headers["authorization"];
  if (!h) return undefined;
  const m = /^Bearer\s+(.+)$/i.exec(Array.isArray(h) ? h[0] : h);
  return m?.[1];
}

function parseDevRoles(req: Request): string[] {
  const src = (req.headers["x-ops-roles"] || req.headers["x-roles"]) as string | undefined;
  if (!src) return [];
  return src.split(",").map(s => s.trim()).filter(Boolean);
}

export function opsAuth() {
  const tokenEnv = process.env.OPS_API_TOKEN || "";
  const allowDev = process.env.ALLOW_DEV_OPS_ROLES === "true";
  global.__allowDevRoles = allowDev;

  return (req: Request, res: Response, next: NextFunction) => {
    const bearer = getBearer(req) || (req.headers["x-ops-token"] as string | undefined);
    const auth: AuthContext = { sub: undefined, roles: [] };

    if (tokenEnv) {
      if (!bearer || bearer !== tokenEnv) {
        return res.status(401).json({ error: "Unauthorized (ops)" });
      }
      auth.sub = "ops-token";
      if (allowDev) auth.roles = parseDevRoles(req);
      (req as any).auth = auth;
      return next();
    }

    const secret = process.env.OPS_JWT_SECRET;
    if (secret) {
      try {
        // eslint-disable-next-line @typescript-eslint/no-var-requires
        const jwt = require("jsonwebtoken") as any;
        if (!bearer) return res.status(401).json({ error: "Missing bearer" });
        const decoded = jwt.verify(bearer, secret);
        auth.sub = decoded.sub || decoded.user || "ops";
        auth.roles = Array.isArray(decoded.roles) ? decoded.roles : [];
        (req as any).auth = auth;
        return next();
      } catch (e) {
        return res.status(401).json({ error: "Unauthorized (jwt)" });
      }
    }

    return res.status(401).json({ error: "Unauthorized (no ops auth configured)" });
  };
}
