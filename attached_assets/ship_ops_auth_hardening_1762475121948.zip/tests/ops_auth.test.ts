/** @jest-environment node */
import express from "express";
import request from "supertest";
import opsAuthPing from "../server/routes/ops.auth.ping.route";
import { opsAuth } from "../server/middleware/opsAuth";
import { requireRole } from "../server/middleware/requireRole";

describe("Ops Auth middleware", () => {
  const build = () => {
    const app = express();
    process.env.OPS_API_TOKEN = "test-token";
    process.env.ALLOW_DEV_OPS_ROLES = "true";
    app.use("/api/ops", opsAuth());
    app.get("/api/ops/hello", (_req, res) => res.json({ ok: true }));
    app.get("/api/ops/need-admin", requireRole("ops_admin"), (_req, res) => res.json({ ok: true }));
    return app;
  };

  it("rejects without token", async () => {
    const app = build();
    const res = await request(app).get("/api/ops/hello");
    expect(res.status).toBe(401);
  });

  it("rejects with wrong token", async () => {
    const app = build();
    const res = await request(app).get("/api/ops/hello").set("Authorization", "Bearer nope");
    expect(res.status).toBe(401);
  });

  it("allows with correct token", async () => {
    const app = build();
    const res = await request(app).get("/api/ops/hello").set("Authorization", "Bearer test-token");
    expect(res.status).toBe(200);
    expect(res.body.ok).toBe(true);
  });

  it("enforces requireRole", async () => {
    const app = build();
    const noRole = await request(app).get("/api/ops/need-admin").set("Authorization", "Bearer test-token");
    expect(noRole.status).toBe(403);
    const ok = await request(app).get("/api/ops/need-admin")
      .set("Authorization", "Bearer test-token")
      .set("X-Ops-Roles", "ops_admin");
    expect(ok.status).toBe(200);
  });

  it("demo route works", async () => {
    const app = express();
    process.env.OPS_API_TOKEN = "test-token";
    app.use(opsAuthPing);
    const res = await request(app).get("/api/ops/_auth/ping").set("Authorization", "Bearer test-token");
    expect(res.status).toBe(200);
    expect(res.body.ok).toBe(true);
  });
});
