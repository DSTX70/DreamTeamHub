import { API } from './api'

// --- Pods ---
export async function listPods(){
  const r = await fetch(`${API}/pods`)
  if(!r.ok) throw new Error('HTTP ' + r.status)
  const d = await r.json()
  return d.items || []
}

export async function createPod(payload: {name:string, charter?:string, owners?:string[], thread_id?:string}){
  const r = await fetch(`${API}/pods`, {
    method:'POST', headers:{'content-type':'application/json'},
    body: JSON.stringify(payload)
  })
  if(!r.ok) throw new Error('HTTP ' + r.status)
  return await r.json()
}

// Optional: Pod update (if backend supports it)
// export async function updatePod(id:number, payload:any){ ... }

// --- Roles ---
export async function listRoles(){
  const r = await fetch(`${API}/roles`)
  if(!r.ok) throw new Error('HTTP ' + r.status)
  return await r.json()
}

export async function createRole(body: any){
  const r = await fetch(`${API}/roles`, { method:'POST', headers:{'content-type':'application/json'}, body: JSON.stringify(body) })
  if(!r.ok) throw new Error('HTTP ' + r.status)
  return await r.json()
}

export async function updateRole(id:number, body:any){
  const r = await fetch(`${API}/roles/${id}`, { method:'PUT', headers:{'content-type':'application/json'}, body: JSON.stringify(body) })
  if(!r.ok) throw new Error('HTTP ' + r.status)
  return await r.json()
}

// --- Agents ---
export async function listAgents(){
  const r = await fetch(`${API}/agents`)
  if(!r.ok) throw new Error('HTTP ' + r.status)
  return await r.json()
}

export async function upsertAgent(spec:any){
  const r = await fetch(`${API}/agents`, { method:'POST', headers:{'content-type':'application/json'}, body: JSON.stringify(spec) })
  if(!r.ok) throw new Error('HTTP ' + r.status)
  return await r.json()
}
