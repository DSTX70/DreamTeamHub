import React, { useEffect, useMemo, useState } from 'react'
import { listPods, createPod, listRoles, createRole, updateRole, listAgents, upsertAgent } from '../lib/admin'

type RoleCard = {
  id?: number
  handle: string; title: string; pod: string
  purpose?: string; core_functions?: string[]; responsibilities?: string[]
  definition_of_done?: string[]; links?: string[]; tags?: string[]
  tone_voice?: string
}

export default function RosterAdmin(){
  return (
    <div className="section" style={{display:'grid', gap:20}}>
      <PodsPanel/>
      <RolesPanel/>
      <AgentsPanel/>
    </div>
  )
}

function PodsPanel(){
  const [items, setItems] = useState<any[]>([])
  const [form, setForm] = useState({name:'', charter:'', owners:'', thread_id:''})

  useEffect(()=>{ (async()=>{
    try{ setItems(await listPods()) }catch{ setItems([]) }
  })() }, [])

  const ownersArray = useMemo(()=>form.owners.split(',').map(s=>s.trim()).filter(Boolean), [form.owners])

  const submit = async ()=>{
    if(!form.name.trim()) return
    const payload = { name: form.name.trim(), charter: form.charter, owners: ownersArray, thread_id: form.thread_id }
    await createPod(payload)
    setItems(await listPods())
    setForm({name:'', charter:'', owners:'', thread_id:''})
  }

  return (
    <section>
      <h2 style={{margin:'0 0 8px'}}>Pods — Onboard</h2>
      <div style={{display:'grid', gap:10, gridTemplateColumns:'repeat(auto-fit, minmax(240px,1fr))'}}>
        <input placeholder="Pod name (e.g., Marketing & Comms)" value={form.name} onChange={e=>setForm({...form, name:e.target.value})} />
        <input placeholder="Owners (comma-separated handles)" value={form.owners} onChange={e=>setForm({...form, owners:e.target.value})} />
        <input placeholder="Thread ID (optional)" value={form.thread_id} onChange={e=>setForm({...form, thread_id:e.target.value})} />
        <input placeholder="Charter (short)" value={form.charter} onChange={e=>setForm({...form, charter:e.target.value})} />
      </div>
      <div style={{marginTop:10}}>
        <button className="btn" data-pod="control" onClick={submit}><span className="icon">➕</span>Create Pod</button>
      </div>

      <h3 style={{marginTop:16}}>Existing Pods</h3>
      <div style={{display:'grid', gap:10}}>
        {items.map((p:any)=>(
          <div key={p.id} className="card">
            <div className="rail"></div>
            <div className="inner">
              <div className="title">{p.name}</div>
              <div className="chips">
                <span className="chip">Owners: {(p.owners||[]).join(', ')}</span>
                {p.thread_id ? <span className="chip">thread: {p.thread_id}</span> : null}
              </div>
              <p className="oneliner">{p.charter || ''}</p>
            </div>
          </div>
        ))}
      </div>
    </section>
  )
}

function RolesPanel(){
  const [items, setItems] = useState<RoleCard[]>([])
  const [sel, setSel] = useState<RoleCard|null>(null)
  const [form, setForm] = useState<RoleCard>({handle:'', title:'', pod:'', purpose:'', core_functions:[], responsibilities:[], definition_of_done:[], links:[], tags:[], tone_voice:''})
  const [core, setCore] = useState('')
  const [dod, setDod] = useState('')
  const [tags, setTags] = useState('')

  useEffect(()=>{ (async()=>{
    try{ setItems(await listRoles()) }catch{ setItems([]) }
  })() }, [])

  useEffect(()=>{
    if(!sel) return
    setForm({
      id: sel.id, handle: sel.handle, title: sel.title, pod: sel.pod,
      purpose: sel.purpose || '',
      core_functions: (sel.core_functions||[]).slice(),
      responsibilities: (sel.responsibilities||[]).slice(),
      definition_of_done: (sel.definition_of_done||[]).slice(),
      links: (sel.links||[]).slice(),
      tags: (sel.tags||[]).slice(),
      tone_voice: sel.tone_voice || ''
    })
    setCore((sel.core_functions||[]).join('; '))
    setDod((sel.definition_of_done||[]).join('; '))
    setTags((sel.tags||[]).join(', '))
  }, [sel])

  const submit = async ()=>{
    const payload = {
      handle: form.handle, title: form.title, pod: form.pod,
      purpose: form.purpose || '',
      core_functions: core.split(';').map(s=>s.trim()).filter(Boolean),
      responsibilities: form.responsibilities || [],
      definition_of_done: dod.split(';').map(s=>s.trim()).filter(Boolean),
      links: form.links || [],
      tags: tags.split(',').map(s=>s.trim()).filter(Boolean),
      tone_voice: form.tone_voice || ''
    }
    if(form.id){
      await updateRole(form.id, payload)
    } else {
      await createRole(payload)
    }
    setItems(await listRoles())
    setSel(null)
    setForm({handle:'', title:'', pod:'', purpose:'', core_functions:[], responsibilities:[], definition_of_done:[], links:[], tags:[], tone_voice:''})
    setCore(''); setDod(''); setTags('')
  }

  return (
    <section>
      <h2 style={{margin:'16px 0 8px'}}>Role Cards — Onboard & Edit</h2>
      <div style={{display:'grid', gap:10, gridTemplateColumns:'repeat(auto-fit, minmax(240px,1fr))'}}>
        <input placeholder="Handle (e.g., Prism)" value={form.handle} onChange={e=>setForm({...form, handle:e.target.value})} />
        <input placeholder="Title (e.g., Marketing Lead)" value={form.title} onChange={e=>setForm({...form, title:e.target.value})} />
        <input placeholder="Pod (e.g., Marketing & Comms)" value={form.pod} onChange={e=>setForm({...form, pod:e.target.value})} />
        <input placeholder="Tone/Voice (optional)" value={form.tone_voice||''} onChange={e=>setForm({...form, tone_voice:e.target.value})} />
        <input placeholder="Purpose (1–2 lines)" value={form.purpose||''} onChange={e=>setForm({...form, purpose:e.target.value})} />
        <input placeholder="Core Functions (semicolon-separated)" value={core} onChange={e=>setCore(e.target.value)} />
        <input placeholder="Definition of Done (semicolon-separated)" value={dod} onChange={e=>setDod(e.target.value)} />
        <input placeholder="Tags (comma-separated)" value={tags} onChange={e=>setTags(e.target.value)} />
      </div>
      <div style={{marginTop:10}}>
        <button className="btn" data-pod="brand" onClick={submit}><span className="icon">💾</span>{form.id ? 'Update Role' : 'Create Role'}</button>
        {form.id ? <button className="btn btn--secondary btn--sm" onClick={()=>{ setSel(null); setForm({handle:'', title:'', pod:'', purpose:'', core_functions:[], responsibilities:[], definition_of_done:[], links:[], tags:[], tone_voice:''}); setCore(''); setDod(''); setTags('') }}>Cancel Edit</button> : null}
      </div>

      <h3 style={{marginTop:16}}>Existing Roles</h3>
      <div style={{display:'grid', gap:10}}>
        {items.map((r:RoleCard)=>(
          <div key={r.id || r.handle + r.title} className="card">
            <div className="rail"></div>
            <div className="inner">
              <div className="title">{r.handle} — {r.title}</div>
              <div className="chips"><span className="chip">{r.pod}</span>{(r.tags||[]).map((t,i)=><span className="chip" key={i}>{t}</span>)}</div>
              <p className="oneliner">{r.purpose||''}</p>
              <button className="btn btn--secondary btn--sm" onClick={()=>setSel(r)}>Edit</button>
            </div>
          </div>
        ))}
      </div>
    </section>
  )
}

function AgentsPanel(){
  const [agents, setAgents] = useState<any[]>([])
  const [spec, setSpec] = useState<any>({
    handle:'', title:'', pod:'', thread_id:'',
    system_prompt:'', instruction_blocks:'', tools:'threads.post,drive.search,zip.kit,hash.index',
    policies:'{"may_post_threads":false,"may_modify_drive":false}'
  })

  useEffect(()=>{ (async()=>{
    try{ const d = await listAgents(); setAgents(d.agents||[]) }catch{ setAgents([]) }
  })() }, [])

  const submit = async ()=>{
    if(!spec.handle || !spec.title || !spec.pod) return
    const payload = {
      handle: spec.handle,
      title: spec.title,
      pod: spec.pod,
      thread_id: spec.thread_id || '',
      system_prompt: spec.system_prompt || `You are ${spec.handle}, ${spec.title} in the ${spec.pod} pod.`,
      instruction_blocks: (spec.instruction_blocks||'').split('\n').map((s:string)=>s.trim()).filter(Boolean),
      tools: (spec.tools||'').split(',').map((s:string)=>s.trim()).filter(Boolean),
      policies: (()=>{ try{ return JSON.parse(spec.policies||'{}') } catch{ return {} }})()
    }
    await upsertAgent(payload)
    const d = await listAgents(); setAgents(d.agents||[])
    setSpec({
      handle:'', title:'', pod:'', thread_id:'', system_prompt:'',
      instruction_blocks:'', tools:'threads.post,drive.search,zip.kit,hash.index',
      policies:'{"may_post_threads":false,"may_modify_drive":false}'
    })
  }

  return (
    <section>
      <h2 style={{margin:'16px 0 8px'}}>Agents — Onboard & Upsert</h2>
      <div style={{display:'grid', gap:10, gridTemplateColumns:'repeat(auto-fit, minmax(240px,1fr))'}}>
        <input placeholder="Handle (e.g., Prism)" value={spec.handle} onChange={e=>setSpec({...spec, handle:e.target.value})} />
        <input placeholder="Title (e.g., Marketing Lead)" value={spec.title} onChange={e=>setSpec({...spec, title:e.target.value})} />
        <input placeholder="Pod (e.g., Marketing & Comms)" value={spec.pod} onChange={e=>setSpec({...spec, pod:e.target.value})} />
        <input placeholder="Thread ID (optional)" value={spec.thread_id} onChange={e=>setSpec({...spec, thread_id:e.target.value})} />
        <input placeholder="System Prompt (override)" value={spec.system_prompt} onChange={e=>setSpec({...spec, system_prompt:e.target.value})} />
        <textarea placeholder="Instruction Blocks (one per line)" rows={3} value={spec.instruction_blocks} onChange={e=>setSpec({...spec, instruction_blocks:e.target.value})} />
        <input placeholder="Tools (comma-separated)" value={spec.tools} onChange={e=>setSpec({...spec, tools:e.target.value})} />
        <textarea placeholder='Policies (JSON)' rows={3} value={spec.policies} onChange={e=>setSpec({...spec, policies:e.target.value})} />
      </div>
      <div style={{marginTop:10}}>
        <button className="btn" data-pod="product" onClick={submit}><span className="icon">🤖</span>Upsert Agent</button>
      </div>

      <h3 style={{marginTop:16}}>Registered Agents</h3>
      <div style={{display:'grid', gap:10}}>
        {agents.map((a:any)=>(
          <div key={a.handle} className="card">
            <div className="rail"></div>
            <div className="inner">
              <div className="title">{a.handle} — {a.title}</div>
              <div className="chips"><span className="chip">{a.pod}</span>{a.thread_id ? <span className="chip">thread: {a.thread_id}</span> : null}</div>
              <p className="oneliner">{(a.system_prompt||'').slice(0,160)}{(a.system_prompt||'').length>160?'…':''}</p>
            </div>
          </div>
        ))}
      </div>
    </section>
  )
}
