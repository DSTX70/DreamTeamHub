# Roster Admin Patch — Vite App

This patch adds **Roster Admin** to onboard and review **Pods**, **Role Cards**, and **Agents**.

## Files
- `src/components/RosterAdmin.tsx` — forms + listings
- `src/lib/admin.ts` — API helpers
- `src/App.patch.tsx` — drop-in replacement for your `src/App.tsx` (or merge manually)

## How to apply
1) Unzip into your Vite project root (merge into `src/`).
2) Replace your `src/App.tsx` with the contents of `src/App.patch.tsx` (or copy the tab and import lines manually).
3) Run the app:
   ```bash
   npm install
   npm run dev -- --host
   ```

## Backend endpoints used
- **Pods**: `GET /pods`, `POST /pods` (update optional if you add it)
- **Roles**: `GET /roles`, `POST /roles`, `PUT /roles/{id}`
- **Agents**: `GET /agents`, `POST /agents` (upsert)

> Optional: Add `PUT /pods/{id}` and `DELETE /pods/{id}` to your backend if you want inline editing/removal for Pods.
