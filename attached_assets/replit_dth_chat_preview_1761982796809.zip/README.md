# Dream Team Chat — Brand-locked Preview

This Replit project serves the same preview you saw in ChatGPT.

## Run
- Click **Run** (or `npm start`).
- Replit will start on the default `$PORT`.

## Files
- `public/dth_tokens.css` — your brand tokens (CSS vars).
- `public/index.html` — the Chat page preview (imports the tokens).
- `server.mjs` — tiny Express static server.
- `.replit` + `package.json` — run config.

## Notes
- Colors come **only** from `/public/dth_tokens.css` (no hard-coded hex).
- Decision Log orange token is referenced as `--core-orange` fallback `#FF965A`.
- To update branding, replace the tokens file and refresh.

## Optional: Export PDF
Use headless Chrome to print the page:

```bash
/Applications/Google\ Chrome.app/Contents/MacOS/Google\ Chrome \
  --headless=new --disable-gpu \
  --print-to-pdf=Chat_Preview.pdf \
  --print-to-pdf-no-header \
  "http://localhost:$PORT/"
```
