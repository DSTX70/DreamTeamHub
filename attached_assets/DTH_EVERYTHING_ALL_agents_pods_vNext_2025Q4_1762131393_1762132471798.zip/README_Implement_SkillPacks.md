# Skill Packs — ALL Agents (vNext · 2025 Q4)
Place the /agents folder at repo root. Loader must scan each agent folder for prompt.txt, tools.yaml, goldens.csv, eval.yaml.
