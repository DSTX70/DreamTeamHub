# DTH Uploader — Work Item Attachments (Drop-in)
Generated: 2025-11-12T02:31:36.360578 UTC

This adds file uploads with allowlist + size limits and links uploads to a Work Item.

## Routes
- `POST /api/ops/uploader/upload?work_item_id=...`
- `GET /api/ops/uploader/config`
- `POST /api/ops/uploader/config`
- `GET /api/work-items/:id/files`

## Setup
1) Copy `server/` and `client/` into your repo.
2) `npm i express multer uuid googleapis aws-sdk mime-types`
3) Wire routes in your Express app (see server/index wiring in README of previous message).
4) Env: see `.env.example`.
