import React, { useEffect, useState } from 'react';

type FileRec = { id:string; name:string; url:string; size:number; contentType:string; uploadedAt:string };

export function FilesPanel({ workItemId }: { workItemId: string }) {
  const [files, setFiles] = useState<FileRec[]>([]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string|undefined>();

  async function refresh(){
    const res = await fetch(`/api/work-items/${workItemId}/files`);
    const data = await res.json();
    setFiles(data.files || []);
  }
  useEffect(()=>{ refresh(); },[workItemId]);

  async function onUpload(e: React.ChangeEvent<HTMLInputElement>){
    const f = e.target.files?.[0]; if(!f) return;
    setBusy(true); setError(undefined);
    const fd = new FormData(); fd.append('file', f);
    const res = await fetch(`/api/ops/uploader/upload?work_item_id=${encodeURIComponent(workItemId)}`, { method:'POST', body: fd });
    const data = await res.json(); if(!data.ok) setError(data.error || 'Upload failed'); await refresh(); setBusy(false);
  }

  return (<div className="p-4 rounded-2xl border border-gray-700">
    <div className="flex items-center justify-between mb-3">
      <h3 className="text-lg font-semibold">Files</h3>
      <label className="cursor-pointer px-3 py-1 rounded bg-gray-200 text-black">
        {busy ? 'Uploading…' : 'Upload File'}
        <input type="file" className="hidden" onChange={onUpload} disabled={busy} />
      </label>
    </div>
    {error && <div className="text-red-400 text-sm mb-2">{error}</div>}
    <ul className="space-y-2">
      {files.map(f => (<li key={f.id} className="flex items-center justify-between bg-gray-900 rounded p-2">
        <div className="truncate">
          <a className="underline" href={f.url} target="_blank" rel="noreferrer">{f.name}</a>
          <div className="text-xs text-gray-400">{(Number(f.size)/1024).toFixed(1)} KB • {f.contentType}</div>
        </div>
        <div className="text-xs text-gray-500">{new Date(f.uploadedAt).toLocaleString()}</div>
      </li>))}
      {files.length===0 && <li className="text-sm text-gray-400">No files yet.</li>}
    </ul>
  </div>);
}
