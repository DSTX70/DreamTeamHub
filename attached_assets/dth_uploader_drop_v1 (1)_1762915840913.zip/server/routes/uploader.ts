import express from 'express';
import multer from 'multer';
import { v4 as uuid } from 'uuid';
import path from 'path';
import { getConfig, saveConfig } from '../services/config';
import { getStorage } from '../services/storage';
import { linkFileToWorkItem } from '../services/workitems';
import mime from 'mime-types';

export const uploaderRouter = express.Router();
const upload = multer({ storage: multer.memoryStorage() });

uploaderRouter.get('/config', (_req, res) => res.json(getConfig()));

uploaderRouter.post('/config', (req, res) => {
  const { backend, allowlist, maxMb } = req.body || {};
  const cfg = getConfig();
  if (backend) cfg.backend = backend;
  if (allowlist) cfg.allowlist = allowlist;
  if (maxMb) cfg.maxMb = maxMb;
  saveConfig(cfg);
  res.json({ ok: true, cfg });
});

uploaderRouter.post('/upload', upload.single('file'), async (req, res) => {
  try {
    const workItemId = String(req.query.work_item_id || '');
    if (!workItemId) return res.status(400).json({ error: 'work_item_id required' });
    if (!req.file) return res.status(400).json({ error: 'No file' });

    const cfg = getConfig();
    const allow = (cfg.allowlist || '').split(',').map(s => s.trim().toLowerCase()).filter(Boolean);
    const maxBytes = (cfg.maxMb || 25) * 1024 * 1024;

    const originalName = req.file.originalname;
    const ext = path.extname(originalName).replace('.', '').toLowerCase();
    const detected = mime.lookup(originalName) || req.file.mimetype || 'application/octet-stream';

    if (allow.length && !allow.includes(ext)) return res.status(415).json({ error: `Extension .${ext} not allowed` });
    if (req.file.size > maxBytes) return res.status(413).json({ error: `File too large. Max ${cfg.maxMb} MB` });

    const id = uuid();
    const storage = getStorage(cfg.backend);
    const saved = await storage.save({ id, name: originalName, buffer: req.file.buffer, contentType: detected });

    await linkFileToWorkItem(workItemId, {
      id, work_item_id: workItemId, name: originalName, url: saved.url,
      size: req.file.size, contentType: detected, uploadedAt: new Date().toISOString()
    });

    res.json({ ok: true, id, url: saved.url });
  } catch (e:any) {
    res.status(500).json({ error: 'upload_failed', detail: String(e?.message || e) });
  }
});
