import express from 'express';
import { listFilesForWorkItem } from '../services/workitems';

export const workitemFilesRouter = express.Router();
workitemFilesRouter.get('/work-items/:id/files', async (req, res) => {
  const files = await listFilesForWorkItem(String(req.params.id));
  res.json({ ok: true, files });
});
