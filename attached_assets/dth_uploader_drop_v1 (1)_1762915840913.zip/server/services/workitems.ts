import fs from 'fs';
import path from 'path';

type FileRecord = { id:string; work_item_id:string; name:string; url:string; size:number; contentType:string; uploadedAt:string };
const DB_PATH = process.env.WORKITEMS_DB || './data/workitems.db.json';

function readDb(): FileRecord[]{
  if (!fs.existsSync(DB_PATH)){
    fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });
    fs.writeFileSync(DB_PATH, '[]');
  }
  return JSON.parse(fs.readFileSync(DB_PATH, 'utf-8'));
}
function writeDb(rows: FileRecord[]){ fs.mkdirSync(path.dirname(DB_PATH), { recursive: true }); fs.writeFileSync(DB_PATH, JSON.stringify(rows, null, 2)); }

export async function linkFileToWorkItem(workItemId:string, rec:FileRecord){
  const rows = readDb(); rows.push(rec); writeDb(rows);
}
export async function listFilesForWorkItem(workItemId:string){ return readDb().filter(r => r.work_item_id === workItemId); }
