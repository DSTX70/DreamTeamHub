import { getLocalStorage } from './local';
import { getDriveStorage } from './drive';
import { getS3Storage } from './s3';
export type SaveArgs = { id:string; name:string; buffer:Buffer; contentType:string };
export type Saved = { url:string };
export function getStorage(backend:string){ return backend==='drive'?getDriveStorage():backend==='s3'?getS3Storage():getLocalStorage(); }
