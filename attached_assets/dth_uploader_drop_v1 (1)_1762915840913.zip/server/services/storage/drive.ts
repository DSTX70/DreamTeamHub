import { google } from 'googleapis';
import type { SaveArgs, Saved } from './index';

export function getDriveStorage(){
  const folderId = process.env.GOOGLE_DRIVE_FOLDER_ID || '';
  const auth = new google.auth.GoogleAuth({ scopes: ['https://www.googleapis.com/auth/drive.file'] });
  const drive = google.drive({ version: 'v3', auth });
  return {
    async save(args: SaveArgs): Promise<Saved>{
      const res = await drive.files.create({
        requestBody: { name: args.name, parents: folderId? [folderId]: undefined },
        media: { mimeType: args.contentType, body: Buffer.from(args.buffer) as any }
      });
      const fileId = res.data.id as string;
      await drive.permissions.create({ fileId, requestBody: { role: 'reader', type: 'anyone' } });
      return { url: `https://drive.google.com/uc?id=${fileId}` };
    }
  }
}
