import fs from 'fs';
import path from 'path';
import type { SaveArgs, Saved } from './index';

const ROOT = process.env.UPLOADS_DIR || './uploads';

export function getLocalStorage(){
  return {
    async save(args: SaveArgs): Promise<Saved>{
      const dir = path.resolve(process.cwd(), ROOT);
      if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
      const fname = `${args.id}__${args.name}`.replace(/\s+/g,'_');
      const fpath = path.join(dir, fname);
      fs.writeFileSync(fpath, args.buffer);
      return { url: `/uploads/${fname}` };
    }
  }
}
