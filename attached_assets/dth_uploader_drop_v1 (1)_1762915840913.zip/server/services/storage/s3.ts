import AWS from 'aws-sdk';
import type { SaveArgs, Saved } from './index';

export function getS3Storage(){
  const s3 = new AWS.S3({
    region: process.env.S3_REGION,
    accessKeyId: process.env.S3_ACCESS_KEY,
    secretAccessKey: process.env.S3_SECRET_KEY,
    signatureVersion: 'v4'
  });
  const bucket = process.env.S3_BUCKET as string;
  return {
    async save(args: SaveArgs): Promise<Saved>{
      const Key = `${args.id}__${args.name}`.replace(/\s+/g,'_');
      await s3.putObject({ Bucket: bucket, Key, Body: args.buffer, ContentType: args.contentType, ACL: 'public-read' }).promise();
      return { url: `https://${bucket}.s3.${process.env.S3_REGION}.amazonaws.com/${Key}` };
    }
  }
}
