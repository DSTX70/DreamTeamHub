# ship_healthz_prod_readiness_and_alerts

Adds productionized health:
- Readiness `/api/healthz` with per-probe timeouts
- Liveness `/api/healthz/livez` fast path
- Deploy markers (`POST /api/admin/deploy/mark`, `GET /api/admin/deploy/last`)
- Overview “Last Deploy” chip
- Example Alertmanager `rules.yml` for p95 latency + 5xx rate

## Mount
```ts
// server/index.ts
import healthzRouter from "./routes/healthz.route";
import adminDeployRouter from "./routes/admin_deploy.route";

app.use("/api/healthz", healthzRouter);
app.use("/api/admin/deploy", adminDeployRouter);
```

Chip:
- Apply `patches/ops_overview_last_deploy.diff` to render the chip on `/ops/overview`

Deploy mark (CI step):
```
curl -X POST https://yourhost/api/admin/deploy/mark   -H "Content-Type: application/json"   -d '{"sha":"'$GITHUB_SHA'","tag":"'$RELEASE_TAG'","actor":"'$GITHUB_ACTOR'"}'
```

Prometheus/Alertmanager:
- Drop `ops/alertmanager/rules.yml` into your rules path and reload.
- Adjust metric names/labels to your stack.
