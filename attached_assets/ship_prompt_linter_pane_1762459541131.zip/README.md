# Prompt Linter Pane — `/llm/provider`

**Date:** 2025-11-06

This drop adds a lightweight Prompt Linter + auto-fix suggestions focused on improving **structured JSON output reliability**. It includes:

- A **pane** under `/llm/provider` that lets you paste:
  1) A *system/instruction prompt*, and
  2) An optional **JSON Schema** for the expected output.
- An in-browser **linter** that flags common schema issues that reduce JSON compliance and offers **safe auto-fixes**.
- A tiny **prompt-augment** helper to prepend “return JSON only” constraints + a compact schema summary.
- A few focused **tests** documenting rule behavior.

## What’s included

### Shared
- `shared/lint/jsonSchemaUtils.ts` — helpers to walk/inspect JSON Schemas.
- `shared/lint/rules.ts` — rule set (anti-patterns + fixers).
- `shared/lint/promptLinter.ts` — orchestrator that runs rules and produces diagnostics & fixes.
- `shared/lint/promptAugment.ts` — `augmentForJson(schema, opts)` returns an extra instruction block for consistent JSON-only output.

### Client
- `client/src/pages/llm/ProviderPromptLinter.tsx` — the pane UI: editors, lint results, auto-fix buttons, and a preview of the augmented prompt.
- `client/src/pages/llm/components/LintRuleCard.tsx` — small presentational component for rule output.

### Tests
- `tests/prompt_linter.test.ts` — basic rule coverage examples.

## Mount

Add a route in your client router:

```tsx
// client/src/AppRouter.tsx (example)
// <Route path="/llm/provider/linter" element={<ProviderPromptLinter />} />
```

## Usage

1) Open **LLM → Provider → Linter**.
2) Paste (or load) your output JSON Schema.
3) Hit **Run Lint** — review warnings/errors.
4) Click **Apply Fixes** to patch your schema (non-destructive; a patched JSON appears alongside).
5) Copy the **Augmented Instructions** block into your system prompt, or use it in your pipeline to boost structured output rates.

## Notes

- Rules are conservative and **never** remove fields. They only add constraints or surface warnings.
- This linter runs fully client-side; wiring it server-side later is trivial since the engine lives in `/shared`.
- Future ideas: per-model presets, stricter union checks, disallowed keys list, and schema → UI auto-form generator (ties into your earlier plan).
