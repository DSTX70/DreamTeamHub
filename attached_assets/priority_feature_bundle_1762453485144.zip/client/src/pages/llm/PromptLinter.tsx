import React from "react";
export default function PromptLinterUI() {
  const [schema, setSchema] = React.useState<string>('{"type":"object","properties":{"name":{"type":"string"}}}');
  const [issues, setIssues] = React.useState<any[]>([]); const [fixed, setFixed] = React.useState<string>("");
  const run = async (autoFix: boolean) => {
    try { const body = { schema: JSON.parse(schema), autoFix }; const r = await fetch("/api/dev/prompt-lint", { method:"POST", headers:{ "Content-Type":"application/json" }, body: JSON.stringify(body) }); const j = await r.json(); setIssues(j.issues||[]); setFixed(JSON.stringify(j.schema||{}, null, 2)); } catch { alert("Invalid JSON"); }
  };
  return (<div className="space-y-3"><h2 className="text-lg font-semibold">Prompt Linter</h2>
    <textarea className="border p-2 rounded w-full h-40" value={schema} onChange={(e)=>setSchema(e.target.value)} />
    <div className="flex gap-2"><button className="px-3 py-1 border rounded" onClick={()=>run(false)}>Lint</button><button className="px-3 py-1 border rounded" onClick={()=>run(true)}>Lint + Auto-Fix</button></div>
    <div><h3 className="font-medium">Issues</h3><ul className="list-disc pl-5 text-sm">{issues.map((it,i)=>(<li key={i}>{it.code}: {it.message}</li>))}</ul></div>
    <div><h3 className="font-medium">Fixed Schema</h3><pre className="text-xs bg-gray-50 p-2 rounded overflow-x-auto">{fixed}</pre></div>
  </div>);
}
