import React from "react";
import Breadcrumbs from "../../components/Breadcrumbs";
import LeftRail from "../../components/LeftRail";
export default function AffiliatesReport() {
  return (<div className="flex"><LeftRail /><main className="p-6 space-y-6 flex-1">
    <Breadcrumbs trail={[{ label: "Ops" }, { label: "Affiliates" }]} />
    <h1 className="text-xl font-semibold">Affiliate Payout Report</h1>
    <a className="underline" href="/api/affiliates/report.csv">Download CSV</a>
  </main></div>);
}
