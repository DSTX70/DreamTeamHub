import React from "react";
import { useParams } from "react-router-dom";
import Breadcrumbs from "../../components/Breadcrumbs";
import LeftRail from "../../components/LeftRail";
export default function OrderPage() {
  const { id } = useParams<{ id: string }>(); const [eta, setEta] = React.useState<any>(null);
  React.useEffect(()=>{ fetch("/api/estimator/eta", { method: "POST", headers: { "Content-Type":"application/json" }, body: JSON.stringify({ postalFrom:"85001", postalTo:"10001", shipSpeed:"standard" }) }).then(r=>r.json()).then(setEta).catch(()=>setEta(null)); }, [id]);
  return (<div className="flex"><LeftRail /><main className="p-6 space-y-6 flex-1">
    <Breadcrumbs trail={[{ label: "Orders", to: "/orders" }, { label: `Order ${id}` }]} />
    <h1 className="text-xl font-semibold">Order {id}</h1>
    {!eta ? <p>Loading ETA…</p> : (<p className="text-sm text-gray-700">Estimated delivery: <strong>{new Date(eta.etaDate).toLocaleDateString()}</strong> ({eta.etaDays} days, {eta.confidence} confidence)</p>)}
  </main></div>);
}
