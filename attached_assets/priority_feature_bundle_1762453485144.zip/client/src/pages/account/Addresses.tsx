import React from "react";
import Breadcrumbs from "../../components/Breadcrumbs";
import LeftRail from "../../components/LeftRail";
type Address = { id: string; label?: string; name: string; line1: string; line2?: string; city: string; region?: string; postal: string; country: string; phone?: string; isDefault?: boolean; };
export default function Addresses() {
  const [items, setItems] = React.useState<Address[]>([]);
  const [form, setForm] = React.useState<Partial<Address>>({ country: "US" });
  const load = async () => { const r = await fetch("/api/account/addresses"); setItems(await r.json()); };
  React.useEffect(()=>{ load(); }, []);
  const submit = async (e: React.FormEvent) => { e.preventDefault();
    const r = await fetch("/api/account/addresses", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(form) });
    if (r.ok) { setForm({ country: "US" }); load(); } else { alert("Validation failed"); } };
  const setDefault = async (id: string) => { await fetch("/api/account/addresses/"+id, { method: "PUT", headers:{"Content-Type":"application/json"}, body: JSON.stringify({ isDefault:true })}); load(); };
  const remove = async (id: string) => { await fetch("/api/account/addresses/"+id, { method: "DELETE" }); load(); };
  return (<div className="flex"><LeftRail /><main className="p-6 space-y-6 flex-1">
    <Breadcrumbs trail={[{ label: "Account", to: "/account" }, { label: "Addresses" }]} />
    <h1 className="text-xl font-semibold">Saved Addresses</h1>
    <form className="grid grid-cols-2 gap-4" onSubmit={submit}>
      <input className="border p-2 rounded" placeholder="Label" value={form.label||""} onChange={e=>setForm({ ...form, label: e.target.value })}/>
      <input className="border p-2 rounded" placeholder="Full Name" value={form.name||""} onChange={e=>setForm({ ...form, name: e.target.value })} required/>
      <input className="border p-2 rounded col-span-2" placeholder="Address Line 1" value={form.line1||""} onChange={e=>setForm({ ...form, line1: e.target.value })} required/>
      <input className="border p-2 rounded col-span-2" placeholder="Address Line 2" value={form.line2||""} onChange={e=>setForm({ ...form, line2: e.target.value })}/>
      <input className="border p-2 rounded" placeholder="City" value={form.city||""} onChange={e=>setForm({ ...form, city: e.target.value })} required/>
      <input className="border p-2 rounded" placeholder="Region/State" value={form.region||""} onChange={e=>setForm({ ...form, region: e.target.value })}/>
      <input className="border p-2 rounded" placeholder="Postal Code" value={form.postal||""} onChange={e=>setForm({ ...form, postal: e.target.value })} required/>
      <input className="border p-2 rounded" placeholder="Country" value={form.country||""} onChange={e=>setForm({ ...form, country: e.target.value })} required/>
      <input className="border p-2 rounded" placeholder="Phone" value={form.phone||""} onChange={e=>setForm({ ...form, phone: e.target.value })}/>
      <div className="col-span-2 flex items-center gap-2"><input id="isDefault" type="checkbox" checked={!!form.isDefault} onChange={e=>setForm({ ...form, isDefault: e.target.checked })}/><label htmlFor="isDefault">Set as default</label></div>
      <button className="px-4 py-2 border rounded col-span-2" type="submit">Save Address</button>
    </form>
    <div className="divide-y">{items.map(a => (<div key={a.id} className="py-3 flex items-center justify-between gap-4">
      <div><div className="font-medium">{a.label || "Address"}</div><div className="text-sm text-gray-600">{a.name} — {a.line1}{a.line2?(", "+a.line2):""}, {a.city}, {a.region} {a.postal}, {a.country} {a.phone?(" • "+a.phone):""}</div></div>
      <div className="flex items-center gap-2">{a.isDefault ? <span className="text-xs px-2 py-1 rounded bg-gray-200">Default</span> : <button className="text-sm underline" onClick={()=>setDefault(a.id)}>Make Default</button>}<button className="text-sm text-red-600 underline" onClick={()=>remove(a.id)}>Delete</button></div>
    </div>))}</div>
  </main></div>);
}
