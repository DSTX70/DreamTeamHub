# Priority Feature Bundle (Saved Addresses → Affiliates) — Replit Drop
Branches:
- feature/saved-addresses
- feature/delivery-estimator
- feature/low-stock-alerts
- feature/responsive-images
- feature/affiliates

Includes: schemas, server routes, client pages, tests, and quick follow-ups (LLM expectJson, Prompt Linter UI, snapshots).
