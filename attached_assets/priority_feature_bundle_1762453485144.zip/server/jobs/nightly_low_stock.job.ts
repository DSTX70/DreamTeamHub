import fetch from "node-fetch";
export async function runNightlyLowStockCheck(baseUrl = "http://localhost:3000") {
  const csv = await (await fetch(baseUrl + "/api/inventory/low-stock.csv")).text();
  try {
    await fetch(baseUrl + "/api/ops/alert", { method: "POST", headers: {"Content-Type":"application/json"}, body: JSON.stringify({ kind:"warn", message:"Low-stock report available", meta:{ csvLength: csv.length } }) });
  } catch {}
  return csv;
}
