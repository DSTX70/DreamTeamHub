import express, { Request, Response } from "express";
import { lintSchema } from "../../shared/utils/promptLinter";
export const router = express.Router();
router.post("/api/dev/prompt-lint", (req: Request, res: Response) => {
  const { schema, autoFix = false } = req.body || {}; if (!schema) return res.status(400).json({ error: "Missing schema" });
  res.json(lintSchema(schema, { autoFix }));
});
