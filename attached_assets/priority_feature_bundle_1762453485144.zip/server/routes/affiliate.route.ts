import express, { Request, Response } from "express";
import crypto from "crypto";
import type { AffiliateCode, OrderAttribution } from "../../shared/schema";
export const router = express.Router();
const codes = new Map<string, AffiliateCode>(); const attributions: OrderAttribution[] = [];
const now = () => new Date().toISOString(); const hash = (s:string) => crypto.createHash("sha256").update(s).digest("hex").slice(0,16);
router.post("/api/affiliates/code", (req: Request, res: Response) => {
  const { code, ownerUserId, pct = 10, active = true } = req.body || {};
  if (!code || !ownerUserId) return res.status(400).json({ error: "Missing fields" });
  const ac: AffiliateCode = { code: String(code).toUpperCase(), ownerUserId, pct, active, createdAt: now() }; codes.set(ac.code, ac); res.json(ac);
});
router.get("/r/:code", (req: Request, res: Response) => {
  const code = String(req.params.code || "").toUpperCase(); const exists = codes.get(code);
  if (!exists || !exists.active) return res.status(404).send("Invalid code");
  res.cookie("aff_code", code, { httpOnly: true, sameSite: "lax", maxAge: 1000*60*60*24*30 }); res.redirect("/");
});
router.post("/api/affiliates/attribute", (req: Request, res: Response) => {
  const { orderId, email, referrer } = req.body || {}; if (!orderId || !email) return res.status(400).json({ error: "Missing fields" });
  const code = String(req.cookies?.aff_code || req.body?.affCode || "");
  const rec: OrderAttribution = { orderId, affiliateCode: code || null, referrer: referrer || null, ipHash: req.ip ? hash(req.ip) : null, emailHash: hash(String(email).toLowerCase()), createdAt: now() };
  attributions.push(rec); res.json(rec);
});
router.get("/api/affiliates/report.csv", (_req: Request, res: Response) => {
  const rows = [["orderId","affiliateCode","referrer","ipHash","emailHash","createdAt"]];
  for (const r of attributions) rows.push([r.orderId, r.affiliateCode || "", r.referrer || "", r.ipHash || "", r.emailHash || "", r.createdAt]);
  res.type("text/csv").send(rows.map(r=>r.join(",")).join("\n"));
});
