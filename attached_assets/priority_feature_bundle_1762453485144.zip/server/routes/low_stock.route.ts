import express, { Request, Response } from "express";
import type { ProductInventory } from "../../shared/schema";
export const router = express.Router();
const inv = new Map<string, ProductInventory>();
const now = () => new Date().toISOString();
router.post("/api/inventory/set", (req: Request, res: Response) => {
  const { productId, sku, quantity, lowStockThreshold = 5 } = req.body || {};
  if (!productId || !sku || typeof quantity !== "number") return res.status(400).json({ error: "Missing fields" });
  const item: ProductInventory = { productId, sku, quantity, lowStockThreshold, updatedAt: now() };
  inv.set(sku, item); res.json(item);
});
router.get("/api/inventory/low-stock.csv", (_req: Request, res: Response) => {
  const rows = [["sku","productId","quantity","threshold","updatedAt"]];
  for (const r of inv.values()) if (r.lowStockThreshold !== undefined && r.quantity <= r.lowStockThreshold) rows.push([r.sku, r.productId, String(r.quantity), String(r.lowStockThreshold), r.updatedAt]);
  res.type("text/csv").send(rows.map(r=>r.join(",")).join("\n"));
});
export function decrementOnOrder(sku: string, qty: number) {
  const r = inv.get(sku); if (!r) return; r.quantity = Math.max(0, r.quantity - qty); r.updatedAt = now();
}
