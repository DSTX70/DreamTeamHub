import express, { Request, Response } from "express";
export const router = express.Router();
router.post("/api/estimator/eta", (req: Request, res: Response) => {
  const { carrier = "usps", postalFrom = "", postalTo = "", shipSpeed = "standard" } = req.body || {};
  let base = shipSpeed === "expedited" ? 2 : 5;
  if (postalFrom.slice(0,1) === postalTo.slice(0,1) && shipSpeed !== "expedited") base = 3;
  const eta = new Date(); eta.setDate(eta.getDate() + base);
  res.json({ etaDays: base, etaDate: eta.toISOString(), confidence: shipSpeed === "expedited" ? "high" : "med", carrier });
});
