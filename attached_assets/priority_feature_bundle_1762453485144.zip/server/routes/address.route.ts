import express, { Request, Response } from "express";
import crypto from "crypto";
import type { Address, ID } from "../../shared/schema";
export const router = express.Router();
const store = new Map<ID, Address>();
const now = () => new Date().toISOString();
const id = () => crypto.randomUUID();
router.get("/api/account/addresses", (req: Request, res: Response) => {
  const userId = String(req.headers["x-user-id"] || "demo-user");
  res.json(Array.from(store.values()).filter(a => a.userId === userId));
});
router.post("/api/account/addresses", (req: Request, res: Response) => {
  const userId = String(req.headers["x-user-id"] || "demo-user");
  const b = req.body || {};
  if (!b.name || !b.line1 || !b.city || !b.postal || !b.country) return res.status(400).json({ error: "Missing required fields" });
  const item: Address = { id: id(), userId, label: b.label, name: b.name, line1: b.line1, line2: b.line2, city: b.city, region: b.region, postal: b.postal, country: b.country, phone: b.phone, isDefault: !!b.isDefault, createdAt: now(), updatedAt: now() };
  if (item.isDefault) for (const a of store.values()) if (a.userId === userId) a.isDefault = false;
  store.set(item.id, item); res.status(201).json(item);
});
router.put("/api/account/addresses/:id", (req: Request, res: Response) => {
  const userId = String(req.headers["x-user-id"] || "demo-user"); const a = store.get(req.params.id);
  if (!a || a.userId !== userId) return res.status(404).json({ error: "Not found" });
  const b = req.body || {}; Object.assign(a, { label: b.label ?? a.label, name: b.name ?? a.name, line1: b.line1 ?? a.line1, line2: b.line2 ?? a.line2, city: b.city ?? a.city, region: b.region ?? a.region, postal: b.postal ?? a.postal, country: b.country ?? a.country, phone: b.phone ?? a.phone, updatedAt: now() });
  if (b.isDefault !== undefined) { if (b.isDefault) for (const x of store.values()) if (x.userId === userId) x.isDefault = false; a.isDefault = !!b.isDefault; }
  res.json(a);
});
router.delete("/api/account/addresses/:id", (req: Request, res: Response) => {
  const userId = String(req.headers["x-user-id"] || "demo-user"); const a = store.get(req.params.id);
  if (!a || a.userId !== userId) return res.status(404).json({ error: "Not found" }); store.delete(a.id); res.status(204).end();
});
router.post("/api/account/addresses/seed", (_req: Request, res: Response) => {
  store.clear(); const userId = "demo-user";
  const mk = (d: Partial<Address>) => { const i: Address = { id: crypto.randomUUID(), userId, name: "Demo User", line1: "1 Main St", city: "Phoenix", postal: "85001", country: "US", createdAt: now(), updatedAt: now(), ...d } as Address; store.set(i.id, i); };
  mk({ label: "Home", isDefault: true }); mk({ label: "Office", line2: "Suite 200" }); res.json({ ok: true, count: Array.from(store.values()).length });
});
