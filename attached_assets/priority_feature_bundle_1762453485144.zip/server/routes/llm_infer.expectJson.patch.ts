import express, { Request, Response } from "express";
import { makeProvider } from "../../shared/llm/providers";
import { extractJson } from "../../shared/utils/json";
export const router = express.Router();
router.post("/api/llm/infer", async (req: Request, res: Response) => {
  try {
    const { provider = "mock", model = "gpt-4.1-mini", prompt = "", expectJson = false } = req.body || {};
    const llm = makeProvider({ provider, model }); const out = await llm.infer({ prompt });
    if (expectJson) { const parsed = extractJson(out.text); if (!parsed.ok) return res.status(422).json({ error: parsed.error }); return res.json(parsed.data); }
    res.type("text/plain").send(out.text);
  } catch (e:any) { res.status(400).json({ error: e.message }); }
});
