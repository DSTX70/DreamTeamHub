import express, { Request, Response } from "express";
export const router = express.Router();
router.get("/img", async (req: Request, res: Response) => {
  const src = String(req.query.src || ""); const w = Number(req.query.w || 0); const fmt = String(req.query.fmt || "");
  if (!src) return res.status(400).send("Missing src");
  res.setHeader("Cache-Control", "public, max-age=86400");
  res.setHeader("X-Img-Note", `stubbed resize w=${w||"auto"} fmt=${fmt||"orig"}`);
  res.redirect(src);
});
