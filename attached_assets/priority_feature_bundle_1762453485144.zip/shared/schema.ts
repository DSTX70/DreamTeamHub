export type ID = string;
export interface Address {
  id: ID; userId: ID; label?: string; name: string; line1: string; line2?: string;
  city: string; region?: string; postal: string; country: string; phone?: string;
  isDefault?: boolean; createdAt: string; updatedAt: string;
}
export interface ProductInventory {
  productId: ID; sku: string; quantity: number; lowStockThreshold?: number; updatedAt: string;
}
export interface OrderAttribution {
  orderId: ID; affiliateCode?: string|null; referrer?: string|null;
  ipHash?: string|null; emailHash?: string|null; createdAt: string;
}
export interface AffiliateCode { code: string; ownerUserId: ID; pct: number; active: boolean; createdAt: string; }
