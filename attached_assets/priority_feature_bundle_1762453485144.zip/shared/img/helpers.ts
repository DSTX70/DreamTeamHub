export function buildSrcSet(src: string, widths: number[] = [320,640,960,1280]) {
  return widths.map(w => `${src}?w=${w} ${w}w`).join(', ');
}
export function sizesForProductCard() { return '(max-width: 640px) 50vw, (max-width: 1024px) 33vw, 400px'; }
