import React from "react";
import renderer from "react-test-renderer";
import Breadcrumbs from "../client/src/components/Breadcrumbs";
import LeftRail from "../client/src/components/LeftRail";
test("Breadcrumbs snapshot", () => { const tree = renderer.create(<Breadcrumbs trail={[{label:"Home", to:"/"},{label:"Orders"}]} />).toJSON(); expect(tree).toMatchSnapshot(); });
test("LeftRail snapshot", () => { const tree = renderer.create(<LeftRail />).toJSON(); expect(tree).toMatchSnapshot(); });
