import request from "supertest";
import express from "express";
import { router as addr } from "../server/routes/address.route";
const app = express(); app.use(express.json()); app.use(addr);
describe("Saved Addresses", () => {
  it("seeds addresses", async () => { const r = await request(app).post("/api/account/addresses/seed"); expect(r.status).toBe(200); expect(r.body.ok).toBe(true); expect(r.body.count).toBeGreaterThanOrEqual(2); });
  it("lists addresses", async () => { await request(app).post("/api/account/addresses/seed"); const r = await request(app).get("/api/account/addresses"); expect(r.status).toBe(200); expect(Array.isArray(r.body)).toBe(true); });
  it("creates + updates default", async () => { await request(app).post("/api/account/addresses/seed"); const created = await request(app).post("/api/account/addresses").send({ name:"A", line1:"L1", city:"C", postal:"P", country:"US", isDefault:true }); expect(created.status).toBe(201); const list = await request(app).get("/api/account/addresses"); const defaults = list.body.filter((x:any)=>x.isDefault); expect(defaults.length).toBe(1); });
});
