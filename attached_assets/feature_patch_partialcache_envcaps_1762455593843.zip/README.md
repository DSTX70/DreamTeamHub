# Patch: Env Caps for Partial Cache

**What’s new**
- LRU caps are now tunable via env vars:
  - `PARTIAL_CACHE_MAX_DIRS` (default **8**, min 1)
  - `PARTIAL_CACHE_MAX_FILES` (default **32**, min 1)

**Updated file**
- `server/lib/mailer.ts`

**Example**
```bash
PARTIAL_CACHE_MAX_DIRS=4 PARTIAL_CACHE_MAX_FILES=16 npm run start
```
