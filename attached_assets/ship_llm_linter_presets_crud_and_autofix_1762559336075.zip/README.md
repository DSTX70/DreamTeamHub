# ship_llm_linter_presets_crud_and_autofix

Adds persisted LLM presets (in-memory CRUD), prompt/schema auto-fix helpers, and JSON extraction + validation.

## Server
```ts
import llmPresetsRouter from "./routes/llm_presets.route";
app.use("/api/llm/presets", express.json(), llmPresetsRouter);
```

## Client
- Page: `client/src/pages/llm/LinterPresetsCRUD.tsx`
- Helpers: `client/src/pages/llm/autofix.ts`
- Reuse your existing `SchemaForm.tsx` if present.

Route suggestion: `/llm/linter/presets`

## Install
```
npm i ajv swr
```

## Notes
- The server uses an in-memory store to keep the bundle self-contained; swap to your DB.
- Auto-fix adds minimal, safe constraints (`additionalProperties:false`, no markdown, JSON-only reply).
- Extraction tries fenced ```json blocks first, then uses a curly-brace heuristic.
