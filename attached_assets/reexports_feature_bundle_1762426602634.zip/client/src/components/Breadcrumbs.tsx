import { Link } from "react-router-dom";

export interface Crumb {
  label: string;
  to?: string;
}

export default function Breadcrumbs({ trail }: { trail: Crumb[] }) {
  return (
    <nav className="text-sm flex items-center gap-2" aria-label="Breadcrumb">
      {trail.map((c, i) => (
        <span key={i} className="flex items-center gap-2">
          {c.to ? <Link className="underline" to={c.to}>{c.label}</Link> : <span>{c.label}</span>}
          {i < trail.length - 1 && <span aria-hidden>/</span>}
        </span>
      ))}
    </nav>
  );
}
