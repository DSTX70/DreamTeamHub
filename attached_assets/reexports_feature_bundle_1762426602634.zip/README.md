# Re-Export: Feature Bundle (WO + Ops + LLM + Forms)

This bundle contains **drop-in files** for the items you listed. Paths assume a monorepo with `/server`, `/client`, and `/shared`.
If your repo paths differ, adjust imports accordingly.

## Contents (by ask)

1) **Playbook preview in WO Create**
   - `client/src/pages/wo/PlaybookPreview.tsx`
   - `shared/schemas/sample_playbook.schema.json`
   - `server/routes/wo_playbook_preview.route.ts`

2) **Onboarding wizard success links**
   - `client/src/pages/onboarding/Success.tsx`
   - `shared/schemas/onboarding_success.schema.json`

3) **Coverage deep-dive**
   - `client/src/pages/coverage/DeepDive.tsx`
   - `server/routes/coverage_report.route.ts`

4) **Alert hooks for ops**
   - `server/routes/ops_alert_hooks.route.ts`
   - `client/src/pages/ops/AlertHooksDemo.tsx`

5) **Breadcrumb & left-rail parity**
   - `client/src/components/Breadcrumbs.tsx`
   - `client/src/components/LeftRail.tsx`

6) **JSON Schema forms**
   - `client/src/forms/JsonSchemaForm.tsx`

7) **LLM providers (pluggable)**
   - `shared/llm/types.ts`
   - `shared/llm/providers.ts`
   - `server/routes/llm_infer.route.ts`
   - `client/src/pages/llm/ProviderSelect.tsx`

8) **JSON extraction (strict)**
   - `shared/utils/json.ts`

9) **Prompt linter (with suggest-fixes)**
   - `shared/utils/promptLinter.ts`
   - `shared/prompts/return_json_only.ts`

---

## Quick Start (Replit)
1. Unzip into your repo root (or copy files into matching folders).
2. Ensure your server mounts routes from `server/routes/*.route.ts`.
3. Add the client routes to your router (see file headers for example).
4. `npm i` (if you add any missing deps from your stack) → `npm run dev`.

> All code is **TypeScript**-ready and uses **React** on the client. No third-party form/LLM libs required.
