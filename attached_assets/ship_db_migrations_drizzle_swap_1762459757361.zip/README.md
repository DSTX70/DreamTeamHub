# DB Migrations (Drizzle) — Swap Affiliate & Inventory stores to DB

**Date:** 2025-11-06

This drop replaces the **in-memory** Affiliate & Inventory stores with a **Postgres**-backed implementation using **Drizzle ORM**.
It includes Drizzle config, schema files, SQL migrations, DAOs, and DB-backed route variants.

## What’s included

### Config & Schema
- `drizzle.config.ts` — Drizzle Kit config (Postgres). 
- `server/db/client.ts` — Drizzle client using `pg` + `DATABASE_URL`.
- `server/db/schema.ts` — Drizzle schema for affiliates, events, products, inventory events.

### Migrations (SQL)
- `drizzle/0001_init.sql` — Creates tables & indexes.
- `drizzle/0002_seed_products.sql` — Seeds initial products (example SKUs you used previously).

### DAOs
- `server/db/affiliateDao.ts` — Replacements for your in-memory Affiliate store.
- `server/db/inventoryDao.ts` — Replacements for your in-memory Inventory store.

### Routes (DB-backed)
- `server/routes/affiliate.route.db.ts` — Same endpoints as before, backed by DB.
- `server/routes/inventory.route.db.ts` — Same endpoints as before, backed by DB.

### Tests
- `tests/db_affiliate_inventory.test.ts` — minimal integration smoke with DAOs (assumes test DB).

### Env
- `.env.example` — `DATABASE_URL` and basic settings.

---

## Setup

1) **Install deps**
```
pnpm add drizzle-orm drizzle-kit pg dotenv
```

2) **Env**
Copy `.env.example` → `.env` and set `DATABASE_URL` (Postgres). Works with Supabase/Neon/Local.

3) **Generate + Run migrations**
If you’d like to use Drizzle Kit to diff from `schema.ts`, you can; but to keep this drop fast:
```
# Apply the provided SQL
psql "$DATABASE_URL" -f drizzle/0001_init.sql
psql "$DATABASE_URL" -f drizzle/0002_seed_products.sql
```

4) **Wire routes**
Replace in-memory mounts with DB-backed routes:
```ts
// server/app.ts
app.use(require("./server/routes/affiliate.route.db").router);
app.use(require("./server/routes/inventory.route.db").router);
```

> You can keep the old routes around; the DB-backed ones have `.db` in filename so you can toggle quickly.

5) **Run**
```
pnpm dev
```

## Notes
- Schemas are designed to be forward-compatible with per-affiliate commission rates, audit trails, and product metadata later.
- Time is stored in UTC with `timestamptz`. 
- Affiliate report SQL aggregates clicks, unique visitors (approx via ip|ua), orders, revenue & commission (flat rate param by API).
- Inventory scheduler: your existing `startLowStockScheduler` can call `inventoryDao.getLowStock()` and `inventoryDao.recordLowEvent()` (DB variants are included).
