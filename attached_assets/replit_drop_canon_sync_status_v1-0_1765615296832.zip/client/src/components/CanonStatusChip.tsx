import React from "react";
import { useCanonStatus } from "../hooks/useCanonStatus";

// If you use shadcn/ui, swap these for Badge + Tooltip components.
function Badge({
  children,
  tone,
}: {
  children: React.ReactNode;
  tone?: "default" | "warning" | "muted";
}) {
  const cls =
    tone === "warning"
      ? "inline-flex items-center rounded-full border px-2 py-0.5 text-xs bg-amber-50 border-amber-200 text-amber-900"
      : tone === "muted"
      ? "inline-flex items-center rounded-full border px-2 py-0.5 text-xs bg-gray-50 border-gray-200 text-gray-700"
      : "inline-flex items-center rounded-full border px-2 py-0.5 text-xs bg-white border-gray-200 text-gray-900";
  return <span className={cls}>{children}</span>;
}

function relativeTime(iso: string | null): string {
  if (!iso) return "never";
  const t = new Date(iso).getTime();
  const diff = Date.now() - t;
  const sec = Math.max(0, Math.floor(diff / 1000));
  if (sec < 10) return "just now";
  if (sec < 60) return `${sec}s ago`;
  const min = Math.floor(sec / 60);
  if (min < 60) return `${min}m ago`;
  const hr = Math.floor(min / 60);
  if (hr < 48) return `${hr}h ago`;
  const day = Math.floor(hr / 24);
  return `${day}d ago`;
}

export function CanonStatusChip({ canonKey }: { canonKey: string }) {
  const { data, loading } = useCanonStatus(canonKey);

  if (loading) return <Badge tone="muted">Canon: loading…</Badge>;
  if (!data) return <Badge tone="muted">Canon: unknown</Badge>;

  const label =
    data.status === "synced"
      ? `Canon synced: ${data.canonVersion} · ${relativeTime(data.lastSyncedAt)}`
      : data.status === "stale"
      ? `Canon stale: ${data.canonVersion} · ${relativeTime(data.lastSyncedAt)}`
      : "Canon status: unknown";

  const tone =
    data.status === "stale" ? "warning" : data.status === "unknown" ? "muted" : "default";

  return <Badge tone={tone}>{label}</Badge>;
}
