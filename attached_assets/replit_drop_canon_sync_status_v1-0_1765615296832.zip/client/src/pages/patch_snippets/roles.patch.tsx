/**
 * PATCH SNIPPET — roles.tsx
 *
 * 1) Add:
 *   import { CanonStatusChip } from "../components/CanonStatusChip";
 *
 * 2) Render near header top-right:
 *   <CanonStatusChip canonKey="dream_team_hub" />
 */
