/**
 * PATCH SNIPPET — syncDreamTeamFromCanon.ts
 *
 * After your sync completes successfully (after upserts),
 * write a canon sync event:
 *
 *   import { writeCanonSyncEvent } from "../lib/canonSync";
 *   await writeCanonSyncEvent(db, {
 *     canonKey: "dream_team_hub",
 *     canonVersion: canon.canonVersion ?? "v1.0",
 *     source: canon.source ?? "Dream Team Hub — Master Canvas (v1.0)",
 *     syncedBy: "syncDreamTeamFromCanon.ts",
 *   });
 */
