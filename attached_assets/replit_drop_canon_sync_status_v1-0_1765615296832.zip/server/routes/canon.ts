import { Router } from "express";
import { getLatestCanonStatus } from "../lib/canonSync";

// Adjust this import to your real DB export.
// Common patterns: ../db, ../db/index, ../db/connection
import { db } from "../db";

const router = Router();

/**
 * GET /api/canon/status?canonKey=dream_team_hub
 */
router.get("/status", async (req, res) => {
  try {
    const canonKey = String(req.query.canonKey ?? "dream_team_hub");
    const status = await getLatestCanonStatus(db, canonKey);
    res.json(status);
  } catch (err: any) {
    res.status(500).json({ error: "Failed to fetch canon status", details: String(err?.message ?? err) });
  }
});

export default router;
