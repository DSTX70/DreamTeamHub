# Ops Dropdown — "?" key opens menu + shows hint

**Date:** 2025-11-06

Update to the Ops menu so that pressing **"?"** (Shift+/) anywhere (outside inputs) will:
1) Open the Ops dropdown
2) Auto-open the hotkeys **"?"** tooltip for ~1.5s, then hide it (menu stays open)

Drop-in replacement for `client/src/components/HeaderOpsMenu.tsx`.
