
# In app/main.py add:
from app.agents.semantic.router import router as semantic_router
app.include_router(semantic_router, prefix="/agents/semantic", tags=["agents-semantic"])
