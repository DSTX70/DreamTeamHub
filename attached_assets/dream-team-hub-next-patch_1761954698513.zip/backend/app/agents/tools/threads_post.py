
from __future__ import annotations
import os

USE_OPENAI = os.getenv("USE_OPENAI","0").lower() in ("1","true","yes")

client = None
if USE_OPENAI:
    try:
        from openai import OpenAI
        client = OpenAI()
    except Exception:
        client = None

def threads_post(thread_id:str, content:str, meta:dict|None=None):
    if client:
        try:
            # Post a message to an existing thread
            client.beta.threads.messages.create(thread_id=thread_id, role="user", content=content)
            return {"ok": True, "thread_id": thread_id}
        except Exception as e:
            return {"ok": False, "error": str(e)}
    # Fallback console log
    print("[threads.post Fallback]", {"thread_id":thread_id, "content":content[:200]})
    return {"ok": True, "thread_id": thread_id, "note":"fallback log"}
