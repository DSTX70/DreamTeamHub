
from __future__ import annotations
from fastapi import APIRouter
from pydantic import BaseModel
from app.agents.semantic.service import upsert_embedding, semantic_search

router = APIRouter()

class EmbIn(BaseModel):
    handle: str
    kind: str = "note"
    text_value: str

@router.post("/add")
def add_embedding(body: EmbIn):
    return upsert_embedding(body.handle, body.kind, body.text_value)

class SearchIn(BaseModel):
    handle: str
    query: str
    top_k: int = 5

@router.post("/search")
def search(body: SearchIn):
    return semantic_search(body.handle, body.query, body.top_k)
