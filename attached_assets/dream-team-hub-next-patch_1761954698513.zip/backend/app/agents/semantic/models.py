
from __future__ import annotations
from sqlalchemy import Column, Integer, String, Text
from sqlalchemy.dialects.postgresql import VECTOR
from app.db.init import Base

class AgentEmbedding(Base):
    __tablename__ = "agent_embeddings"
    id = Column(Integer, primary_key=True)
    handle = Column(String, index=True, nullable=False)   # agent handle
    kind = Column(String, default="note")                 # note|run|rule
    text = Column(Text, default="")                       # source text
    embedding = Column(VECTOR(1536))                      # OpenAI text-embedding-3-small dims
