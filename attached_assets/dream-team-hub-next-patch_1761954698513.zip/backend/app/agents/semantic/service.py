
from __future__ import annotations
import os
from typing import List, Dict, Any
from sqlalchemy import text
from sqlalchemy.orm import Session
from app.db.init import SessionLocal, engine
from app.agents.semantic.models import AgentEmbedding

USE_OPENAI = os.getenv("USE_OPENAI","0").lower() in ("1","true","yes")
EMBED_MODEL = os.getenv("EMBED_MODEL","text-embedding-3-small")

client = None
if USE_OPENAI:
    try:
        from openai import OpenAI
        client = OpenAI()
    except Exception:
        client = None

def upsert_embedding(handle:str, kind:str, text_value:str, embedding:List[float] | None = None):
    db = SessionLocal()
    try:
        if embedding is None:
            if not client:
                return {"ok": False, "error":"OpenAI not enabled for embeddings"}
            emb = client.embeddings.create(model=EMBED_MODEL, input=text_value)
            embedding = emb.data[0].embedding
        rec = AgentEmbedding(handle=handle, kind=kind, text=text_value, embedding=embedding)
        db.add(rec); db.commit(); db.refresh(rec)
        return {"ok": True, "id": rec.id}
    finally:
        db.close()

def semantic_search(handle:str, query:str, top_k:int=5):
    # Get query embedding
    if not client:
        # fallback: return empty with message
        return {"items":[], "note":"embeddings disabled (USE_OPENAI=0)"}
    emb = client.embeddings.create(model=EMBED_MODEL, input=query)
    qv = emb.data[0].embedding
    # Use cosine distance via pgvector <-> operator
    with engine.connect() as conn:
        res = conn.execute(
            text("""
                SELECT id, handle, kind, text, 1 - (embedding <=> :vec) AS score
                FROM agent_embeddings
                WHERE handle = :handle
                ORDER BY embedding <=> :vec
                LIMIT :k
            """),
            {"vec": qv, "handle": handle, "k": top_k}
        )
        rows = res.fetchall()
        return {"items":[{"id":r.id,"kind":r.kind,"text":r.text,"score":float(r.score)} for r in rows]}
