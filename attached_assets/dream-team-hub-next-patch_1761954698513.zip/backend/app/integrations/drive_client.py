
from __future__ import annotations
import os, json, base64
from typing import List, Dict, Any
from google.oauth2 import service_account
from googleapiclient.discovery import build

SCOPES = ["https://www.googleapis.com/auth/drive"]
# Expect base64-encoded SA JSON in env GOOGLE_SERVICE_ACCOUNT_JSON_BASE64
def _sa_credentials():
    b64 = os.getenv("GOOGLE_SERVICE_ACCOUNT_JSON_BASE64","")
    if not b64:
        raise RuntimeError("Missing GOOGLE_SERVICE_ACCOUNT_JSON_BASE64")
    raw = base64.b64decode(b64)
    info = json.loads(raw.decode("utf-8"))
    creds = service_account.Credentials.from_service_account_info(info, scopes=SCOPES)
    return creds

def drive_service():
    creds = _sa_credentials()
    return build("drive", "v3", credentials=creds, cache_discovery=False)

def drive_search(q:str, page_size:int=25):
    svc = drive_service()
    results = svc.files().list(q=q, pageSize=page_size, fields="files(id,name,mimeType,parents)").execute()
    return {"items": results.get("files",[])}

def drive_move(file_id:str, new_parent_id:str):
    svc = drive_service()
    file = svc.files().get(fileId=file_id, fields="parents").execute()
    prev_parents = ",".join(file.get("parents", []))
    updated = svc.files().update(fileId=file_id, addParents=new_parent_id, removeParents=prev_parents, fields="id, parents").execute()
    return {"ok": True, "id": updated["id"], "parents": updated.get("parents",[])}
