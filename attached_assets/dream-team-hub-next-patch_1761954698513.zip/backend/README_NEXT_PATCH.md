
# Semantic Memory (pgvector)
- Set your DB to Postgres with pgvector installed (one-time):
  ```sql
  CREATE EXTENSION IF NOT EXISTS vector;
  ```
- Set env:
  ```
  DATABASE_URL=postgresql+psycopg://user:pass@host:port/db?sslmode=require
  USE_OPENAI=1
  EMBED_MODEL=text-embedding-3-small
  ```
- Mount the semantic router (in app/main.py):
  ```python
  from app.agents.semantic.router import router as semantic_router
  app.include_router(semantic_router, prefix="/agents/semantic", tags=["agents-semantic"])
  ```

# Google Drive Service Account
- Put your service-account JSON into a base64 secret:
  - Mac: `base64 -i sa.json | pbcopy`
  - Add to env: `GOOGLE_SERVICE_ACCOUNT_JSON_BASE64=<paste>`
- Sample calls:
  ```python
  from app.integrations.drive_client import drive_search, drive_move
  drive_search("name contains 'Spec' and trashed=false")
  drive_move("<fileId>", "<folderId>")
  ```

# Threads/Assistants
- Toggle with env:
  ```
  USE_OPENAI=1
  OPENAI_API_KEY=sk-...
  ```
- The tool now posts messages to an existing `thread_id` when `post_to_thread=true`.
