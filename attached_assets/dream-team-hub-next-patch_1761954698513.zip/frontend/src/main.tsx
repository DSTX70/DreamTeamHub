
import React, { useEffect, useState } from 'react'
import { createRoot } from 'react-dom/client'

const API = import.meta.env.VITE_API_URL || 'http://localhost:8000'

function AgentConsole() {
  const [agents, setAgents] = useState<any[]>([])
  const [selected, setSelected] = useState<string>('')
  const [task, setTask] = useState('Draft Week-1 OUAS A+ outline')
  const [output, setOutput] = useState('')
  const [post, setPost] = useState(false)
  const [loading, setLoading] = useState(false)
  const [mem, setMem] = useState<any[]>([])
  const [query, setQuery] = useState('')

  useEffect(() => {
    fetch(`${API}/agents`).then(r=>r.json()).then(d=>{
      setAgents(d.agents||[])
      if(d.agents?.length) setSelected(d.agents[0].handle)
    })
  }, [])

  useEffect(()=>{
    if(!selected) return
    fetch(`${API}/agents/${selected}/memory?limit=10`).then(r=>r.json()).then(d=>setMem(d.items||[]))
  }, [selected])

  const run = async () => {
    if(!selected || !task.trim()) return
    setLoading(true); setOutput('')
    const res = await fetch(`${API}/agents/run`,{
      method:'POST',
      headers:{'content-type':'application/json'},
      body: JSON.stringify({ agent:selected, task, links:[], post_to_thread:post })
    }).then(r=>r.json())
    setOutput(res.output||'')
    setLoading(false)
  }

  const feedback = async (txt:string, score=1) => {
    if(!selected || !txt.trim()) return
    await fetch(`${API}/agents/feedback`,{
      method:'POST',
      headers:{'content-type':'application/json'},
      body: JSON.stringify({ agent:selected, feedback:txt, score, kind:'feedback' })
    })
    fetch(`${API}/agents/${selected}/memory?limit=10`).then(r=>r.json()).then(d=>setMem(d.items||[]))
  }

  const search = async () => {
    if(!selected || !query.trim()) return
    const res = await fetch(`${API}/agents/semantic/search`,{
      method:'POST',
      headers:{'content-type':'application/json'},
      body: JSON.stringify({ handle:selected, query, top_k:5 })
    }).then(r=>r.json())
    alert('Top matches:\n' + (res.items||[]).map((x:any)=>`${x.score.toFixed(3)} — ${x.text.slice(0,80)}`).join('\n'))
  }

  return (
    <div style={{fontFamily:'Inter, system-ui, sans-serif', padding: 24, color:'#e8ebff', background:'#0B0D12', minHeight:'100vh'}}>
      <h1 style={{margin:0}}>Agent Console</h1>
      <p style={{opacity:.85}}>Run agents, post feedback (learning), and query semantic memory.</p>

      <div style={{display:'flex', gap:12, flexWrap:'wrap', margin:'12px 0'}}>
        <select value={selected} onChange={e=>setSelected(e.target.value)} style={{padding:8, borderRadius:8}}>
          {agents.map(a => <option key={a.handle} value={a.handle}>{a.handle} — {a.title}</option>)}
        </select>
        <label><input type="checkbox" checked={post} onChange={e=>setPost(e.target.checked)} /> Post to thread</label>
      </div>

      <textarea value={task} onChange={e=>setTask(e.target.value)} rows={4} style={{width:'100%', padding:12, borderRadius:12}} />

      <div style={{display:'flex', gap:12, margin:'10px 0'}}>
        <button onClick={run} disabled={loading} style={{padding:'10px 14px', borderRadius:12, fontWeight:600}}>{loading?'Running…':'Run Agent'}</button>
        <input placeholder="Feedback to teach agent…" onKeyDown={(e)=>{
          if(e.key==='Enter'){ feedback((e.target as HTMLInputElement).value); (e.target as HTMLInputElement).value='' }
        }} style={{flex:1, padding:'10px 12px', borderRadius:12}} />
      </div>

      <div style={{marginTop:12}}>
        <h3>Output</h3>
        <pre style={{whiteSpace:'pre-wrap', background:'#11162a', padding:16, borderRadius:12}}>{output}</pre>
      </div>

      <div style={{marginTop:12}}>
        <h3>Recent Memory</h3>
        <ul>{mem.map((m:any,i:number)=>(<li key={i}><b>{m.kind}</b>: {m.content}</li>))}</ul>
      </div>

      <div style={{marginTop:12, display:'flex', gap:10}}>
        <input placeholder="Semantic search query…" value={query} onChange={e=>setQuery(e.target.value)} style={{flex:1, padding:'10px 12px', borderRadius:12}} />
        <button onClick={search} style={{padding:'10px 14px', borderRadius:12, fontWeight:600}}>Semantic Search</button>
      </div>
    </div>
  )
}

createRoot(document.getElementById('root')!).render(<AgentConsole />)
