# Website Audit — Access & Testing Pack (v2)
_Date: 2025-11-04_

This pack consolidates everything needed to stand up a **staging environment on Replit**, protect it with **app-level access controls** (basic auth + CIDR allowlist), run a **PII-safe data refresh** (Greenmask by default), and execute a **disciplined audit** with clear guardrails.

## What’s inside
- **/docs/ACCESS_PLAN.md** — least-privilege plan & staging setup
- **/docs/INVITE_EMAIL.md** — paste-ready invite template
- **/docs/ROLES_MATRIX.csv** — who needs what permissions
- **/docs/CREDENTIALS_TEMPLATE.csv** — accounts to issue (fill in & vault)
- **/docs/STAGING_CHECKLIST.md** — safe staging prep (no PII)
- **/docs/TOOLING_LIST.md** — perf/security/a11y/SEO tools
- **/docs/WORKFLOW_WEEK.md** — day-by-day audit cadence
- **/docs/ISSUE_TEMPLATE.md** — standard issue format
- **/docs/SECURITY_GUARDRAILS.md** — hard rules
- **/docs/GA_SEARCH_CONSOLE_DELEGATION.md** — analytics delegation
- **/docs/GITHUB_LABELS_SEED.md** — label taxonomy & seeding
- **/ci/LIGHTHOUSE_CI.sample.yml** — perf baseline CI
- **/ci/STAGING_REFRESH.sample.yml** — weekly Greenmask refresh CI
- **/db/greenmask.yml** — example deterministic masking rules
- **/db/sql/ri_invariants.sql** — referential-integrity checks
- **/server/middleware/stagingGuard.js** — Express middleware (basic auth + CIDR + health bypass)
- **/.env.staging.sample** — environment variables for staging
- **/docs/DB_MASKING_OPTIONS.md** — PostgreSQL Anonymizer vs Greenmask vs custom

## Mapping to Replit’s questions & our answers
1) **Deployment Architecture (Replit)**
   - ✅ Separate **Replit deployment** for staging, `NODE_ENV=staging`, custom domain, app-level protection: see **`.env.staging.sample`** and **`/server/middleware/stagingGuard.js`**.

2) **Access Control Implementation**
   - ✅ Combined **CIDR allowlist + basic auth** with health check bypass (for uptime probes): see **`stagingGuard.js`**.
   - Env: `STAGING_USER`, `STAGING_PASSWORD`, `ALLOWED_IPS`. Logs on 401/403.

3) **Database Strategy (mirror prod WITHOUT PII)**
   - ✅ Default: **Greenmask (CLI)** with deterministic masking — versioned in Git & CI-friendly: see **`/db/greenmask.yml`**.
   - ✅ Alternative: **PostgreSQL Anonymizer (SQL)** — see **`/docs/DB_MASKING_OPTIONS.md`** for sample labels.
   - ✅ Custom Node script: for exotic fields only.

4) **Data Refresh Pipeline (weekly)**
   - ✅ CI skeleton: **`/ci/STAGING_REFRESH.sample.yml`** (dump → mask → restore → RI checks → notify).

**Defaults we recommend:** Greenmask; weekly refresh; allowlist office/CI IPs + basic auth; never import live PII.
