-- Referential Integrity invariants (add your own)
-- Example checks:
-- 1) Orphaned addresses
SELECT COUNT(*) AS orphaned_addresses
FROM addresses a LEFT JOIN users u ON a.user_id = u.id
WHERE u.id IS NULL;

-- 2) Users with null email
SELECT COUNT(*) AS users_null_email FROM users WHERE email IS NULL;

-- 3) Duplicated emails (post-masking should remain unique if required)
SELECT email, COUNT(*) FROM users GROUP BY email HAVING COUNT(*) > 1;
