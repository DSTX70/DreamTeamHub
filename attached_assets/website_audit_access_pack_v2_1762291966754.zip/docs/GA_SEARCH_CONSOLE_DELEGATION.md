# GA4 & Search Console Delegation (Read-Only)

GA4: Admin → Access Management → Add users → Read role (staging stream).  
Search Console: Settings → Users & permissions → Add user → Restricted (read).