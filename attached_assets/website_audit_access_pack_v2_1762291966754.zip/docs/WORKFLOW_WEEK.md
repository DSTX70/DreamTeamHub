# Audit Workflow (One Week)

**Day 1 — Access & Baselines**  
Validate logins; publish Lighthouse CI run; crawl for broken links; export KPI baseline.

**Days 2–3 — Deep Dives**  
Perf (Pulse), Accessibility (Lume), Security/Headers (Sentinel), SEO (Stratēga/Beacon), Errors (Uptime).

**Day 4 — Small Fixes**  
Open issues + small PRs (copy/aria/headers/code-splitting). Tag with `priority:P1`, `gate:*`, `stage:review`.

**Day 5 — Readout**  
1-pager: findings → impact → effort → ROI. Top 10 fixes & “no-regrets.” Ship a mini roadmap.
