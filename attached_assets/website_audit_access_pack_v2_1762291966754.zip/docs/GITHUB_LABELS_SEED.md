# GitHub Labels — Seed Instructions

```bash
export GITHUB_TOKEN=… 
export REPO=owner/repo
node DreamTeamHub/Agent-Lab/tools/seed_labels.js
```
Labels: `priority:*`, `gate:1..4`, `level:L0..L3`, `status:*`, `stage:*`.
