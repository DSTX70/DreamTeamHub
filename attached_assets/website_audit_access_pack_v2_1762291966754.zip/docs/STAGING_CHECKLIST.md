# Staging Checklist (Safe & Useful)
- [ ] Enable middleware guard (basic auth + CIDR allowlist)
- [ ] Health check route `/healthz` bypasses auth
- [ ] Seed synthetic / masked data only
- [ ] Disable real outbound mail/SMS; use sink
- [ ] Enable verbose logging (perf, errors)
- [ ] Create test accounts (editor/shopper) with MFA & expiry
- [ ] Publish environment notes (feature flags, CDN, cache)