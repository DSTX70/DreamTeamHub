# Security Guardrails
- No prod writes; staging only
- No copying PII/screens with PII
- MFA required; accounts auto-expire
- Secrets in vault; rotate post-window
- One channel of record: GitHub Issues (labeled)