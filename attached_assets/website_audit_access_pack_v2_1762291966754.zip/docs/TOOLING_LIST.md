# Tooling for Audit
Performance & UX: Lighthouse CI, WebPageTest, Chrome DevTools, Axe, Pa11y  
Errors & Quality: Sentry (staging), LogRocket (sampled), uptime  
SEO & Content: Google Search Console, Screaming Frog, schema validator  
Analytics: GA4 (staging stream), funnels & events snapshot  
Security headers: Mozilla Observatory, SecurityHeaders.com, report-only CSP
