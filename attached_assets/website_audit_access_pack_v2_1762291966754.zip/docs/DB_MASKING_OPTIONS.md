# DB Masking Options

**A) PostgreSQL Anonymizer (SQL-based, DB-native)**
Pros: Simple to maintain in DB; preserves RI; performant.  
Rules (example):
```
SECURITY LABEL FOR anon ON COLUMN users.email IS 'MASKED WITH FUNCTION anon.fake_email()';
SECURITY LABEL FOR anon ON COLUMN users.first_name IS 'MASKED WITH FUNCTION anon.fake_first_name()';
```

**B) Greenmask (CLI, CI/CD-friendly)** — *Recommended*
Pros: Deterministic masking; versioned configs; great in pipelines.  
Config sample: see `/db/greenmask.yml`.

**C) Custom Script (Node/Python)**
Pros: Maximum control for exotic fields.  
Cons: More code & maintenance; avoid unless necessary.
