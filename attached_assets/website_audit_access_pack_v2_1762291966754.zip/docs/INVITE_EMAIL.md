Subject: Staging access for Agent Lab audit (read-only / time-boxed)

Hi team—here are your least-privilege, time-limited credentials for **STAGING**:

• Staging: https://staging.yourdomain.com (user: ***** / pass: *****)
• Test accounts: shopper@test / editor@test (MFA via email)
• Telemetry (read-only): GA4, Search Console, Sentry, LogRocket
• Repos (read/triage): org/repo-frontend, org/repo-api
• Issue board: GitHub Projects “Website Audit”

**Scope:** audit & recommendations only (no prod changes).  
**Window:** <Start> → <End> (14–30 days).  
**Contact:** Helm @ handle • **Escalations:** OS
