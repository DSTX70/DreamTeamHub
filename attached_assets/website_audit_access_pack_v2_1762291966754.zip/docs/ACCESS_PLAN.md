# Access Plan (Least-Privilege, Time-Boxed)

## Staging Environment (Replit)
- Separate deployment with `NODE_ENV=staging`
- Custom domain, e.g. https://staging.yourdomain.com
- App-level protection: middleware (basic auth + CIDR allowlist)
- Health check endpoint: `/healthz` (no auth)
- Data: masked or synthetic (no PII)

## Accounts & Secrets
- Time-boxed staging users (MFA), stored in your vault
- Rotate after the audit window
- Replit Secrets for env vars (no secrets in repo)
