# [Type] <concise title>

**Type:** Performance | Accessibility | Security | SEO | Content | Bug  
**Priority:** P0 / P1 / P2  
**Area:** <page/feature>

## Why (impact)
<LCP 3.4s vs target 2.5s; blocking font; revenue impact if known>

## What (fix)
<Preconnect fonts/CDN, serve WOFF2 only, font-display: swap>

## Evidence
<Lighthouse trace, WebPageTest waterfall, Axe report>

## Estimate
<2–3h> — **Dependencies:** <none>
