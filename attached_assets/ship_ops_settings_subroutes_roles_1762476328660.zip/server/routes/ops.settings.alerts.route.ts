import express, { Request, Response } from "express";
import { opsAuth } from "../middleware/opsAuth";
import { effectiveSettings, writeSettings } from "../notifiers/settingsStore";
import { webhookNotifier } from "../notifiers/webhook";
import { emailNotifier } from "../notifiers/email";

const router = express.Router();

function allowEditorOrAdmin(req: Request, res: Response, next: any) {
  const roles = ((req as any).auth?.roles || []) as string[];
  if (roles.includes("ops_admin") || roles.includes("ops_editor")) return next();
  return res.status(403).json({ error: "Forbidden (role)" });
}

router.get("/api/ops/settings/alerts", opsAuth(), allowEditorOrAdmin, async (_req: Request, res: Response) => {
  const s = await effectiveSettings();
  res.json({
    slackWebhookUrl: s.slackWebhookUrl,
    emailEnabled: s.emailEnabled,
    emailFrom: s.emailFrom,
    emailTo: s.emailTo,
    smtpHost: s.smtpHost,
    smtpPort: s.smtpPort,
    smtpUser: s.smtpUser,
  });
});

router.post("/api/ops/settings/alerts", opsAuth(), allowEditorOrAdmin, express.json(), async (req: Request, res: Response) => {
  const body = req.body || {};
  await writeSettings({
    slackWebhookUrl: String(body.slackWebhookUrl || ""),
    emailEnabled: !!body.emailEnabled,
    emailFrom: String(body.emailFrom || ""),
    emailTo: String(body.emailTo || ""),
    smtpHost: String(body.smtpHost || ""),
    smtpPort: Number(body.smtpPort || 587),
    smtpUser: String(body.smtpUser || ""),
    smtpPass: String(body.smtpPass || ""),
  });
  const s = await effectiveSettings();
  res.json({ ok: true, emailEnabled: s.emailEnabled });
});

router.post("/api/ops/settings/alerts/test-webhook", opsAuth(), allowEditorOrAdmin, async (_req: Request, res: Response) => {
  const s = await effectiveSettings();
  const n = webhookNotifier({ url: s.slackWebhookUrl });
  if (!n) return res.status(400).json({ error: "Webhook URL not set" });
  await n({ kind: "low-stock", sku: "TEST-ALERT", stock: 1, threshold: 9, at: new Date().toISOString() });
  res.json({ ok: true });
});

router.post("/api/ops/settings/alerts/test-email", opsAuth(), allowEditorOrAdmin, async (_req: Request, res: Response) => {
  const s = await effectiveSettings();
  const n = emailNotifier({
    enabled: s.emailEnabled,
    from: s.emailFrom || process.env.EMAIL_FROM || "",
    to: s.emailTo || process.env.EMAIL_TO || "",
    transport: {
      host: s.smtpHost || process.env.SMTP_HOST,
      port: Number(s.smtpPort || process.env.SMTP_PORT || 587),
      secure: false,
      auth: { user: s.smtpUser || process.env.SMTP_USER, pass: s.smtpPass || process.env.SMTP_PASS }
    }
  });
  if (!n) return res.status(400).json({ error: "Email not enabled or SMTP missing" });
  await n({ kind: "low-stock", sku: "TEST-EMAIL", stock: 2, threshold: 9, at: new Date().toISOString() });
  res.json({ ok: true });
});

export default router;
