import express, { Request, Response } from "express";
import { opsAuth } from "../middleware/opsAuth";
import { requireRole } from "../middleware/requireRole";
import { effectiveSettings, writeSettings } from "../notifiers/settingsStore";

const router = express.Router();

router.get("/api/ops/settings/global", opsAuth(), requireRole("ops_admin"), async (_req: Request, res: Response) => {
  const s = await effectiveSettings();
  res.json({ hotkeysEnabled: s.hotkeysEnabled });
});

router.post("/api/ops/settings/global", opsAuth(), requireRole("ops_admin"), express.json(), async (req: Request, res: Response) => {
  const body = req.body || {};
  await writeSettings({ hotkeysEnabled: body.hotkeysEnabled !== undefined ? !!body.hotkeysEnabled : undefined });
  const s = await effectiveSettings();
  res.json({ ok: true, hotkeysEnabled: s.hotkeysEnabled });
});

export default router;
