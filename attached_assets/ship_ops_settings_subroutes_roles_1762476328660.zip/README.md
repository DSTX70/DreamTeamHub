# /ops/settings — Sub-routes + Role Gating (viewer/editor/admin)

Date: 2025-11-07

This drop splits /ops/settings into sub-routes with role gating:

- /api/ops/settings/alerts (GET/POST): requires ops_editor or ops_admin
- /api/ops/settings/global (GET/POST): requires ops_admin only

Client pages:
- /ops/settings/alerts — Alerts (Slack + Email) — editor/admin
- /ops/settings/global — Global controls (Hotkeys) — admin only
- Role-aware tabs via SettingsLayout + RequireRole.

Mount:
  app.use(require("./server/routes/ops.settings.alerts.route").default);
  app.use(require("./server/routes/ops.settings.global.route").default);
