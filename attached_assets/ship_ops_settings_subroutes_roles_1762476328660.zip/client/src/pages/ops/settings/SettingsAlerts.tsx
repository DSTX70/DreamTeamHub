import React from "react";

const SettingsAlerts: React.FC = () => {
  const [s, setS] = React.useState<any | null>(null);
  const [busy, setBusy] = React.useState(false);
  const [note, setNote] = React.useState("");

  const load = async () => {
    const r = await fetch("/api/ops/settings/alerts");
    const j = await r.json();
    setS(j);
  };
  React.useEffect(()=>{ load(); }, []);

  const save = async () => {
    setBusy(true);
    setNote("");
    await fetch("/api/ops/settings/alerts", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(s) });
    setBusy(false);
    setNote("Saved.");
  };

  const testWebhook = async () => {
    setBusy(true);
    setNote("");
    const r = await fetch("/api/ops/settings/alerts/test-webhook", { method: "POST" });
    setBusy(false);
    setNote(r.ok ? "Webhook sent." : "Webhook failed.");
  };

  const testEmail = async () => {
    setBusy(true);
    setNote("");
    const r = await fetch("/api/ops/settings/alerts/test-email", { method: "POST" });
    setBusy(false);
    setNote(r.ok ? "Email sent." : "Email failed.");
  };

  if (!s) return <div>Loading…</div>;

  return (
    <div className="space-y-3">
      <div className="font-semibold">Alerts (editor/admin)</div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        <label className="flex flex-col gap-1 text-sm">
          <span className="text-xs text-gray-600">Slack Webhook URL</span>
          <input className="border rounded px-2 py-1" value={s.slackWebhookUrl || ""} onChange={e=>setS({ ...s, slackWebhookUrl: e.target.value })} />
        </label>
        <label className="flex items-center gap-2 text-sm">
          <input type="checkbox" checked={!!s.emailEnabled} onChange={e=>setS({ ...s, emailEnabled: e.target.checked })} />
          <span>Email Enabled</span>
        </label>
        <label className="flex flex-col gap-1 text-sm">
          <span className="text-xs text-gray-600">Email From</span>
          <input className="border rounded px-2 py-1" value={s.emailFrom || ""} onChange={e=>setS({ ...s, emailFrom: e.target.value })} />
        </label>
        <label className="flex flex-col gap-1 text-sm">
          <span className="text-xs text-gray-600">Email To</span>
          <input className="border rounded px-2 py-1" value={s.emailTo || ""} onChange={e=>setS({ ...s, emailTo: e.target.value })} />
        </label>
        <label className="flex flex-col gap-1 text-sm">
          <span className="text-xs text-gray-600">SMTP Host</span>
          <input className="border rounded px-2 py-1" value={s.smtpHost || ""} onChange={e=>setS({ ...s, smtpHost: e.target.value })} />
        </label>
        <label className="flex flex-col gap-1 text-sm">
          <span className="text-xs text-gray-600">SMTP Port</span>
          <input type="number" className="border rounded px-2 py-1" value={s.smtpPort || 587} onChange={e=>setS({ ...s, smtpPort: Number(e.target.value) })} />
        </label>
        <label className="flex flex-col gap-1 text-sm">
          <span className="text-xs text-gray-600">SMTP User</span>
          <input className="border rounded px-2 py-1" value={s.smtpUser || ""} onChange={e=>setS({ ...s, smtpUser: e.target.value })} />
        </label>
        <label className="flex flex-col gap-1 text-sm">
          <span className="text-xs text-gray-600">SMTP Pass</span>
          <input type="password" className="border rounded px-2 py-1" value={s.smtpPass || ""} onChange={e=>setS({ ...s, smtpPass: e.target.value })} />
        </label>
      </div>
      <div className="flex gap-2">
        <button className="px-3 py-2 border rounded" onClick={save} disabled={busy}>Save</button>
        <button className="px-3 py-2 border rounded" onClick={testWebhook} disabled={busy}>Test Webhook</button>
        <button className="px-3 py-2 border rounded" onClick={testEmail} disabled={busy || !s.emailEnabled}>Test Email</button>
        <span className="text-sm text-gray-600">{note}</span>
      </div>
    </div>
  );
};

export default SettingsAlerts;
