import React from "react";

const SettingsGlobal: React.FC = () => {
  const [s, setS] = React.useState<{ hotkeysEnabled: boolean } | null>(null);
  const [busy, setBusy] = React.useState(false);
  const [note, setNote] = React.useState("");

  const load = async () => {
    const r = await fetch("/api/ops/settings/global");
    if (!r.ok) return setS(null);
    const j = await r.json();
    setS({ hotkeysEnabled: !!j.hotkeysEnabled });
  };
  React.useEffect(()=>{ load(); }, []);

  const save = async () => {
    if (!s) return;
    setBusy(true);
    setNote("");
    await fetch("/api/ops/settings/global", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(s) });
    setBusy(false);
    setNote("Saved.");
  };

  if (!s) return <div>Loading…</div>;

  return (
    <div className="space-y-3">
      <div className="font-semibold">Global controls (admin only)</div>
      <label className="flex items-center gap-2 text-sm">
        <input type="checkbox" checked={s.hotkeysEnabled} onChange={e=>setS({ hotkeysEnabled: e.target.checked })} />
        <span>Hotkeys</span>
      </label>
      <div className="flex gap-2">
        <button className="px-3 py-2 border rounded" onClick={save} disabled={busy}>Save</button>
        <span className="text-sm text-gray-600">{note}</span>
      </div>
    </div>
  );
};

export default SettingsGlobal;
