import React from "react";
import { Outlet, NavLink } from "react-router-dom";

const Tab: React.FC<{ to: string; label: string }> = ({ to, label }) => (
  <NavLink
    to={to}
    className={({ isActive }) =>
      `px-3 py-2 rounded border ${isActive ? 'bg-gray-100 border-gray-300' : 'border-transparent hover:bg-gray-50'}`
    }
    end
  >
    {label}
  </NavLink>
);

const SettingsLayout: React.FC = () => {
  return (
    <div className="p-4 space-y-4">
      <h1 className="text-xl font-semibold">Ops Settings</h1>
      <div className="flex gap-2">
        <Tab to="alerts" label="Alerts" />
        <Tab to="global" label="Global" />
      </div>
      <div className="border rounded p-3">
        <Outlet />
      </div>
    </div>
  );
};

export default SettingsLayout;
