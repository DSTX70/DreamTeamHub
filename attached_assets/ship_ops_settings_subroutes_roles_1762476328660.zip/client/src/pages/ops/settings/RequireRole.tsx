import React from "react";

type Props = { roles: string[]; children: React.ReactNode };

const RequireRole: React.FC<Props> = ({ roles, children }) => {
  const [ok, setOk] = React.useState<boolean | null>(null);

  React.useEffect(() => {
    (async () => {
      try {
        const r = await fetch("/api/ops/_auth/ping");
        if (!r.ok) return setOk(false);
        const j = await r.json();
        const have = Array.isArray(j?.who?.roles) ? j.who.roles : [];
        setOk(roles.some(role => have.includes(role)));
      } catch {
        setOk(false);
      }
    })();
  }, [roles.join(",")]);

  if (ok === null) return <div className="text-sm text-gray-500">Checking permissions…</div>;
  if (!ok) return <div className="text-sm text-red-600">You do not have access to this section.</div>;
  return <>{children}</>;
};

export default RequireRole;
