import React, { useCallback } from "react";
import { useHotkeys } from "../hooks/useHotkeys";
import Toast from "./Toast"; // optional; ignore if not present

type Props = { navigate?: (path: string) => void };

const map: Record<string, string> = {
  "g o": "/ops/overview",
  "g i": "/ops/inventory",
  "g m": "/ops/images",
  "g a": "/ops/affiliates",
  "g s": "/ops/settings",
};

function toKey(seq: string[]) { return seq.join(" "); }

const OpsHotkeys: React.FC<Props> = ({ navigate }) => {
  const [showToast, setShowToast] = React.useState(false);
  const [enabled, setEnabled] = React.useState<boolean>(true);

  React.useEffect(() => {
    (async () => {
      try {
        const r = await fetch("/api/ops/settings/notifiers");
        const j = await r.json();
        setEnabled(!!j.settings?.hotkeysEnabled ?? true);
      } catch {
        setEnabled(true);
      }
    })();
  }, []);

  const markSeen = () => {
    try { localStorage.setItem("opsHotkeysSeen", "1"); } catch {}
  };
  const hasSeen = () => {
    try { return localStorage.getItem("opsHotkeysSeen") === "1"; } catch { return true; }
  };

  const go = (path: string) => {
    if (!hasSeen()) setShowToast(true);
    markSeen();
    if (navigate) navigate(path);
    else window.location.assign(path);
  };

  const onSequence = useCallback((seq: string[]) => {
    const key = toKey(seq);
    const target = map[key];
    if (target) {
      go(target);
      return true;
    }
    if (seq.length >= 2) return true;
    return false;
  }, [navigate]);

  // Respect global toggle
  useHotkeys({ onSequence, timeoutMs: 1200, enable: enabled });

  return <>{showToast ? <div className="fixed bottom-4 right-4 bg-black text-white text-sm px-3 py-2 rounded shadow-lg opacity-90">Hotkeys active — press ? for help</div> : null}</>;
};

export default OpsHotkeys;
