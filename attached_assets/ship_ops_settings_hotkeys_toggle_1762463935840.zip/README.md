# Ops Settings — Global Hotkeys Toggle

**Date:** 2025-11-06

Adds a **Hotkeys: On** toggle to **/ops/settings** and wires it so global hotkeys can be disabled org‑wide.

## What’s included
- `server/notifiers/settingsStore.ts` — adds `hotkeysEnabled` (default `true`).
- `server/routes/ops_settings.route.ts` — GET/POST now include `hotkeysEnabled`.
- `client/src/pages/ops/OpsSettings.tsx` — UI toggle for Hotkeys.
- `client/src/components/OpsHotkeys.tsx` — respects server setting; if disabled, the listener stays off.

## Notes
- The same settings JSON file (`/data/ops_settings.json` by default) now stores `hotkeysEnabled`.
- Backwards compatible: if the field is missing, it defaults to `true`.
