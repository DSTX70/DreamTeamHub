import React, { useCallback } from "react";
import { useHotkeys } from "../hooks/useHotkeys";
import Toast from "./Toast";

type Props = { navigate?: (path: string) => void };

const map: Record<string, string> = {
  "g o": "/ops/overview",
  "g i": "/ops/inventory",
  "g m": "/ops/images",
  "g a": "/ops/affiliates",
  "g s": "/ops/settings",
};

function toKey(seq: string[]) { return seq.join(" "); }

const OpsHotkeys: React.FC<Props> = ({ navigate }) => {
  const [showToast, setShowToast] = React.useState(false);

  const markSeen = () => {
    try { localStorage.setItem("opsHotkeysSeen", "1"); } catch {}
  };
  const hasSeen = () => {
    try { return localStorage.getItem("opsHotkeysSeen") === "1"; } catch { return true; }
  };

  const go = (path: string) => {
    if (!hasSeen()) setShowToast(true);
    markSeen();
    if (navigate) navigate(path);
    else window.location.assign(path);
  };

  const onSequence = useCallback((seq: string[]) => {
    const key = toKey(seq);
    const target = map[key];
    if (target) {
      go(target);
      return true;
    }
    if (seq.length >= 2) return true;
    return false;
  }, [navigate]);

  useHotkeys({ onSequence, timeoutMs: 1200, enable: true });

  return (
    <>
      {showToast && <Toast text="Hotkeys active — press ? for help" durationMs={2200} />}
    </>
  );
};

export default OpsHotkeys;
