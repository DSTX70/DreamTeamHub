# Hotkeys First-Use Toast

**Date:** 2025-11-06

Adds a tiny toast the **first time** a user triggers a hotkey. Message:
**“Hotkeys active — press ? for help.”**

## What’s included
- `client/src/components/Toast.tsx` — minimal toast component (auto-hide).
- `client/src/components/OpsHotkeys.tsx` — patched to show the toast on first hotkey use, persisted by `localStorage` key `opsHotkeysSeen=1`.

## How it works
- When a mapped hotkey is used (e.g., `g` then `o`), the helper checks `localStorage`.
- If not set, it renders the toast, then sets the flag so it won’t show again.
