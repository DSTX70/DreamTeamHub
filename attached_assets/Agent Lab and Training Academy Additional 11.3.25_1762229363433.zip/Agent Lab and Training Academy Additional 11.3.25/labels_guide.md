# Labels Guide (Agent Lab)
- priority:P0 — mandatory (safety, compliance, CEO-level OKR)
- priority:P1 — high value, near-term ROI
- priority:P2 — opportunistic/experimental

- level:L0..L3 — current autonomy target
- gate:1..4 — which gate is blocking
- status:pilot | live | watch | rollback
